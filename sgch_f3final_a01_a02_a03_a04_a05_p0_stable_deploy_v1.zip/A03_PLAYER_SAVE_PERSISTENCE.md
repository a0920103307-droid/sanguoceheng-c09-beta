# A03｜玩家存档持久化

## 目的
把招募、资源、武将、装备、战马、兵书、关卡进度等 canonical cloud save 从 Render 本机 SQLite 移到 PostgreSQL，避免 restart / redeploy 后存档消失。

## 本版变更
- `CloudSaveStore` 保持既有调用接口，但新增 backend selector
- SQLite backend 保留供本机开发／回滚
- PostgreSQL backend 使用：
  - `player_cloud_saves`
  - `player_cloud_backups`
- 保留 revision optimistic locking、checksum、自动备份与恢复逻辑
- `SGCH_SAVE_BACKEND` 可独立指定；未指定时跟随 `SGCH_AUTH_BACKEND`
- URL：`SGCH_SAVE_DATABASE_URL` → `SGCH_AUTH_DATABASE_URL` → `DATABASE_URL`
- 新增 `004_player_saves_to_postgres.py` 迁移工具

## 验收
1. 登入后改变资源／招募／阵容／装备等并保存
2. 记录 revision
3. restart / redeploy
4. 同帐号重新进入后内容与 revision 仍存在
5. 再保存 revision +1
6. 冲突 revision 会返回 CloudConflictError
7. backup 列表可读取，损坏主存档可由有效 backup 恢复

## 建议正式切换环境
- SGCH_AUTH_BACKEND=postgres
- SGCH_SESSION_BACKEND=postgres
- SGCH_SAVE_BACKEND=postgres
