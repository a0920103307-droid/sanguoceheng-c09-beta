﻿@echo off
cd /d %~dp0
set SGCH_ENV=staging
py -3 start_game.py
if errorlevel 1 python start_game.py
pause
