# 三國策衡｜P03 部署專案

此目錄是供 C09 真人封閉測試部署使用的乾淨來源專案，只保留執行／部署所需檔案。

## Runtime
- Python 3.10+
- 無第三方 Python runtime 套件
- 預設 production bind：`0.0.0.0:8080`

## 本機 / Linux 啟動
```bash
export SGCH_ENV=production
export SGCH_HOST=0.0.0.0
export SGCH_PORT=8080
python3 migrations/001_initialize_databases.py
python3 start_game.py
```

部署平台若提供動態 Port，請把該 Port 映射到 `SGCH_PORT`。

## Git / Secret 規則
- 不提交 `.env`
- 不提交 `save_data/`、`logs/`、SQLite DB、telemetry secret
- 不提交任何內部交接、研究、歷史比對或非部署必要資料
- `.env.example` 僅放非秘密範例值

## Web / PWA
啟動後由同一服務提供：
- `/`
- `/manifest.webmanifest`
- `/sw.js`

## 健康檢查
部署後確認：
- `GET /api/health` → HTTP 200
- `GET /api/version` → HTTP 200

## P03 基線
本專案來源基於已通過 P02 的修正版 Build：
`sanguoceheng-0.4.0-d10-ipclean-p02fix1.zip`

## P04｜Render Web Service
本專案已加入 `render.yaml`，供 Render Blueprint / Web Service 使用。

建議設定：
- Service name：`sanguoceheng-c09-beta`
- Runtime：Python
- Region：Singapore
- Build command：`pip install -r requirements.txt`
- Start command：由 `render.yaml` 將 Render 的 `$PORT` 映射到 `SGCH_PORT`，先初始化資料庫，再啟動 `start_game.py`
- Health check：`/api/health`

> P04 只建立 Web Service；SQLite/JSON 的永久儲存掛載屬 P05。正式真人封測前必須完成 P05 的 restart/redeploy persistence 驗證。
