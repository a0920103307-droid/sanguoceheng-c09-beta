from pathlib import Path
import argparse, datetime, shutil
p=argparse.ArgumentParser(); p.add_argument('--save-dir',required=True); p.add_argument('--out',default='runtime_backups'); args=p.parse_args()
src=Path(args.save_dir).resolve(); out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
if not src.exists(): raise SystemExit(f'save dir not found: {src}')
stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
base=out/f'sgch-save-{stamp}'
archive=shutil.make_archive(str(base),'zip',root_dir=src)
print(archive)
