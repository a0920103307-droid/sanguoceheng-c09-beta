from pathlib import Path
import json, os, sys
BASE=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
for f in ['VERSION','DATA_VERSION','BUILD_MANIFEST.json','web/index.html','start_game.py']:
    if not (BASE/f).exists(): errors.append(f'MISSING:{f}')
try:
    prod=json.loads((BASE/'config/production.json').read_text())
    if prod.get('beta_tools'): errors.append('production.beta_tools must be false')
    if prod.get('allow_guest'): warnings.append('production guest login enabled')
except Exception as e: errors.append(f'production config invalid: {e}')
for bad in ['.env','save_data','logs','__pycache__']:
    if (BASE/bad).exists(): warnings.append(f'package contains runtime path: {bad}')
print(json.dumps({'ok':not errors,'errors':errors,'warnings':warnings},ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
