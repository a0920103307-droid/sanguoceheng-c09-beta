from __future__ import annotations
from datetime import date
import json, random
from pathlib import Path
from typing import Any, Callable, Dict
BASE=Path(__file__).resolve().parent.parent
CATALOG=json.loads((BASE/'b07_arena_catalog.json').read_text(encoding='utf-8'))

class AIArenaController:
    """B07 adapter. Rating/rank/chest/season semantics delegate to legacy Grid12 PVPEngine."""
    def __init__(self, core, growth, decks, today_provider:Callable[[],str]|None=None, seed:int=7):
        self.engine=core.modules['pvp'].PVPEngine(seed=seed)
        self.Player=core.modules['pvp'].PVPPlayer
        self.player=self.Player('PLAYER', level=1)
        self.growth=growth; self.decks=decks; self.rng=random.Random(seed+700)
        self.today_provider=today_provider or (lambda: date.today().isoformat())
        self.day=''; self.season_id=CATALOG['season']['season_id']; self.season_matches=0
        self.history=[]
    def _today(self): return str(self.today_provider())
    def _roll_day(self):
        t=self._today()
        if self.day!=t:
            self.day=t; self.player.daily_wins=0; self.player.claimed_chests=set()
    def _power(self):
        cards=self.decks.active_cards() if self.decks.formal_active else ['張遼']
        total=0
        for n in cards:
            try:
                p=self.growth.roster.profile(n); total += 95 + p.level*3 + p.star*10
            except Exception: total += 90
        return max(100,total)
    def _grant(self,rewards):
        for k,v in rewards.items(): self.growth.roster.resources[k]=int(self.growth.roster.resources.get(k,0))+int(v)
    def challenge(self,opponent_id:str, force_won=None)->Dict[str,Any]:
        self._roll_day(); opp=next((x for x in CATALOG['ai_opponents'] if x['opponent_id']==str(opponent_id)),None)
        if not opp: raise ValueError('未知 AI 對手')
        power=self._power(); chance=max(.18,min(.82,.5+(power-int(opp['power']))/300.0))
        won=bool(force_won) if force_won is not None else self.rng.random()<chance
        micro=self.engine.resolve_micro_arena(self.player,won=won)
        season=self.engine.resolve_heroes_contest(self.player,won=won); self.season_matches+=1
        rewards=dict(CATALOG['balance_match_rewards']['win' if won else 'loss']); self._grant(rewards)
        rec={'day':self.day,'opponent_id':opp['opponent_id'],'opponent_name':opp['name'],'won':won,'chance':round(chance,3),'player_power':power,'micro':micro,'season':season,'rewards':rewards}
        self.history=(self.history+[rec])[-100:]; return rec
    def claim_chest(self,threshold:int)->Dict[str,Any]:
        self._roll_day(); rewards=self.engine.claim_micro_chest(self.player,int(threshold)); self._grant(rewards)
        return {'threshold':int(threshold),'rewards':rewards}
    def reset_season(self,new_season_id:str|None=None):
        self.player.dragon_seals=0; self.season_matches=0; self.season_id=str(new_season_id or self.season_id); self.history=[]
        return {'season_id':self.season_id,'dragon_seals':0}
    def export(self):
        self._roll_day(); return {'day':self.day,'micro_points':self.player.micro_points,'daily_wins':self.player.daily_wins,'claimed_chests':sorted(self.player.claimed_chests),'dragon_seals':self.player.dragon_seals,'season_id':self.season_id,'season_matches':self.season_matches,'history':list(self.history[-100:])}
    def import_data(self,data):
        d=data or {}; self.day=str(d.get('day') or ''); self.player.micro_points=int(d.get('micro_points',0)); self.player.daily_wins=int(d.get('daily_wins',0)); self.player.claimed_chests=set(int(x) for x in d.get('claimed_chests',[])); self.player.dragon_seals=int(d.get('dragon_seals',0)); self.season_id=str(d.get('season_id') or CATALOG['season']['season_id']); self.season_matches=int(d.get('season_matches',0)); self.history=list(d.get('history') or [])[-100:]; self._roll_day()
    def state(self):
        self._roll_day(); points=self.player.micro_points; rank=self.engine.micro_rank(points)
        bots=[]
        for x in CATALOG['ai_opponents']:
            y=dict(x); y['recommended']=abs(int(x['power'])-self._power())<=35; bots.append(y)
        simulated=[self.Player('NPC_A',micro_points=max(0,points+80)),self.Player('NPC_B',micro_points=max(0,points+25)),self.player,self.Player('NPC_C',micro_points=max(0,points-35))]
        glory=[{'rank':i+1,'player_id':p.player_id,'points':p.micro_points,'is_player':p.player_id=='PLAYER'} for i,p in enumerate(self.engine.glory_ranking(simulated))]
        season_players=[self.Player('NPC_A',dragon_seals=max(0,self.player.dragon_seals+18)),self.player,self.Player('NPC_B',dragon_seals=max(0,self.player.dragon_seals-8))]
        return {'version':'B07','mode':'LOCAL_AI','unlock_level':15,'unlocked':self.player.level>=15,'player_level':self.player.level,'day':self.day,'points':points,'rank':rank,'daily_wins':self.player.daily_wins,'available_chests':self.engine.available_micro_chests(self.player),'claimed_chests':sorted(self.player.claimed_chests),'opponents':bots,'glory_ranking':glory,'season':{'season_id':self.season_id,'name':CATALOG['season']['name'],'dragon_seals':self.player.dragon_seals,'matches':self.season_matches,'ranking':self.engine.season_ranking(season_players),'cross_server':CATALOG['season']['cross_server']},'hundred_generals':dict(CATALOG['hundred_generals']),'realtime_human_pvp':False,'player_power':self._power(),'history':list(self.history[-10:])}
