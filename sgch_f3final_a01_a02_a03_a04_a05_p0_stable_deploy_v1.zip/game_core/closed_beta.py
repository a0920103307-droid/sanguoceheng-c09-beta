from __future__ import annotations
import json, sqlite3, threading, time
from dataclasses import dataclass
from pathlib import Path

CATEGORIES={'install','login','tutorial','first_hour','return','cards','economy','bug','ui','performance','other'}
SEVERITIES={'blocker','major','minor','suggestion'}
PRIORITY_BY_SEVERITY={'blocker':'P0','major':'P1','minor':'P2','suggestion':'P3'}

@dataclass(frozen=True)
class BetaFeedback:
    player_hash:str
    session_id:str|None
    category:str
    severity:str
    screen:str|None
    message:str
    reproduce:str|None=None

class ClosedBetaStore:
    """C09 closed-beta feedback store. Contains redacted tester ids only."""
    def __init__(self, db_path: str|Path):
        self.db_path=Path(db_path); self.db_path.parent.mkdir(parents=True,exist_ok=True)
        self._lock=threading.RLock(); self._init_db()
    def _connect(self):
        con=sqlite3.connect(self.db_path,timeout=10); con.row_factory=sqlite3.Row; return con
    def _init_db(self):
        with self._connect() as con:
            con.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS beta_feedback(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts REAL NOT NULL,
              player_hash TEXT NOT NULL,
              session_id TEXT,
              category TEXT NOT NULL,
              severity TEXT NOT NULL,
              priority TEXT NOT NULL,
              screen TEXT,
              message TEXT NOT NULL,
              reproduce TEXT,
              status TEXT NOT NULL DEFAULT 'open'
            );
            CREATE INDEX IF NOT EXISTS idx_beta_priority ON beta_feedback(priority,status,ts);
            CREATE INDEX IF NOT EXISTS idx_beta_player ON beta_feedback(player_hash,ts);
            ''')
    @staticmethod
    def _clean_text(value,limit):
        return str(value or '').strip()[:limit]
    def submit(self, feedback:BetaFeedback):
        category=self._clean_text(feedback.category,24).lower()
        severity=self._clean_text(feedback.severity,24).lower()
        if category not in CATEGORIES: raise ValueError('未知的回饋分類')
        if severity not in SEVERITIES: raise ValueError('未知的嚴重度')
        message=self._clean_text(feedback.message,1200)
        if not message: raise ValueError('請填寫回饋內容')
        reproduce=self._clean_text(feedback.reproduce,1200) or None
        screen=self._clean_text(feedback.screen,48) or None
        session=self._clean_text(feedback.session_id,80) or None
        priority=PRIORITY_BY_SEVERITY[severity]
        with self._lock,self._connect() as con:
            cur=con.execute('''INSERT INTO beta_feedback(ts,player_hash,session_id,category,severity,priority,screen,message,reproduce,status)
              VALUES(?,?,?,?,?,?,?,?,?,'open')''',(time.time(),feedback.player_hash,session,category,severity,priority,screen,message,reproduce))
            return int(cur.lastrowid),priority
    def report(self,limit=100):
        limit=max(1,min(int(limit),500))
        with self._connect() as con:
            total=con.execute('SELECT COUNT(*) n FROM beta_feedback').fetchone()['n']
            open_count=con.execute("SELECT COUNT(*) n FROM beta_feedback WHERE status='open'").fetchone()['n']
            by_priority=[dict(r) for r in con.execute('SELECT priority,COUNT(*) count FROM beta_feedback GROUP BY priority ORDER BY priority')]
            by_category=[dict(r) for r in con.execute('SELECT category,COUNT(*) count FROM beta_feedback GROUP BY category ORDER BY count DESC,category')]
            items=[dict(r) for r in con.execute('''SELECT id,ts,player_hash,session_id,category,severity,priority,screen,message,reproduce,status
              FROM beta_feedback ORDER BY CASE priority WHEN 'P0' THEN 0 WHEN 'P1' THEN 1 WHEN 'P2' THEN 2 ELSE 3 END, id DESC LIMIT ?''',(limit,))]
        return {'schema':'sgch.closed_beta.feedback_report','total_feedback':total,'open_feedback':open_count,'by_priority':by_priority,'by_category':by_category,'items':items}
