from __future__ import annotations
from .general_runtime import load_catalog

class ContentPool:
    def __init__(self):
        self.catalog=load_catalog(expanded=True); self.by_id={x['card_id']:x for x in self.catalog['cards']}; self.by_name={x['name']:x for x in self.catalog['cards']}
    def grant_to_collection(self, collection, name:str, qty:int=1):
        c=self.by_name[name]; cid=c['card_id']; qty=max(1,int(qty)); newly=cid not in collection.engine.state.owned
        if newly:
            collection.engine.state.owned[cid]=1; collection._ensure_growth_profile(name); qty-=1
        if qty>0:
            collection.engine.state.fragments[cid]=int(collection.engine.state.fragments.get(cid,0))+qty
            collection._sync_fragment_to_growth(cid,name)
        return {'name':name,'newly_owned':newly,'fragment_added':max(0,qty)}
