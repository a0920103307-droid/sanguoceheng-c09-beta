from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / 'runtime_modules'


def _read(rel: str):
    return json.loads((RUNTIME / rel).read_text(encoding='utf-8'))


def support_catalog() -> Dict[str, Any]:
    tactics = _read('tactics/tactic_catalog_v0.4.json')
    horses = _read('horse/horse_catalog_v0.5.json')
    equip = _read('equipment/equipment_catalog_v0.6.json')
    return {
        'books': tactics['books'],
        'commands': tactics['commands'],
        'horses': horses['horses'],
        'equipment': equip['equipment'],
        'exclusive_fates': equip['exclusive_fates'],
        'equipment_system_rules': equip.get('system_rules',{}),
        'horse_system_rules': horses.get('system_rules',{}),
    }


def command_target_mode(name: str) -> str:
    if name in {'軍令集火','軍令衝擊'}: return 'ENEMY'
    if name in {'軍令戰意','軍令死誌','軍令重生'}: return 'ALLY'
    if name == '軍令固守': return 'NONE'
    raise KeyError(name)


def equipment_slot(name: str) -> str:
    for row in support_catalog()['equipment']:
        if row['name'] == name or row['equipment_id'] == name:
            return row['slot']
    raise KeyError(name)



def _quality_tier(raw: str) -> str:
    q=str(raw or '未確認')
    if '橙' in q: return '橙'
    if '紫' in q: return '紫'
    if '藍' in q: return '藍'
    if '綠' in q: return '綠'
    if '基礎' in q: return '藍（封測分類）'
    if '高階' in q: return '高階／待核'
    return '未確認'

def f3d_beta_config() -> Dict[str, Any]:
    return _read('support_f3d_beta.json')

def equipment_detail(row: Dict[str, Any]) -> Dict[str, Any]:
    slot=row.get('slot')
    return {**row,'quality_display':_quality_tier(row.get('quality')),'stat_type':'攻擊' if slot=='WEAPON' else '生命','five_star_rule':'五星裝備：淬鍊命中的既有技能 +1（原版規則已確認，精確成本為封測值）'}

def horse_detail(row: Dict[str, Any]) -> Dict[str, Any]:
    return {**row,'quality_display':_quality_tier(row.get('quality')),'level_rule':'戰馬升級會同步提升技能等級','battle_attachment':'掛載於武將，不占戰場格'}

def book_detail(row: Dict[str, Any]) -> Dict[str, Any]:
    return {**row,'quality_display':_quality_tier(row.get('quality')),'battle_attachment':'牌組戰術卡，不掛在特定武將、不占戰場格'}

def public_catalog() -> Dict[str, List[Dict[str, Any]]]:
    c=support_catalog()
    return {
      'books': [book_detail(x) for x in c['books']],
      'commands': [{**{k:x.get(k) for k in ('id','name','level','effect_original','confidence','numeric_status')}, 'target_mode':command_target_mode(x['name'])} for x in c['commands']],
      'horses': [horse_detail(x) for x in c['horses']],
      'equipment': [equipment_detail(x) for x in c['equipment']],
      'exclusive_fates': list(c['exclusive_fates']),
      'system_rules': {
        'equipment': c.get('equipment_system_rules',{}),
        'horse': c.get('horse_system_rules',{}),
      }
    }
