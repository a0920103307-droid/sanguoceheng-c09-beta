from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
import random, statistics

@dataclass
class FairPreset:
    preset_id:str
    name:str
    cards:List[str]
    note:str

class FairTestController:
    """F3-E.2 closed-beta fair test center.

    This mode intentionally ignores collection ownership. It exists to test card identity,
    targeting, positioning and balance before the formal economy is finalized.
    Values marked BETA are test rules, not claimed original rules.
    """
    def __init__(self, collection, seed:int=73):
        self.collection=collection
        self.seed=seed
        self.rng=random.Random(seed)
        self.pool_size=30
        self.deck_size=8
        self.ai_level=3
        self.random_pool:List[str]=[]
        self.saved_decks={1:{'name':'測試牌組A','cards':[]},2:{'name':'測試牌組B','cards':[]},3:{'name':'測試牌組C','cards':[]}}
        self.active_slot=1
        self.history:List[Dict[str,Any]]=[]
        self.last_batch=None
        self.refresh_pool()

    def _cards(self):
        return [c for c in self.collection.state()['collection'] if c.get('name')]
    def _by_name(self): return {c['name']:c for c in self._cards()}
    def all_names(self): return [c['name'] for c in self._cards()]
    def refresh_pool(self,size:int|None=None):
        names=self.all_names(); n=max(12,min(len(names),int(size or self.pool_size)))
        self.random_pool=self.rng.sample(names,n) if len(names)>n else list(names)
        self.pool_size=n
        return list(self.random_pool)
    def save_deck(self,slot_id:int,name:str,cards:List[str],scope='FREE'):
        sid=max(1,min(3,int(slot_id))); valid=self._by_name(); seen=[]
        allowed=set(self.random_pool) if scope=='RANDOM' else set(valid)
        for raw in cards:
            n=str(raw)
            if n in seen: continue
            if n not in valid: raise ValueError(f'未知卡牌：{n}')
            if n not in allowed: raise ValueError(f'此卡不在目前隨機卡池：{n}')
            seen.append(n)
        if not seen: raise ValueError('公平測試牌組至少需要1張卡')
        if len(seen)>self.deck_size: raise ValueError(f'公平測試牌組最多 {self.deck_size} 張')
        self.saved_decks[sid]={'name':str(name or f'測試牌組{sid}')[:24],'cards':seen}
        self.active_slot=sid
        return self.saved_decks[sid]
    def select_deck(self,slot_id:int): self.active_slot=max(1,min(3,int(slot_id))); return self.saved_decks[self.active_slot]
    def set_ai_level(self,level:int): self.ai_level=max(1,min(5,int(level))); return self.ai_level

    def presets(self):
        names=set(self.all_names())
        raw=[
            FairPreset('WEI_CONTROL','魏國控場',['曹操','張遼','郭嘉','司馬懿','張郃','盾兵','輔兵','醫護兵'],'控場＋站場測試'),
            FairPreset('SHU_BURST','蜀國爆發',['劉備','關羽','張飛','趙雲','馬超','黃忠','鼓兵','箭手'],'高輸出與左右位置測試'),
            FairPreset('WU_FLOW','吳國聯動',['孫權','周瑜','大喬','小喬','孫堅','呂蒙','醫護兵','攻城兵'],'群體、治療與攻城測試'),
            FairPreset('SIEGE','攻城壓力',['孫堅','攻城兵','張遼','盾兵','鼓兵','箭手'],'空路打城與護線測試'),
        ]
        out=[]
        for x in raw:
            cards=[n for n in x.cards if n in names][:self.deck_size]
            if cards: out.append({'preset_id':x.preset_id,'name':x.name,'cards':cards,'note':x.note})
        return out
    def use_preset(self,preset_id:str,slot_id:int=1):
        rec=next((x for x in self.presets() if x['preset_id']==str(preset_id)),None)
        if not rec: raise ValueError('找不到推薦套牌')
        return self.save_deck(slot_id,rec['name'],rec['cards'],'FREE')

    def _card_score(self,c,smart:float):
        # Beta-only heuristic: card identity matters more than raw rarity, and better AI
        # extracts more value from targeting/roles rather than receiving stat cheats.
        atk=float(c.get('attack') or 0); hp=float(c.get('hp') or 0)
        q=str(c.get('quality') or '')
        qv=4 if '橙' in q else 3 if '紫' in q else 2 if '藍' in q else 1
        skills=c.get('skills') or []
        text=' '.join(str(s.get('text') or '') for s in skills)
        roles=' '.join((c.get('combat_profile') or {}).get('roles') or [(c.get('combat_profile') or {}).get('role','')])
        tactical=sum(k in text+roles for k in ['左右','全體','治療','嘲諷','攻城','控制','沉默','反擊','隨機','增攻','護'])
        return atk*.035+hp*.012+qv*2.2+len(skills)*1.2+tactical*(0.7+smart*0.45)
    def _synergy(self,deck,smart:float):
        text=' '.join((c.get('positioning') or '')+' '+' '.join((c.get('combat_profile') or {}).get('roles') or []) for c in deck)
        unique_roles=sum(k in text for k in ['坦','治療','控','攻城','輸出','輔','士兵'])
        factions=[c.get('faction') for c in deck if c.get('faction') not in ('士兵',None,'')]
        faction_bonus=max([factions.count(x) for x in set(factions)] or [0])*.45
        return (unique_roles*.55+faction_bonus)*(0.5+smart*.5)
    def _make_ai_deck(self,level:int):
        cards=self._cards(); smart=(level-1)/4
        # Lv1 mostly random; Lv5 samples many candidates and picks highest heuristic set.
        if level==1: return self.rng.sample(cards,min(self.deck_size,len(cards)))
        trials=4+level*6; best=None; bestv=-1
        for _ in range(trials):
            d=self.rng.sample(cards,min(self.deck_size,len(cards)))
            v=sum(self._card_score(c,smart) for c in d)+self._synergy(d,smart)+self.rng.random()*(6-level)
            if v>bestv: best,bestv=d,v
        return best or cards[:self.deck_size]
    def _resolve_once(self,player_names:List[str],level:int,seed_noise:float=1.0):
        by=self._by_name(); pd=[by[n] for n in player_names if n in by]
        if not pd: raise ValueError('目前測試牌組是空的')
        ai=self._make_ai_deck(level); smart=(level-1)/4
        p=sum(self._card_score(c,.72) for c in pd)+self._synergy(pd,.72)
        a=sum(self._card_score(c,smart) for c in ai)+self._synergy(ai,smart)
        # No AI stat bonus: difficulty affects selection quality/variance only.
        p+=self.rng.gauss(0,5.5*seed_noise); a+=self.rng.gauss(0,(7.0-level)*seed_noise)
        won=p>=a
        turns=max(3,min(20,int(11-abs(p-a)/8+self.rng.randint(-2,3))))
        gate=max(0,int(4200-max(0,a-p)*18-self.rng.randint(0,650))) if won else max(0,int(4200-max(0,p-a)*18-self.rng.randint(0,650)))
        return {'won':won,'turns':turns,'player_score':round(p,1),'ai_score':round(a,1),'ai_cards':[c['name'] for c in ai],'winner_gate_hp':gate}
    def run_ai_batch(self,count:int=1,level:int|None=None,slot_id:int|None=None):
        count=int(count)
        if count not in (1,5,10): raise ValueError('目前支援1／5／10場測試')
        lv=self.set_ai_level(level if level is not None else self.ai_level)
        sid=int(slot_id or self.active_slot); deck=self.saved_decks.get(sid) or {'cards':[]}
        if not deck['cards']:
            # first-use convenience: recommended deck, still fully editable afterwards
            p=self.presets()[0] if self.presets() else None
            if p: self.save_deck(sid,'首次測試牌組',p['cards'])
            deck=self.saved_decks[sid]
        rows=[self._resolve_once(deck['cards'],lv) for _ in range(count)]
        wins=sum(1 for x in rows if x['won'])
        report={'mode':'AI_PRACTICE','ai_level':lv,'matches':count,'wins':wins,'losses':count-wins,'win_rate':round(wins/count*100,1),'average_turns':round(statistics.mean(x['turns'] for x in rows),1),'deck':list(deck['cards']),'results':rows,'rule_note':'F3-E.2封測公平測試：AI難度改變決策品質，不額外加攻血作弊。'}
        self.last_batch=report; self.history.append({k:v for k,v in report.items() if k!='results'})
        self.history=self.history[-30:]
        return report
    def export(self): return {'saved_decks':self.saved_decks,'active_slot':self.active_slot,'ai_level':self.ai_level,'random_pool':self.random_pool,'pool_size':self.pool_size,'history':self.history,'last_batch':self.last_batch}
    def import_data(self,d):
        if not isinstance(d,dict): return
        for k,v in (d.get('saved_decks') or {}).items():
            try:self.saved_decks[int(k)]={'name':str(v.get('name') or f'測試牌組{k}'),'cards':[n for n in v.get('cards',[]) if n in self._by_name()]}
            except Exception: pass
        self.active_slot=max(1,min(3,int(d.get('active_slot',1)))); self.ai_level=max(1,min(5,int(d.get('ai_level',3))))
        pool=[n for n in d.get('random_pool',[]) if n in self._by_name()]
        if pool:self.random_pool=pool
        self.history=list(d.get('history') or [])[-30:]; self.last_batch=d.get('last_batch')
    def state(self):
        return {'version':'F3-H','beta_only':True,'ownership_required':False,'fair_standard':{'level':'FIXED_TEST_STANDARD','star':'ALL_SKILLS_ENABLED','equipment':'NORMALIZED','balance':'F3-G-v1','note':'封測公平規則；正式上線數值另行平衡'},'deck_size':self.deck_size,'pool_size':self.pool_size,'random_pool':list(self.random_pool),'saved_decks':self.saved_decks,'active_slot':self.active_slot,'ai_level':self.ai_level,'ai_levels':[
            {'level':1,'name':'新手','behavior':'基本出牌；位置判斷少'}, {'level':2,'name':'一般','behavior':'會看坦補與基本位置'}, {'level':3,'name':'進階','behavior':'會考慮左右、攻城與組合'}, {'level':4,'name':'高手','behavior':'會預判與保核心'}, {'level':5,'name':'戰術','behavior':'多方案比較；不加攻血作弊'}],
            'presets':self.presets(),'last_batch':self.last_batch,'history':list(self.history[-12:]),'live_pvp':{'status':'READY','note':'F3-H：6位房間碼／快速匹配／20秒伺服器計時／自動跳過／斷線回房已接線。'},
            'modes':[{'id':'FREE','name':'完全自由構築','ready':True},{'id':'RANDOM','name':'隨機卡池構築','ready':True},{'id':'RECOMMENDED','name':'推薦套牌','ready':True},{'id':'AI','name':'AI練習','ready':True},{'id':'LIVE','name':'真人公平對決','ready':True,'phase':'F3-H'}]}
