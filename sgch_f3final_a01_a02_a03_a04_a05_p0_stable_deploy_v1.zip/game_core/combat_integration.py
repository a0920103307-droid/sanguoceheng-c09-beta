from __future__ import annotations
from copy import deepcopy
from typing import Any, Dict, List


class F3ECombatIntegrationMixin:
    """F3-E combat integration layer.

    Keeps the restored/reconstructed six-lane rules in one place without hardcoding
    individual general names. It adds deterministic target selection helpers,
    position-aware telemetry, and battle metrics used by later fair-test/PVP modes.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.f3e_event_seq = 0
        self.f3e_timeline: List[Dict[str, Any]] = []
        self.f3e_metrics: Dict[str, Dict[str, int]] = {}
        self.f3e_rules = {
            'board_capacity': 6,
            'deployment': 'ORDERED_INSERT',
            'compaction': 'END_OF_TURN',
            'default_target': 'OPPOSITE_OR_GATE',
            'attack_order': 'LEFT_TO_RIGHT',
            'adjacency': 'PHYSICAL_LANE_CURRENT_TURN',
            'empty_opposite': 'ATTACK_GATE',
        }

    def _metric(self, name: str) -> Dict[str, int]:
        key = str(name or 'UNKNOWN')
        return self.f3e_metrics.setdefault(key, {
            'attacks': 0,
            'card_damage': 0,
            'gate_damage': 0,
            'healing': 0,
            'defeats_caused': 0,
            'defeated': 0,
            'deploys': 0,
            'skill_triggers': 0,
        })

    def _locate_by_name(self, name: str):
        for oi, p in enumerate(self.players):
            for si, c in enumerate(p.board):
                if c is not None and c.name == name:
                    return oi, si, c
        return None

    def emit(self, event: str, **ctx):
        # Record the event before downstream handlers mutate the board; this preserves
        # the lane/target snapshot that generated the event.
        self.f3e_event_seq += 1
        row = {'seq': self.f3e_event_seq, 'event': str(event), 'turn': int(getattr(self, 'turn', 0)), 'active': int(getattr(self, 'active', 0))}
        safe = {}
        for k, v in ctx.items():
            if hasattr(v, 'name'):
                safe[k] = getattr(v, 'name')
            elif isinstance(v, (str, int, float, bool)) or v is None:
                safe[k] = v
            else:
                safe[k] = repr(v)
        row['detail'] = safe
        self.f3e_timeline.append(row)
        if len(self.f3e_timeline) > 600:
            self.f3e_timeline = self.f3e_timeline[-600:]

        if event == 'ON_DEPLOY':
            card = ctx.get('card')
            if card is not None:
                self._metric(getattr(card, 'name', str(card)))['deploys'] += 1
        elif event == 'ON_ATTACK':
            self._metric(str(ctx.get('source', 'UNKNOWN')))['attacks'] += 1
        elif event == 'AFTER_DAMAGE':
            self._metric(str(ctx.get('source', 'UNKNOWN')))['card_damage'] += max(0, int(ctx.get('amount', 0) or 0))
        elif event == 'F3E_GATE_STRIKE':
            self._metric(str(ctx.get('source', 'UNKNOWN')))['gate_damage'] += max(0, int(ctx.get('amount', 0) or 0))
        elif event == 'HEAL_APPLIED':
            self._metric(str(ctx.get('source', 'UNKNOWN')))['healing'] += max(0, int(ctx.get('amount', 0) or 0))
        elif event == 'ON_DEFEAT':
            self._metric(str(ctx.get('card', 'UNKNOWN')))['defeated'] += 1
            src = ctx.get('source')
            if src:
                self._metric(str(src))['defeats_caused'] += 1
        return super().emit(event, **ctx)

    def _select(self, owner, source, selector, ctx):
        """Position-aware selectors used by the generic general skill compiler."""
        mine = [c for c in self.players[owner].board if c]
        enemy = [c for c in self.players[1-owner].board if c]
        selector = str(selector or 'SELF')
        if selector == 'SELF': return [source]
        if selector == 'ALLY_ALL': return mine
        if selector == 'ALLY_OTHERS': return [c for c in mine if c is not source]
        if selector == 'ALLY_RANDOM_OTHER':
            xs=[c for c in mine if c is not source]; return [self.rng.choice(xs)] if xs else []
        if selector in ('SELF_ADJACENT','ALLY_ADJACENT'):
            loc = self._find_card(source)
            if not loc: return [source] if selector == 'SELF_ADJACENT' else []
            lo, hi = loc[1]-1, loc[1]+1
            out=[]
            if selector == 'SELF_ADJACENT': out.append(source)
            for s in (lo, hi):
                if 0 <= s < len(self.players[owner].board):
                    c=self.players[owner].board[s]
                    if c is not None: out.append(c)
            return out
        if selector == 'OPPOSITE':
            loc=self._find_card(source)
            if not loc: return []
            c=self.players[1-owner].board[loc[1]]
            return [c] if c else []
        if selector == 'ATTACK_TARGET':
            obj=ctx.get('target_card')
            if obj is not None and obj in self.players[1-owner].board: return [obj]
            slot=ctx.get('target_slot')
            if isinstance(slot, int) and 0 <= slot < len(self.players[1-owner].board):
                c=self.players[1-owner].board[slot]
                if c is not None: return [c]
            name=ctx.get('target')
            xs=[c for c in enemy if c.name==name]
            return xs[:1]
        if selector == 'ENEMY_ALL': return enemy
        if selector == 'ENEMY_RANDOM': return [self.rng.choice(enemy)] if enemy else []
        if selector == 'ENEMY_LOWEST_HP': return [min(enemy,key=lambda c:c.hp)] if enemy else []
        if selector == 'ENEMY_HIGHEST_ATTACK': return [max(enemy,key=lambda c:c.attack)] if enemy else []
        if selector == 'ENEMY_LOWEST_ATTACK': return [min(enemy,key=lambda c:c.attack)] if enemy else []
        if selector in ('ALLY_EMPTY_SLOT','ENEMY_GATE'): return [None]
        # Preserve existing engine semantics for any future selector.
        return super()._select(owner, source, selector, ctx)

    def f3e_state(self) -> Dict[str, Any]:
        """Compact battle analytics snapshot for UI and later fair-test data capture."""
        return {
            'rules': dict(self.f3e_rules),
            'metrics': deepcopy(self.f3e_metrics),
            'timeline': deepcopy(self.f3e_timeline[-120:]),
        }
