from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional
import json
from .balance_c08 import stage_gate_hp

@dataclass(frozen=True)
class PlayableStage:
    stage_id: str
    order: int
    mode: str
    name: str
    food_cost: int
    victory_rule: str
    enemy_gate_hp: int
    fragment_drop: Optional[str]
    description: str
    source_layer: str='Temporary'
    unlock_after: Optional[str]=None
    first_clear: Dict[str,int]=field(default_factory=dict)
    star_conditions: tuple[str,...]=()

def playable_stages(pve_module)->List[PlayableStage]:
    path=Path(__file__).resolve().parent.parent/'b04_pve_catalog.json'
    doc=json.loads(path.read_text(encoding='utf-8'))
    out=[]
    for r in doc['stages']:
        src=r.get('identity_layer','Temporary')
        desc=(f"B04正式PVE路線第{r['order']}節；身份層={src}。"
              f"勝利規則/星級門檻屬 Temporary；敵城HP自C08起採 Balance C08-v1，碎片身份僅在標記 Original B 的節點視為原版證據。")
        out.append(PlayableStage(
            r['stage_id'],int(r['order']),r['mode'],r['name'],int(r['food_cost']),r['victory_rule'],
            stage_gate_hp(int(r['order'])),r.get('fragment_drop'),desc,src,r.get('unlock_after'),
            {str(k):int(v) for k,v in (r.get('first_clear') or {}).items()},tuple(r.get('star_conditions') or ())))
    return sorted(out,key=lambda s:s.order)

def legacy_stage(pve_module, s:PlayableStage):
    return pve_module.StageDef(
        s.stage_id,s.mode,s.name,s.food_cost,
        direct_gate_allowed=(s.victory_rule in ('STANDARD','GATE_ONLY')),
        fragment_drop=s.fragment_drop,symbol_drop=True,source_confidence=s.source_layer,
        enemy_gate_hp=s.enemy_gate_hp,notes=s.description,
    )

class PVEVictoryRuleMixin:
    victory_rule='STANDARD'
    def check_victory(self):
        if self.winner is not None:return self.winner
        rule=getattr(self,'victory_rule','STANDARD')
        if rule=='STANDARD':return super().check_victory()
        if rule=='GATE_ONLY':
            for i,p in enumerate(self.players):
                if p.gate_hp<=0:
                    self.winner=1-i; self.win_reason='GATE_DESTROYED'; return self.winner
            return None
        if rule=='ELIMINATION_ONLY':
            target='GENERAL'
            for i,p in enumerate(self.players):
                if p.ever_deployed_elimination_target:
                    alive=any(c is not None and c.kind==target for c in p.board)
                    if not alive:
                        self.winner=1-i; self.win_reason='ELIMINATION'; return self.winner
            return None
        return super().check_victory()
