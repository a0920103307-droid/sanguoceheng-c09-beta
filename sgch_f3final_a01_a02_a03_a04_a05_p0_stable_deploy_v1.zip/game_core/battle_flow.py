from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class BattleLoadout:
    """A02 battle resources. Names are legacy data keys; no Original values are overwritten."""
    book_name: str = "鬼谷子"
    command_name: str = "軍令重生"
    horse_name: str = "黑雲"
    armor_name: str = "鍛鋼鎧"


@dataclass
class BattleReport:
    winner: Optional[int]
    winner_name: Optional[str]
    reason: Optional[str]
    turns: int
    completed: bool
    gate_hp: List[int]
    retreat_counts: List[int]
    deck_counts: List[int]
    hand_counts: List[int]
    events: List[str] = field(default_factory=list)
    feature_usage: Dict[str, Any] = field(default_factory=dict)


class CompleteBattleRunner:
    """A02 orchestration layer over the A01 GameSession/legacy SoldierBattle.

    It supplies deterministic PLAYER/AI turn policies and battle loadouts, while all
    battle mutations are executed by the frozen Grid01-08 engines.
    """
    def __init__(self, session, *, max_turns: int = 120, loadouts: Optional[List[BattleLoadout]] = None):
        self.session = session
        self.battle = session.battle
        self.max_turns = int(max_turns)
        self.loadouts = loadouts or [BattleLoadout(), BattleLoadout()]
        self.used = [dict(book=False, command=False, horse=False, equipment=False) for _ in range(2)]
        self.events: List[str] = []
        self.session.metadata["battle_lifecycle_version"] = "A02"

    def _touch(self, reason: str, **detail):
        self.session.touch(reason, **detail)
        self.events.append(reason)

    def _prepare_demo_skills(self):
        # A02 needs the generic skill engine to participate in the lifecycle.
        # These are explicit Temporary runtime test effects, not Original character skills.
        for pi, p in enumerate(self.battle.players):
            for idx, c in enumerate(p.deck):
                if idx == 0:
                    c.effects = [{"trigger": "ON_DEPLOY", "type": "ADD_FIRE", "amount": 1,
                                  "layer": "TEMPORARY", "purpose": "A02_GENERIC_SKILL_PIPELINE"}]
                    break

    def opening(self, shuffle: bool = False):
        self._prepare_demo_skills()
        self.battle.opening(shuffle=shuffle)
        self._touch("a02_opening", opening_hands=[len(p.hand) for p in self.battle.players])

    def _empty_slot(self, owner: int) -> Optional[int]:
        return next((i for i, c in enumerate(self.battle.players[owner].board) if c is None), None)

    def _first_general(self, owner: int):
        return next((c for c in self.battle.players[owner].board if c is not None and c.kind == "GENERAL"), None)

    def _play_units(self, owner: int):
        p = self.battle.players[owner]
        # Spend available fire while there is space. Ignore tactic cards if any are generated.
        while p.fire > 0 and self.battle.winner is None:
            slot = self._empty_slot(owner)
            if slot is None:
                return
            hi = next((i for i, c in enumerate(p.hand) if getattr(c, "kind", None) in ("GENERAL", "SOLDIER")), None)
            if hi is None:
                return
            before = len(p.hand)
            self.battle.play(hi, slot)
            self._touch("a02_play", owner=owner, slot=slot)
            if self.battle.winner is not None:
                return
            if len(p.hand) >= before:  # defensive guard against a broken legacy adapter
                return

    def _use_support_systems(self, owner: int):
        target = self._first_general(owner)
        if target is None:
            return
        l = self.loadouts[owner]

        if not self.used[owner]["horse"]:
            existing = (getattr(target, "skill_state", {}) or {}).get("horse")
            if existing:
                self.used[owner]["horse"] = True
                self._touch("a02_horse_existing", owner=owner, target=target.name, horse=existing.get("name") if isinstance(existing, dict) else str(existing))
            else:
                self.battle.equip_horse(owner, target, l.horse_name, level=1)
                self.used[owner]["horse"] = True
                self._touch("a02_horse", owner=owner, target=target.name, horse=l.horse_name)

        if not self.used[owner]["equipment"]:
            eq = (getattr(target, "skill_state", {}) or {}).get("equipment", {})
            if isinstance(eq, dict) and any(eq.values()):
                self.used[owner]["equipment"] = True
                self._touch("a02_equipment_existing", owner=owner, target=target.name)
            else:
                self.battle.equip_equipment(owner, target, l.armor_name, star=1)
                self.used[owner]["equipment"] = True
                self._touch("a02_equipment", owner=owner, target=target.name, equipment=l.armor_name)

        if not self.used[owner]["book"]:
            result = self.battle.use_book(owner, l.book_name)
            if result.get("applied"):
                self.used[owner]["book"] = True
                self._touch("a02_book", owner=owner, book=l.book_name)

        if not self.used[owner]["command"]:
            result = self.battle.use_command(owner, l.command_name, target=target)
            if result.get("applied"):
                self.used[owner]["command"] = True
                self._touch("a02_command", owner=owner, command=l.command_name, target=target.name)

    def run(self, *, shuffle: bool = False) -> BattleReport:
        if self.battle.turn == 0 and not any(p.hand for p in self.battle.players):
            self.opening(shuffle=shuffle)

        while self.battle.winner is None and self.battle.turn < self.max_turns:
            owner = self.battle.active
            self.battle.start_turn()
            self._touch("a02_turn_start", owner=owner, turn=self.battle.turn)
            self._play_units(owner)
            if self.battle.winner is not None:
                break
            self._use_support_systems(owner)
            if self.battle.winner is not None:
                break
            self.battle.combat()
            self._touch("a02_combat", owner=owner, winner=self.battle.winner)

        completed = self.battle.winner is not None
        report = BattleReport(
            winner=self.battle.winner,
            winner_name=None if self.battle.winner is None else self.battle.players[self.battle.winner].name,
            reason=self.battle.win_reason,
            turns=self.battle.turn,
            completed=completed,
            gate_hp=[p.gate_hp for p in self.battle.players],
            retreat_counts=[len(p.retreat) for p in self.battle.players],
            deck_counts=[len(p.deck) for p in self.battle.players],
            hand_counts=[len(p.hand) for p in self.battle.players],
            events=list(self.events),
            feature_usage={
                "opening": True,
                "draw": any("ON_DRAW" in line for line in self.battle.log),
                "hand": True,
                "board_slots": [len(p.board) for p in self.battle.players],
                "fire": any("FIRE_CHANGED" in line for line in self.battle.log),
                "play": "a02_play" in self.events,
                "skill": any("A02_GENERIC_SKILL_PIPELINE" in repr(getattr(c, "effects", [])) for p in self.battle.players for c in (p.board + p.retreat + p.hand + p.deck) if c is not None),
                "horse": all(x["horse"] for x in self.used),
                "equipment": all(x["equipment"] for x in self.used),
                "book": all(x["book"] for x in self.used),
                "command": all(x["command"] for x in self.used),
                "retreat": sum(len(p.retreat) for p in self.battle.players) > 0,
                "gate": any("GATE_DAMAGED" in line for line in self.battle.log),
                "victory": completed,
            },
        )
        self._touch("a02_battle_finished" if completed else "a02_battle_timeout", turns=report.turns, win_reason=report.reason)
        return report
