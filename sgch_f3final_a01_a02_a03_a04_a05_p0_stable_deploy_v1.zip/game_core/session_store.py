from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Protocol


@dataclass(frozen=True)
class SessionRecord:
    token_hash: str
    player_id: str
    expires_at: int
    created_at: int


class SessionStoreError(RuntimeError):
    pass


class SessionStore(Protocol):
    backend_name: str

    def create(self, record: SessionRecord) -> None: ...
    def get(self, token_hash: str) -> Optional[SessionRecord]: ...
    def delete(self, token_hash: str) -> None: ...
    def delete_expired(self, now: int) -> int: ...


class SQLiteSessionStore:
    backend_name = "sqlite"

    def __init__(self, db_path: str | Path):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _db(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self._db() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS sessions(
                  token_hash TEXT PRIMARY KEY,
                  player_id TEXT NOT NULL,
                  expires_at INTEGER NOT NULL,
                  created_at INTEGER NOT NULL
                )
                """
            )
            con.execute("CREATE INDEX IF NOT EXISTS idx_sessions_player_id ON sessions(player_id)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at)")

    @staticmethod
    def _row(row) -> Optional[SessionRecord]:
        if row is None:
            return None
        return SessionRecord(
            token_hash=str(row["token_hash"]),
            player_id=str(row["player_id"]),
            expires_at=int(row["expires_at"]),
            created_at=int(row["created_at"]),
        )

    def create(self, record: SessionRecord) -> None:
        with self._db() as con:
            con.execute(
                "INSERT OR REPLACE INTO sessions(token_hash,player_id,expires_at,created_at) VALUES(?,?,?,?)",
                (record.token_hash, record.player_id, record.expires_at, record.created_at),
            )

    def get(self, token_hash: str) -> Optional[SessionRecord]:
        with self._db() as con:
            row = con.execute(
                "SELECT token_hash,player_id,expires_at,created_at FROM sessions WHERE token_hash=?",
                (token_hash,),
            ).fetchone()
        return self._row(row)

    def delete(self, token_hash: str) -> None:
        with self._db() as con:
            con.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash,))

    def delete_expired(self, now: int) -> int:
        with self._db() as con:
            cur = con.execute("DELETE FROM sessions WHERE expires_at<=?", (int(now),))
            return int(cur.rowcount or 0)


class PostgresSessionStore:
    backend_name = "postgres"

    def __init__(self, database_url: str):
        self.database_url = str(database_url or "").strip()
        if not self.database_url:
            raise SessionStoreError("PostgreSQL session backend requires DATABASE_URL")
        try:
            import psycopg  # type: ignore
        except ImportError as exc:
            raise SessionStoreError(
                "PostgreSQL session backend requires psycopg; install requirements.txt"
            ) from exc
        self._psycopg = psycopg
        self._init()

    def _db(self):
        return self._psycopg.connect(self.database_url)

    def _init(self):
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS auth_sessions(
                      token_hash VARCHAR(64) PRIMARY KEY,
                      player_id VARCHAR(40) NOT NULL,
                      expires_at BIGINT NOT NULL,
                      created_at BIGINT NOT NULL
                    )
                    """
                )
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_auth_sessions_player_id ON auth_sessions(player_id)"
                )
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_auth_sessions_expires_at ON auth_sessions(expires_at)"
                )

    @staticmethod
    def _record(row) -> Optional[SessionRecord]:
        if row is None:
            return None
        return SessionRecord(
            token_hash=str(row[0]),
            player_id=str(row[1]),
            expires_at=int(row[2]),
            created_at=int(row[3]),
        )

    def create(self, record: SessionRecord) -> None:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO auth_sessions(token_hash,player_id,expires_at,created_at)
                    VALUES(%s,%s,%s,%s)
                    ON CONFLICT(token_hash) DO UPDATE SET
                      player_id=EXCLUDED.player_id,
                      expires_at=EXCLUDED.expires_at,
                      created_at=EXCLUDED.created_at
                    """,
                    (record.token_hash, record.player_id, record.expires_at, record.created_at),
                )

    def get(self, token_hash: str) -> Optional[SessionRecord]:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    "SELECT token_hash,player_id,expires_at,created_at FROM auth_sessions WHERE token_hash=%s",
                    (token_hash,),
                )
                row = cur.fetchone()
        return self._record(row)

    def delete(self, token_hash: str) -> None:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute("DELETE FROM auth_sessions WHERE token_hash=%s", (token_hash,))

    def delete_expired(self, now: int) -> int:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute("DELETE FROM auth_sessions WHERE expires_at<=%s", (int(now),))
                return int(cur.rowcount or 0)


def build_session_store(sqlite_path: str | Path) -> SessionStore:
    """Build the A02 session backend.

    Default follows SGCH_AUTH_BACKEND so a production switch can move account and
    session persistence together. SGCH_SESSION_BACKEND may override it explicitly.
    PostgreSQL URL priority: SGCH_SESSION_DATABASE_URL, SGCH_AUTH_DATABASE_URL,
    then Render's DATABASE_URL.
    """

    backend = (
        os.getenv("SGCH_SESSION_BACKEND")
        or os.getenv("SGCH_AUTH_BACKEND")
        or "sqlite"
    ).strip().lower()
    if backend == "sqlite":
        return SQLiteSessionStore(sqlite_path)
    if backend == "postgres":
        url = (
            os.getenv("SGCH_SESSION_DATABASE_URL")
            or os.getenv("SGCH_AUTH_DATABASE_URL")
            or os.getenv("DATABASE_URL")
            or ""
        ).strip()
        return PostgresSessionStore(url)
    raise SessionStoreError("SGCH_SESSION_BACKEND must be sqlite or postgres")
