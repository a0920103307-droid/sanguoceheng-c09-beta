from __future__ import annotations
from datetime import date
import json
from pathlib import Path
from typing import Any, Callable, Dict
from .balance_c08 import value as c08_value
from .progression_runtime import GeneralGrowth

BASE=Path(__file__).resolve().parent.parent
CATALOG=json.loads((BASE/'b06_economy_catalog.json').read_text(encoding='utf-8'))
F3F=json.loads((BASE/'config'/'f3f_economy.json').read_text(encoding='utf-8'))

class EconomyController:
    def __init__(self, growth, collection, campaign, today_provider:Callable[[],str]|None=None):
        self.growth=growth; self.collection=collection; self.campaign=campaign
        self.today_provider=today_provider or (lambda: date.today().isoformat())
        self.last_daily_claim=''; self.history=[]
        self.claimed_welfare=set(); self.claimed_level_gifts=set(); self.claimed_seven_day=set(); self.redeemed_codes=set()
        self.purchase_log=[]; self.redeem_log=[]; self.synthesis_log=[]
        self.growth.roster.resources.setdefault('將魂',0); self.growth.roster.resources.setdefault('軍令資源',0)
    def _today(self): return str(self.today_provider())
    def _get(self,name:str)->int:
        if name=='元寶': return int(self.collection.engine.state.yuanbao)
        if name=='招募令': return int(self.collection.recruit_tickets)
        if name=='糧草': return int(self.campaign.state.food)
        if name=='掃蕩卡': return int(self.campaign.state.sweep_cards)
        return int(self.growth.roster.resources.get(name,0))
    def _set(self,name:str,value:int):
        value=max(0,int(value))
        if name=='元寶': self.collection.engine.state.yuanbao=value
        elif name=='招募令': self.collection.recruit_tickets=value
        elif name=='糧草': self.campaign.state.food=value
        elif name=='掃蕩卡': self.campaign.state.sweep_cards=value
        else: self.growth.roster.resources[name]=value
    def _add(self,name:str,qty:int): self._set(name,self._get(name)+int(qty))
    def _grant(self,rewards:Dict[str,int]):
        for k,v in rewards.items(): self._add(str(k),int(v))
    def balances(self)->Dict[str,int]:
        keys=['銀幣','元寶','招募令','武將經驗','進化丹','兵符','馬糧','鍛造石','兵書殘頁','掃蕩卡','糧草','將魂','軍令資源']
        base={k:self._get(k) for k in keys}
        for k,v in self.growth.roster.resources.items():
            if str(k).endswith('碎片'): base[str(k)]=int(v)
        return base
    def claim_daily_supply(self)->Dict[str,Any]:
        today=self._today()
        if self.last_daily_claim==today: raise ValueError('今日循環補給已領取')
        x=c08_value('economy.outputs')['daily_supply']; rewards={'元寶':int(x['yuanbao']),'招募令':int(x['ticket']),'糧草':int(x['food']),'掃蕩卡':int(x['sweep'])}
        self._grant(rewards); self.last_daily_claim=today
        r={'action':'DAILY_SUPPLY','day':today,'rewards':rewards,'layer':'BALANCE_C08'}; self.history.append(r); return r
    def exchange(self,exchange_id:str)->Dict[str,Any]:
        rec=next((x for x in CATALOG['temporary_exchanges'] if x['exchange_id']==str(exchange_id)),None)
        if not rec: raise ValueError('未知資源兌換')
        for k,v in rec['pay'].items():
            if self._get(k)<int(v): raise ValueError(f'資源不足：{k} 需要 {v}')
        for k,v in rec['pay'].items(): self._add(k,-int(v))
        self._grant(rec['receive']); r={'action':'EXCHANGE','exchange_id':rec['exchange_id'],'pay':dict(rec['pay']),'receive':dict(rec['receive']),'layer':'TEMPORARY'}; self.history.append(r); return r
    def buy(self,item_id:str):
        rec=next((x for x in F3F['shop_items'] if x['id']==str(item_id)),None)
        if not rec: raise ValueError('未知商城商品')
        cur=rec['currency']; price=int(rec['price'])
        if self._get(cur)<price: raise ValueError(f'{cur}不足：需要 {price}')
        self._add(cur,-price); self._grant(rec['grant'])
        r={'action':'SHOP_BUY','item_id':rec['id'],'name':rec['name'],'paid':{cur:price},'grant':dict(rec['grant']),'layer':'CLOSED_BETA_PRICE'}
        self.purchase_log.append(r); self.history.append(r); return r
    def claim_beta_start(self):
        key='beta_start'
        if key in self.claimed_welfare: raise ValueError('封測初始資源包已領取')
        rewards=dict(F3F['welfare']['beta_start']['rewards']); self._grant(rewards); self.claimed_welfare.add(key)
        r={'action':'BETA_START_PACK','rewards':rewards,'layer':'CLOSED_BETA_WELFARE'}; self.history.append(r); return r
    def claim_level_gift(self,level:int):
        level=int(level); key=str(level); gifts=F3F['welfare']['level_gifts']
        if key not in gifts: raise ValueError('此等級沒有封測禮包')
        if int(self.growth.roster.account_level)<level: raise ValueError(f'主公等級需達 Lv.{level}')
        if key in self.claimed_level_gifts: raise ValueError('此等級禮包已領取')
        rewards=dict(gifts[key]); self._grant(rewards); self.claimed_level_gifts.add(key)
        r={'action':'LEVEL_GIFT','level':level,'rewards':rewards,'layer':'CLOSED_BETA_WELFARE'}; self.history.append(r); return r
    def claim_seven_day(self,day:int):
        day=int(day); rec=next((x for x in F3F['welfare']['seven_day'] if int(x['day'])==day),None)
        if not rec: raise ValueError('不存在此簽到日')
        if day in self.claimed_seven_day: raise ValueError('此封測簽到已領取')
        rewards=dict(rec['rewards']); self._grant(rewards); self.claimed_seven_day.add(day)
        r={'action':'SEVEN_DAY','day':day,'rewards':rewards,'layer':'CLOSED_BETA_WELFARE'}; self.history.append(r); return r
    def redeem(self,code:str):
        code=str(code or '').strip().upper(); rec=F3F['redeem_codes'].get(code)
        if not rec: raise ValueError('兌換碼不存在或已停用')
        if code in self.redeemed_codes: raise ValueError('此帳號已兌換過此兌換碼')
        rewards=dict(rec['rewards']); self._grant(rewards); self.redeemed_codes.add(code)
        r={'action':'REDEEM','code':code,'rewards':rewards,'day':self._today(),'layer':'CLOSED_BETA_CODE'}; self.redeem_log.append(r); self.history.append(r); return r
    def synthesize_general(self,name:str):
        name=str(name); c=self.collection.by_name.get(name)
        if not c or str(c.get('card_type') or 'GENERAL').upper()!='GENERAL': raise ValueError('未知武將')
        cid=c['card_id']
        if cid in self.collection.engine.state.owned: raise ValueError('已擁有此武將')
        required=int(F3F['fragment_synthesis']['default_required']); key=f'{name}碎片'; have=max(self._get(key),int(self.collection.engine.state.fragments.get(cid,0)))
        if have<required: raise ValueError(f'{name}碎片不足：需要 {required}')
        remain=have-required; self.collection.engine.state.fragments[cid]=remain; self._set(key,remain); self.collection.engine.state.owned[cid]=1
        if name not in self.growth.roster.generals: self.growth.roster.generals[name]=GeneralGrowth(name=name,quality=c.get('quality') or '橙')
        r={'action':'FRAGMENT_SYNTHESIS','name':name,'required':required,'remaining':remain,'layer':'ORIGINAL_MECHANISM_BETA_THRESHOLD'}; self.synthesis_log.append(r); self.history.append(r); return r
    def export(self):
        return {'last_daily_claim':self.last_daily_claim,'history':list(self.history[-100:]),'claimed_welfare':sorted(self.claimed_welfare),'claimed_level_gifts':sorted(self.claimed_level_gifts),'claimed_seven_day':sorted(self.claimed_seven_day),'redeemed_codes':sorted(self.redeemed_codes),'purchase_log':self.purchase_log[-100:],'redeem_log':self.redeem_log[-100:],'synthesis_log':self.synthesis_log[-100:]}
    def import_data(self,data):
        data=data or {}; self.last_daily_claim=str(data.get('last_daily_claim') or ''); self.history=list(data.get('history') or [])[-100:]
        self.claimed_welfare=set(data.get('claimed_welfare') or []); self.claimed_level_gifts=set(str(x) for x in (data.get('claimed_level_gifts') or [])); self.claimed_seven_day=set(int(x) for x in (data.get('claimed_seven_day') or [])); self.redeemed_codes=set(str(x) for x in (data.get('redeemed_codes') or [])); self.purchase_log=list(data.get('purchase_log') or [])[-100:]; self.redeem_log=list(data.get('redeem_log') or [])[-100:]; self.synthesis_log=list(data.get('synthesis_log') or [])[-100:]
    def state(self):
        families=[dict(x) for x in CATALOG['resource_families']]
        exchanges=[]
        for x in CATALOG['temporary_exchanges']:
            y=dict(x); y['affordable']=all(self._get(k)>=int(v) for k,v in x['pay'].items()); exchanges.append(y)
        shop=[]
        for x in F3F['shop_items']:
            y=dict(x); y['affordable']=self._get(x['currency'])>=int(x['price']); shop.append(y)
        lv=int(self.growth.roster.account_level); level_gifts=[]
        for k,rewards in F3F['welfare']['level_gifts'].items(): level_gifts.append({'level':int(k),'rewards':dict(rewards),'unlocked':lv>=int(k),'claimed':str(k) in self.claimed_level_gifts})
        synth=[]
        required=int(F3F['fragment_synthesis']['default_required'])
        for x in self.collection.state()['collection']:
            if x.get('card_type')=='GENERAL' and not x.get('owned') and int(x.get('fragments',0))>0: synth.append({'name':x['name'],'fragments':int(x['fragments']),'required':required,'can_synthesize':int(x['fragments'])>=required})
        return {'version':'F3-F','day':self._today(),'disclaimer':F3F['disclaimer'],'daily_claimed':self.last_daily_claim==self._today(),'daily_supply':dict(CATALOG['temporary_daily_supply']),'balances':self.balances(),'resource_families':families,'exchanges':exchanges,'shop':shop,'welfare':{'beta_start_claimed':'beta_start' in self.claimed_welfare,'beta_start_rewards':dict(F3F['welfare']['beta_start']['rewards']),'level_gifts':level_gifts,'seven_day':[{'day':int(x['day']),'rewards':dict(x['rewards']),'claimed':int(x['day']) in self.claimed_seven_day} for x in F3F['welfare']['seven_day']]},'redeem':{'available_codes':sorted(F3F['redeem_codes'].keys()),'claimed':sorted(self.redeemed_codes),'note':'封測兌換碼；每帳號每碼限領一次。'},'fragment_synthesis':{'required':required,'candidates':synth,'note':F3F['fragment_synthesis']['note']},'logs':{'purchase':self.purchase_log[-20:],'redeem':self.redeem_log[-20:],'synthesis':self.synthesis_log[-20:]},'original_rules':{'tavern_full_card_and_fragments':True,'duplicate_to_fragments':True,'fragment_to_general':True,'first_tavern_draw_orange':True,'exact_rates_prices_pity':'UNCONFIRMED'},'loop_status':{'acquire_consume_grow_reacquire':True,'beta_closed_loop':True,'planned_locked':['神符','萬能將魂完整轉換規則']},'history':list(self.history[-15:])}
