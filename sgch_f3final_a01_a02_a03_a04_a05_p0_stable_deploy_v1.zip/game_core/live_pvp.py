from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import random, threading, time


@dataclass
class LiveRoom:
    code: str
    created_at: float
    players: List[Dict[str, Any]] = field(default_factory=list)
    ready: Dict[str, List[str]] = field(default_factory=dict)
    session: Any = None
    status: str = 'WAITING'  # WAITING / ACTIVE / FINISHED / CLOSED
    deadline: float = 0.0
    action_seconds: int = 20
    last_seen: Dict[str, float] = field(default_factory=dict)
    timeout_streak: Dict[str, int] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    seq: int = 0
    winner_player_id: Optional[str] = None
    win_reason: Optional[str] = None


class LivePVPManager:
    """F3-H server-authoritative realtime fair-PVP coordinator.

    Transport is short polling over the existing HTTP server so it works in the
    browser/PWA baseline without adding a websocket dependency. The battle engine
    remains authoritative on the server; clients only send intent.
    """
    def __init__(self, core, *, action_seconds: int = 20, reconnect_grace: int = 60):
        self.core = core
        self.action_seconds = int(action_seconds)
        self.reconnect_grace = int(reconnect_grace)
        self.rooms: Dict[str, LiveRoom] = {}
        self.player_room: Dict[str, str] = {}
        self.quick_waiting: Optional[str] = None
        self.lock = threading.RLock()
        self.rng = random.Random(309)

    def _now(self): return time.time()

    def _event(self, room: LiveRoom, typ: str, **detail):
        room.seq += 1
        row = {'seq': room.seq, 'type': typ, 'at': round(self._now(), 3), 'detail': detail}
        room.events.append(row)
        room.events[:] = room.events[-120:]
        return row

    def _new_code(self) -> str:
        for _ in range(200):
            code = f'{self.rng.randint(100000,999999)}'
            if code not in self.rooms or self.rooms[code].status == 'CLOSED':
                return code
        raise RuntimeError('暫時無法建立房間碼')

    def _player(self, identity):
        return {'player_id': identity.player_id, 'username': identity.username, 'is_guest': bool(identity.is_guest)}

    def _room_for(self, player_id: str) -> Optional[LiveRoom]:
        code = self.player_room.get(player_id)
        return self.rooms.get(code) if code else None

    def _touch(self, room: LiveRoom, player_id: str):
        room.last_seen[player_id] = self._now()

    def _join(self, room: LiveRoom, identity):
        pid = identity.player_id
        if any(p['player_id'] == pid for p in room.players):
            self.player_room[pid] = room.code
            self._touch(room, pid)
            return
        if len(room.players) >= 2 or room.status not in ('WAITING',):
            raise ValueError('房間已滿或對戰已開始')
        room.players.append(self._player(identity))
        self.player_room[pid] = room.code
        self._touch(room, pid)
        room.timeout_streak[pid] = 0
        self._event(room, 'PLAYER_JOINED', player_id=pid, username=identity.username)

    def create_room(self, identity):
        with self.lock:
            old = self._room_for(identity.player_id)
            if old and old.status in ('WAITING','ACTIVE'):
                return self.state(identity)
            code = self._new_code()
            room = LiveRoom(code=code, created_at=self._now(), action_seconds=self.action_seconds)
            self.rooms[code] = room
            self._join(room, identity)
            self._event(room, 'ROOM_CREATED', code=code)
            return self.state(identity)

    def join_room(self, identity, code: str):
        with self.lock:
            code = ''.join(ch for ch in str(code or '') if ch.isdigit())[:6]
            room = self.rooms.get(code)
            if not room or room.status == 'CLOSED': raise ValueError('找不到房間')
            old = self._room_for(identity.player_id)
            if old and old.code != code and old.status in ('WAITING','ACTIVE'):
                raise ValueError('你目前已在另一個對戰房間')
            self._join(room, identity)
            return self.state(identity)

    def quick_match(self, identity):
        with self.lock:
            current = self._room_for(identity.player_id)
            if current and current.status in ('WAITING','ACTIVE'):
                return self.state(identity)
            if self.quick_waiting:
                room = self.rooms.get(self.quick_waiting)
                if room and room.status == 'WAITING' and len(room.players) == 1 and room.players[0]['player_id'] != identity.player_id:
                    self._join(room, identity)
                    self.quick_waiting = None
                    self._event(room, 'QUICK_MATCH_PAIRED')
                    return self.state(identity)
                self.quick_waiting = None
            st = self.create_room(identity)
            self.quick_waiting = st['room_code']
            room = self.rooms[self.quick_waiting]
            self._event(room, 'QUICK_MATCH_WAITING')
            return self.state(identity)

    def ready(self, identity, deck_names: List[str]):
        with self.lock:
            room = self._room_for(identity.player_id)
            if not room: raise ValueError('請先建立或加入房間')
            if room.status != 'WAITING': raise ValueError('目前不能變更準備狀態')
            names=[]
            for x in list(deck_names or []):
                n=str(x)
                if n and n not in names: names.append(n)
            if not names: raise ValueError('公平對戰牌組至少需要1張卡')
            if len(names)>8: raise ValueError('公平對戰牌組最多8張')
            room.ready[identity.player_id] = names
            self._touch(room, identity.player_id)
            self._event(room, 'PLAYER_READY', player_id=identity.player_id, cards=len(names))
            if len(room.players)==2 and all(p['player_id'] in room.ready for p in room.players):
                self._start(room)
            return self.state(identity)

    def _start(self, room: LiveRoom):
        p0,p1=room.players
        d0=room.ready[p0['player_id']]; d1=room.ready[p1['player_id']]
        seed=self.rng.randint(1,10_000_000)
        session=self.core.create_session(seed=seed, player_names=(p0['username'],p1['username']), deck_names=d0, enemy_deck_names=d1, victory_rule='STANDARD')
        session.battle.opening(shuffle=True)
        session.battle.start_turn()
        room.session=session; room.status='ACTIVE'; room.deadline=self._now()+room.action_seconds
        room.timeout_streak[p0['player_id']]=0; room.timeout_streak[p1['player_id']]=0
        self._event(room,'MATCH_STARTED', first_player=p0['player_id'], action_seconds=room.action_seconds)

    def _active_pid(self, room: LiveRoom) -> Optional[str]:
        if room.status!='ACTIVE' or not room.session: return None
        idx=int(room.session.battle.active)
        return room.players[idx]['player_id'] if idx < len(room.players) else None

    def _finish_from_engine(self, room: LiveRoom):
        b=room.session.battle
        if b.winner is None: return False
        room.status='FINISHED'
        room.winner_player_id=room.players[int(b.winner)]['player_id']
        room.win_reason=b.win_reason
        room.deadline=0
        self._event(room,'MATCH_FINISHED',winner_player_id=room.winner_player_id,reason=room.win_reason)
        return True

    def _end_turn(self, room: LiveRoom, *, timeout=False):
        if room.status!='ACTIVE' or not room.session: return
        active_pid=self._active_pid(room)
        room.session.battle.combat()
        self._event(room,'TURN_ENDED',player_id=active_pid,timeout=bool(timeout))
        if timeout and active_pid:
            room.timeout_streak[active_pid]=room.timeout_streak.get(active_pid,0)+1
        elif active_pid:
            room.timeout_streak[active_pid]=0
        if self._finish_from_engine(room): return
        # Three consecutive inactivity turns forfeits the match; this provides a
        # reconnect window while preventing a dead room from hanging forever.
        if active_pid and room.timeout_streak.get(active_pid,0)>=3:
            loser_idx=next((i for i,p in enumerate(room.players) if p['player_id']==active_pid),0)
            winner_idx=1-loser_idx
            room.status='FINISHED'; room.winner_player_id=room.players[winner_idx]['player_id']; room.win_reason='INACTIVITY_FORFEIT'; room.deadline=0
            self._event(room,'MATCH_FINISHED',winner_player_id=room.winner_player_id,reason=room.win_reason)
            return
        room.session.battle.start_turn()
        room.deadline=self._now()+room.action_seconds
        self._event(room,'TURN_STARTED',player_id=self._active_pid(room),turn=room.session.battle.turn)

    def _tick(self, room: LiveRoom):
        if room.status=='ACTIVE' and room.deadline and self._now() >= room.deadline:
            self._end_turn(room,timeout=True)

    def play(self, identity, hand_index:int, slot:int):
        with self.lock:
            room=self._room_for(identity.player_id)
            if not room: raise ValueError('目前沒有真人對戰')
            self._tick(room)
            if room.status!='ACTIVE': return self.state(identity)
            if self._active_pid(room)!=identity.player_id: raise ValueError('現在不是你的操作回合')
            room.session.battle.play(int(hand_index),int(slot))
            self._touch(room,identity.player_id); self._event(room,'CARD_DEPLOYED',player_id=identity.player_id,slot=int(slot))
            self._finish_from_engine(room)
            return self.state(identity)

    def end_turn(self, identity):
        with self.lock:
            room=self._room_for(identity.player_id)
            if not room: raise ValueError('目前沒有真人對戰')
            self._tick(room)
            if room.status!='ACTIVE': return self.state(identity)
            if self._active_pid(room)!=identity.player_id: raise ValueError('現在不是你的操作回合')
            self._touch(room,identity.player_id); self._end_turn(room,timeout=False)
            return self.state(identity)

    def forfeit(self, identity):
        with self.lock:
            room=self._room_for(identity.player_id)
            if not room: raise ValueError('目前沒有真人對戰')
            if len(room.players)==2 and room.status in ('WAITING','ACTIVE'):
                winner=next((p['player_id'] for p in room.players if p['player_id']!=identity.player_id),None)
                room.status='FINISHED'; room.winner_player_id=winner; room.win_reason='FORFEIT'; room.deadline=0
                self._event(room,'MATCH_FINISHED',winner_player_id=winner,reason='FORFEIT')
            return self.state(identity)

    def leave(self, identity):
        with self.lock:
            room=self._room_for(identity.player_id)
            if not room: return {'connected':False,'status':'NONE'}
            pid=identity.player_id
            if room.status=='ACTIVE' and len(room.players)==2:
                self.forfeit(identity)
            self.player_room.pop(pid,None)
            if room.status=='WAITING':
                room.players=[p for p in room.players if p['player_id']!=pid]
                room.ready.pop(pid,None)
                if not room.players:
                    room.status='CLOSED'
                    if self.quick_waiting==room.code:self.quick_waiting=None
            self._event(room,'PLAYER_LEFT',player_id=pid)
            return {'connected':False,'status':'NONE'}

    def _card(self,c):
        if c is None:return None
        ss=getattr(c,'skill_state',{}) or {}
        return {'name':c.name,'kind':c.kind,'attack':int(c.attack),'hp':int(c.hp),'max_hp':int(c.max_hp),'horse':ss.get('horse'),'equipment':ss.get('equipment')}

    def _battle_state(self, room:LiveRoom, viewer_pid:str):
        b=room.session.battle
        vi=next((i for i,p in enumerate(room.players) if p['player_id']==viewer_pid),0); oi=1-vi
        me,op=b.players[vi],b.players[oi]
        active_pid=self._active_pid(room)
        return {
            'turn':int(b.turn),'active_player_id':active_pid,'your_turn':active_pid==viewer_pid,
            'seconds_left':max(0,int(room.deadline-self._now()+0.999)) if room.deadline else 0,
            'action_seconds':room.action_seconds,'fire':int(me.fire),'opponent_fire':int(op.fire),
            'your_gate_hp':int(me.gate_hp),'opponent_gate_hp':int(op.gate_hp),
            'your_board':[self._card(c) for c in me.board],'opponent_board':[self._card(c) for c in op.board],
            'hand':[self._card(c) for c in me.hand],'opponent_hand_count':len(op.hand),
            'deck_count':len(me.deck),'opponent_deck_count':len(op.deck),'retreat_count':len(me.retreat),'opponent_retreat_count':len(op.retreat),
            'winner_player_id':room.winner_player_id,'win_reason':room.win_reason,
            'rules':{'lanes':6,'deployment':'ORDERED_INSERT','compaction':'END_OF_TURN','target':'OPPOSITE_OR_GATE','timeout':'AUTO_END_TURN','timeout_forfeit_after':3},
            'log':list(getattr(b,'log',[])[-50:]),'analytics':b.f3e_state() if hasattr(b,'f3e_state') else {},
        }

    def state(self, identity):
        with self.lock:
            room=self._room_for(identity.player_id)
            if not room:return {'connected':False,'status':'NONE','version':'F3-H'}
            self._touch(room,identity.player_id); self._tick(room)
            players=[]
            for p in room.players:
                pid=p['player_id']; players.append({**p,'ready':pid in room.ready,'online_recently':(self._now()-room.last_seen.get(pid,0))<self.reconnect_grace})
            out={'connected':True,'version':'F3-H','room_code':room.code,'status':room.status,'players':players,'you':identity.player_id,'action_seconds':room.action_seconds,'events':list(room.events[-30:]),'winner_player_id':room.winner_player_id,'win_reason':room.win_reason,'reconnect_grace_seconds':self.reconnect_grace}
            if room.status in ('ACTIVE','FINISHED') and room.session:
                out['battle']=self._battle_state(room,identity.player_id)
            return out
