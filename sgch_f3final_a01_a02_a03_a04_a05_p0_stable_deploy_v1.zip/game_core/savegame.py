from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Optional
import copy, json, os, shutil, tempfile, time

SAVE_SCHEMA = "sgch.savegame"
CURRENT_SAVE_VERSION = 7
CURRENT_GAME_VERSION = "0.3-B06"

class SaveGameError(RuntimeError):
    pass

class SaveMigrationError(SaveGameError):
    pass


def _int_dict(value: Any) -> Dict[str, int]:
    if not isinstance(value, dict):
        return {}
    out={}
    for k,v in value.items():
        try: out[str(k)] = int(v)
        except Exception: continue
    return out


def _as_list(value: Any):
    return list(value) if isinstance(value, (list, tuple, set)) else []


def migrate_save(data: Dict[str, Any]) -> Dict[str, Any]:
    """Migrate v0.2-era/transitional saves into the B01 v3 schema.

    Accepted inputs:
      - schema v1/v2 save payloads
      - an A10 controller.state() snapshot (no schema/version)
      - current v3 payload (returned normalized)
    """
    if not isinstance(data, dict):
        raise SaveMigrationError("存檔根節點必須是 JSON object")
    src=copy.deepcopy(data)

    if src.get("schema") == SAVE_SCHEMA:
        version=int(src.get("save_version", 1))
        payload=src.get("payload", {})
    else:
        # v0.2 had no permanent-save schema. Treat a controller state export as v0 legacy input.
        version=0
        payload=src.get("payload", src)

    if version > CURRENT_SAVE_VERSION:
        raise SaveMigrationError(f"存檔版本 {version} 高於目前可讀版本 {CURRENT_SAVE_VERSION}")

    if version == 0:
        collection=payload.get("collection", {}) if isinstance(payload.get("collection"), dict) else {}
        growth=payload.get("growth", {}) if isinstance(payload.get("growth"), dict) else {}
        pve={
            "food": payload.get("food", 100),
            "sweep_cards": payload.get("sweep_cards", 10),
            "sweep_used_today": payload.get("sweep_used_today", 0),
            "inventory": payload.get("inventory", {}),
            "cleared": [x.get("stage_id") for x in payload.get("stages", []) if isinstance(x,dict) and x.get("cleared")],
        }
        owned={x.get("card_id"):1 for x in collection.get("collection",[]) if isinstance(x,dict) and x.get("owned") and x.get("card_id")}
        fragments={x.get("card_id"):x.get("fragments",0) for x in collection.get("collection",[]) if isinstance(x,dict) and x.get("card_id")}
        payload={
            "profile":{"screen":payload.get("screen","MAIN"),"selected_stage_id":(payload.get("selected_stage") or {}).get("stage_id") if isinstance(payload.get("selected_stage"),dict) else None},
            "pve":pve,
            "tavern":{
                "version":"HAOLING_2016",
                "owned":owned,
                "fragments":fragments,
                "first_tavern_draw_done":collection.get("first_draw_done",False),
                "draw_count":collection.get("draw_count",0),
                "recruit_tickets":collection.get("recruit_tickets",30),
                "lineup":collection.get("lineup",["張遼"]),
                "last_recruit":collection.get("last_recruit"),
            },
            "growth":growth,
        }
        version=1

    if version == 1:
        payload.setdefault("meta", {})
        payload["meta"].setdefault("source", "v0.2-migration")
        payload.setdefault("player_resources", {})
        version=2

    if version == 2:
        # v3 makes equipment/horse/book ownership explicit and reserves extensible subsystem slots.
        growth=payload.setdefault("growth", {})
        payload.setdefault("loadout", {
            "owned_equipment": growth.get("owned_equipment", {}),
            "owned_horses": growth.get("owned_horses", {}),
            "owned_books": growth.get("owned_books", {}),
        })
        payload.setdefault("subsystems", {})
        version=3

    if version == 3:
        # B03 introduces formal multi-deck data. Legacy lineup is preserved in slot 1
        # but does not activate formal mode until the player explicitly saves/selects it.
        tavern=payload.setdefault("tavern", {})
        legacy_lineup=list(tavern.get("lineup") or ["張遼"])
        payload.setdefault("decks", {
            "formal_active": False,
            "active_slot_id": 1,
            "slots": [
                {"slot_id":1,"name":"舊版編隊","cards":legacy_lineup},
                {"slot_id":2,"name":"牌組二","cards":legacy_lineup[:]},
                {"slot_id":3,"name":"牌組三","cards":legacy_lineup[:]},
            ],
        })
        version=4

    if version == 4:
        # B04 persists campaign star ratings and first-clear claims.
        pve=payload.setdefault("pve", {})
        pve.setdefault("stage_stars", {})
        pve.setdefault("first_clear_claimed", [])
        version=5

    if version == 5:
        # B05 persists daily dungeon attempts. Day rollover is handled by the dungeon controller.
        payload.setdefault("dungeons", {"day": "", "runs": {}, "history": [], "player_level": 20})
        version=6

    if version == 6:
        # B06 persists the economy hub daily claim/history while balances remain in their existing authoritative stores.
        payload.setdefault("economy", {"last_daily_claim":"", "history":[]})
        version=7

    now=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    return {
        "schema": SAVE_SCHEMA,
        "save_version": CURRENT_SAVE_VERSION,
        "game_version": CURRENT_GAME_VERSION,
        "saved_at": src.get("saved_at", now),
        "migrated_from": int(src.get("save_version", 0)) if src.get("schema") == SAVE_SCHEMA else "v0.2-state",
        "payload": payload,
    }


class SaveGameManager:
    def __init__(self, save_path: str | Path):
        self.path=Path(save_path)
        self.backup_path=self.path.with_suffix(self.path.suffix + ".bak")
        self.corrupt_dir=self.path.parent / "corrupt_saves"

    def _atomic_write(self, data: Dict[str, Any], target: Optional[Path]=None):
        target=target or self.path
        target.parent.mkdir(parents=True, exist_ok=True)
        raw=json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
        fd,tmp=tempfile.mkstemp(prefix=target.name+".", suffix=".tmp", dir=str(target.parent))
        try:
            with os.fdopen(fd,"wb") as f:
                f.write(raw); f.flush(); os.fsync(f.fileno())
            os.replace(tmp,target)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)

    def save(self, controller, *, backup=True, reason="manual") -> Dict[str, Any]:
        if backup and self.path.exists():
            shutil.copy2(self.path, self.backup_path)
        doc=controller.export_savegame()
        doc["save_reason"]=reason
        doc["saved_at"]=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self._atomic_write(doc)
        return doc

    def manual_backup(self, destination: str | Path | None=None) -> Path:
        if not self.path.exists():
            raise SaveGameError("目前沒有可備份的主存檔")
        if destination is None:
            stamp=time.strftime("%Y%m%d_%H%M%S", time.localtime())
            destination=self.path.parent / f"savegame_manual_{stamp}.json"
        dest=Path(destination); dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(self.path,dest); return dest

    def _read(self, path: Path) -> Dict[str, Any]:
        with path.open("r",encoding="utf-8") as f: return json.load(f)

    def load(self, controller) -> Dict[str, Any]:
        if not self.path.exists():
            return {"loaded":False,"source":"new_game","message":"沒有既有存檔，使用新遊戲狀態"}
        try:
            doc=migrate_save(self._read(self.path))
            controller.import_savegame(doc)
            # Persist migration immediately, while preserving the pre-migration file as backup.
            current=self._read(self.path)
            if current.get("schema") != SAVE_SCHEMA or int(current.get("save_version",0)) != CURRENT_SAVE_VERSION:
                shutil.copy2(self.path,self.backup_path)
                self._atomic_write(doc)
            return {"loaded":True,"source":"main","version":doc["save_version"]}
        except Exception as main_exc:
            self.corrupt_dir.mkdir(parents=True,exist_ok=True)
            stamp=time.strftime("%Y%m%d_%H%M%S", time.localtime())
            quarantined=self.corrupt_dir / f"{self.path.stem}_{stamp}.corrupt{self.path.suffix}"
            try: shutil.copy2(self.path,quarantined)
            except Exception: quarantined=None
            if self.backup_path.exists():
                try:
                    doc=migrate_save(self._read(self.backup_path)); controller.import_savegame(doc)
                    self._atomic_write(doc)
                    return {"loaded":True,"source":"backup","recovered":True,"quarantined":None if quarantined is None else str(quarantined),"warning":str(main_exc)}
                except Exception as backup_exc:
                    return {"loaded":False,"source":"new_game","recovered":False,"warning":f"主存檔與備份皆無法讀取：{main_exc}; {backup_exc}"}
            return {"loaded":False,"source":"new_game","recovered":False,"quarantined":None if quarantined is None else str(quarantined),"warning":str(main_exc)}
