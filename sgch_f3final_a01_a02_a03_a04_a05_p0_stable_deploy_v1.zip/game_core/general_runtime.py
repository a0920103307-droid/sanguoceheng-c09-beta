from __future__ import annotations
import json, re
from copy import deepcopy
from pathlib import Path

CATALOG_PATH = Path(__file__).resolve().parent.parent / 'general_catalog_a04.json'
F3_CARD_CATALOG_PATH = Path(__file__).resolve().parent.parent / 'runtime_modules' / 'cards' / 'card_catalog_v0.3.json'


def load_catalog(expanded=False):
    if expanded and F3_CARD_CATALOG_PATH.exists():
        payload=json.loads(F3_CARD_CATALOG_PATH.read_text(encoding='utf-8'))
        cards=[]
        for raw in payload.get('cards',[]):
            if str(raw.get('card_type')).upper()!='GENERAL': continue
            c=deepcopy(raw)
            c['source_confidence']=c.get('source_confidence') or c.get('confidence') or 'UNCONFIRMED'
            for sk in c.get('skills',[]):
                sk['original_text']=sk.get('original_text') or sk.get('effect_text') or ''
                sk['source_confidence']=sk.get('source_confidence') or sk.get('confidence') or 'UNCONFIRMED'
            cards.append(c)
        return {'version':payload.get('version'),'cards':cards,'f3b_policy':payload.get('f3b_policy',{})}
    return json.loads(CATALOG_PATH.read_text(encoding='utf-8'))


def _trigger(text: str) -> str:
    if any(k in text for k in ('每回合','回合')): return 'TURN_START'
    if any(k in text for k in ('敗退時','敗退後')): return 'ON_DEFEAT'
    if any(k in text for k in ('被攻擊','受到傷害','受物傷')): return 'AFTER_DAMAGE'
    if any(k in text for k in ('攻擊時','攻擊卡牌時','命中後','造成傷害後')): return 'ON_ATTACK'
    return 'ON_DEPLOY'


def _selector(text: str) -> str:
    if '其他所有卡牌' in text: return 'ALL_OTHER'
    if '敵方全體' in text or '敵全體' in text or '敵方所有' in text: return 'ENEMY_ALL'
    if '生命最低' in text: return 'ENEMY_LOWEST_HP'
    if '攻擊最高' in text: return 'ENEMY_HIGHEST_ATTACK'
    if '攻擊最低' in text: return 'ENEMY_LOWEST_ATTACK'
    if '正對' in text or '對面' in text: return 'OPPOSITE'
    if '隨機' in text and ('敵' in text or '對手' in text): return 'ENEMY_RANDOM'
    if '己方所有' in text or '我方所有' in text or '全體吳將' in text: return 'ALLY_ALL'
    if '除自身外' in text: return 'ALLY_OTHERS'
    if '自身與兩側' in text or '左右兩側' in text: return 'SELF_ADJACENT'
    if '敵' in text or '對手' in text or '對方' in text: return 'OPPOSITE'
    return 'SELF'


def compile_skill(skill: dict) -> list[dict]:
    text = f"{skill.get('name') or ''} {skill.get('original_text') or skill.get('effect_text') or ''}"
    trig, sel = _trigger(text), _selector(text)
    out=[]
    def add(tp, selector=None, **kw): out.append({'trigger':trig,'selector':selector or sel,'effect':{'type':tp,**kw},'layer':'TEMPORARY','skill_name':skill.get('name'),'original_text':skill.get('original_text') or skill.get('effect_text')})
    # zone / special first
    if '回到牌堆' in text or '送回' in text and '牌堆' in text: add('RETURN_TO_DECK')
    if '回到手牌' in text: add('RETURN_TO_HAND', 'ALLY_RANDOM_OTHER')
    if '復活' in text or '重新回到場上' in text or ('召回' in text and '敗退' in text): add('REVIVE_SELF' if trig=='ON_DEFEAT' else 'REVIVE','SELF')
    if '召喚人偶' in text: add('SUMMON','ALLY_EMPTY_SLOT',token={'card_id':'TOKEN_DOLL','name':'人偶','kind':'SOLDIER','attack':110,'hp':275})
    if '搶奪' in text and '戰馬' in text: add('STEAL_HORSE','ENEMY_RANDOM')
    if ('直接敗退' in text or '直接使' in text and '敗退' in text or '斬殺' in text): add('DIRECT_DEFEAT')
    if '抽' in text and '張' in text: add('DRAW','SELF',amount=3)
    if '火種' in text: add('ADD_FIRE','SELF',amount=1)
    if '城門' in text:
        gate_nums=[int(x) for x in re.findall(r'(?<!%)(?<!\d)(\d{2,4})(?!\d|%)', text)]
        add('DAMAGE_GATE','ENEMY_GATE',amount=int(max(gate_nums) if gate_nums else 180))
    # statuses
    if '隱身' in text: add('STEALTH','SELF',duration=99)
    if '嘲諷' in text: add('TAUNT','SELF',duration=99)
    if '沉默' in text: add('SILENCE',duration=1)
    if '封印' in text: add('SEAL',duration=1)
    if '混亂' in text or '反間' in text: add('CONFUSION',duration=1)
    if '鎖定' in text: add('LOCK',duration=1)
    if '照明' in text or '隱身/易容失效' in text: add('REVEAL','ENEMY_ALL')
    if any(k in text for k in ('無視謀略','不受法術','法術免疫','風護','神佑','識破')): add('IMMUNITY','SELF',blocks=['STATUS'],duration=2)
    if any(k in text for k in ('閃避','減少76%','鐵骨','金盾','減少60%傷害')): add('DIVINE_PROTECTION','SELF',duration=99)
    if '解除' in text and ('負面' in text or '狀態' in text or '中毒' in text): add('CLEAR_STATUS','ALLY_ALL',status='ALL')
    # F3-G: preserve explicit restored numbers where the source text contains them.
    # Unknown values still use clearly beta-only fallbacks so skills remain meaningful at the new stat scale.
    nums=[int(x) for x in re.findall(r'(?<!%)(?<!\d)(\d{2,4})(?!\d|%)', text)]
    explicit=max(nums) if nums else None
    if any(k in text for k in ('恢復','治療','補血')) and '攻擊' not in text:
        add('HEAL','ALLY_ALL' if '所有' in text else 'SELF',amount=int(explicit or 90))
    if ('生命+' in text or '生命基礎' in text or '提升生命' in text or '生命增' in text):
        add('MOD_HP','ALLY_OTHERS' if '除自身' in text else 'SELF',amount=int(explicit or 100))
    attack_buff = any(k in text for k in ('攻擊+','提升攻擊','攻擊提升','提高自身','物攻加成','攻擊加乘','轉加自身')) or ('提升' in text and '攻擊力' in text)
    if attack_buff:
        # Percent buffs are kept conservative until the full percentage engine is introduced.
        pct=re.findall(r'(\d{1,3})%',text); amount=60 if pct else int(explicit or 60)
        add('MOD_ATTACK','SELF',amount=amount)
    damage_reduction = any(k in text for k in ('減少' ,'減傷','免疫')) and '傷害' in text
    if ('兩側' in text or '左右' in text) and '傷害' in text and not damage_reduction:
        add('SPLASH','ATTACK_TARGET',amount=int(explicit or 80))
    elif ('全體' in text or '其他所有卡牌' in text) and '傷害' in text and not damage_reduction:
        add('DAMAGE','ALL_OTHER' if '其他所有卡牌' in text else 'ENEMY_ALL',amount=int(explicit or 80))
    elif any(k in text for k in ('對敵','敵方','穿心','狙擊','直接造成')) and '傷害' in text and not damage_reduction:
        add('DAMAGE',sel,amount=int(explicit or 80))
    if '回擊' in text: add('COUNTER','SELF',amount=int(explicit or 80),duration=99)
    if not out:
        # Explicit fallback for mechanics not modeled yet; still routes through generic engine.
        add('MOD_ATTACK','SELF',amount=60)
        out[-1]['temporary_fallback']=True
    return out


def build_deck(Card, names=None):
    general_cat=load_catalog(expanded=bool(names)); generals=general_cat['cards']; gen_by={x['name']:x for x in generals}
    soldier_by={}
    try:
        sp=Path(__file__).resolve().parent.parent/'runtime_modules'/'soldier'/'soldier_catalog_v0.9.json'
        soldier_by={x['name']:x for x in json.loads(sp.read_text(encoding='utf-8')).get('cards',[])}
    except Exception: pass
    wanted=list(names) if names else [x['name'] for x in generals]
    bond_eval={'per_general':{}}
    try:
        from .bond_runtime import BondEngine
        bond_eval=BondEngine().evaluate([n for n in wanted if n in gen_by])
    except Exception: pass
    deck=[]
    for name in wanted:
        if name in soldier_by:
            d=soldier_by[name]
            c=Card(d['card_id'],d['name'],'SOLDIER',attack=int(d['attack']),max_hp=int(d['hp']))
            c.soldier_role_code=d['role_code'];c.cost_fame=9;c.soldier_level=1;c.soldier_core_skill=deepcopy(d['core_skill']);c.soldier_meta=deepcopy(d)
            c.a04_meta={'faction':'士兵','quality':d.get('quality'),'source_confidence':d.get('source_confidence'),'combat_profile':{'role':'士兵/'+d['role_label'],'identity_note':d['core_skill']['text']}}
            c.a04_skills=[{'name':d['core_skill']['name'],'original_text':d['core_skill']['text'],'compiled':[],'runtime_layer':'BETA_BALANCE'}]
            deck.append(c);continue
        e=gen_by.get(name)
        if not e:continue
        bmod=(bond_eval.get('per_general') or {}).get(e['name'],{})
        atk=int(e['attack']['effective']);hp=int(e['hp']['effective']);atk=max(1,round(atk*(100+int(bmod.get('attack_pct',0)))/100));hp=max(1,round(hp*(100+int(bmod.get('hp_pct',0)))/100))
        c=Card(e['card_id'],e['name'],'GENERAL',attack=atk,max_hp=hp);c.a04_meta={'faction':e['faction'],'quality':e['quality'],'source_confidence':e.get('source_confidence') or e.get('confidence'),'combat_profile':e.get('combat_profile',{}),'bond_mod':bmod};c.a04_skills=[]
        for sk in e['skills']:c.a04_skills.append({**deepcopy(sk),'compiled':compile_skill(sk)})
        deck.append(c)
    return deck


class GeneralSkillRuntimeMixin:
    """A04 generic selector/effect adapter. No character-name branches."""
    def _a04_cards(self, owner=None, include_retreat=False):
        owners=range(2) if owner is None else [owner]
        for oi in owners:
            seq=[c for c in self.players[oi].board if c]
            if include_retreat: seq += list(self.players[oi].retreat)
            for c in seq: yield oi,c

    def _a04_owner(self, source):
        for oi,c in self._a04_cards(include_retreat=True):
            if c is source: return oi
        return None

    def _select(self, owner, source, selector, ctx):
        mine=[c for c in self.players[owner].board if c]; enemy=[c for c in self.players[1-owner].board if c]
        if selector=='SELF': return [source]
        if selector=='ALLY_ALL': return mine
        if selector=='ALLY_OTHERS': return [c for c in mine if c is not source]
        if selector=='ALLY_RANDOM_OTHER':
            xs=[c for c in mine if c is not source]; return [self.rng.choice(xs)] if xs else []
        if selector=='SELF_ADJACENT':
            loc=self._find_card(source); 
            if not loc: return [source]
            return [c for i,c in enumerate(self.players[owner].board) if c and abs(i-loc[1])<=1]
        if selector=='OPPOSITE':
            loc=self._find_card(source); c=None if not loc else self.players[1-owner].board[loc[1]]; return [c] if c else []
        if selector=='ATTACK_TARGET':
            name=ctx.get('target'); return [c for c in enemy if c.name==name][:1]
        if selector=='ALL_OTHER':
            attacked=str(ctx.get('target') or '')
            return [c for c in (mine+enemy) if c is not source and c.name!=attacked]
        if selector=='ENEMY_ALL': return enemy
        if selector=='ENEMY_RANDOM': return [self.rng.choice(enemy)] if enemy else []
        if selector=='ENEMY_LOWEST_HP': return [min(enemy,key=lambda c:c.hp)] if enemy else []
        if selector=='ENEMY_HIGHEST_ATTACK': return [max(enemy,key=lambda c:c.attack)] if enemy else []
        if selector=='ENEMY_LOWEST_ATTACK': return [min(enemy,key=lambda c:c.attack)] if enemy else []
        if selector=='ALLY_RETREAT_RANDOM': return []
        if selector in ('ALLY_EMPTY_SLOT','ENEMY_GATE'): return [None]
        return [source]

    def _a04_apply(self, owner, source, spec, ctx):
        targets=self._select(owner,source,spec.get('selector','SELF'),ctx)
        if spec.get('chance') is not None and self.rng.random() >= float(spec['chance']): return False
        applied=False
        for target in targets or [None]:
            eff=deepcopy(spec['effect']); et=str(eff.get('type','')).upper()
            if et=='RETURN_TO_HAND':
                if target is None: continue
                loc=self._find_card(target)
                if loc and len(self.players[loc[0]].hand)<10:
                    self.players[loc[0]].board[loc[1]]=None; self.players[loc[0]].hand.append(target); applied=True
            elif et=='DIRECT_DEFEAT':
                if target is not None:
                    target.hp=0; self.state_based_defeat(); applied=True
            elif et=='REVIVE_SELF':
                p=self.players[owner]
                if source in p.retreat:
                    slot=next((i for i,c in enumerate(p.board) if c is None),None)
                    if slot is not None:
                        p.retreat.remove(source); source.hp=source.max_hp; p.board[slot]=source; applied=True
            elif et=='REVIVE':
                p=self.players[owner]
                if p.retreat:
                    slot=next((i for i,c in enumerate(p.board) if c is None),None)
                    if slot is not None:
                        card=p.retreat.pop(); card.hp=card.max_hp; p.board[slot]=card; applied=True
            elif et=='SUMMON':
                slot=next((i for i,c in enumerate(self.players[owner].board) if c is None),None)
                if slot is not None:
                    res=super().apply_effect(owner,source,eff,target_slot=slot,context=ctx); applied |= res.applied
            elif et=='DAMAGE_GATE':
                res=super().apply_effect(owner,source,eff,context=ctx); applied |= res.applied
            else:
                res=super().apply_effect(owner,source,eff,target=target,context=ctx); applied |= res.applied
        if applied:
            self.log.append(f"A04_SKILL {source.name}::{spec.get('skill_name')} trigger={spec.get('trigger')}")
        return applied

    def emit(self,event,**ctx):
        super().emit(event,**ctx)
        candidates=list(self._a04_cards(include_retreat=True))
        for owner,source in candidates:
            for sk in getattr(source,'a04_skills',[]) or []:
                for spec in sk.get('compiled',[]):
                    trig=spec.get('trigger')
                    # special alias: source's ally defeated
                    if trig=='ALLY_DEFEAT' and event!='ON_DEFEAT': continue
                    if trig!='ALLY_DEFEAT' and trig!=event: continue
                    if event=='ON_DEPLOY' and ctx.get('card') is not source: continue
                    if event=='ON_DEFEAT' and trig!='ALLY_DEFEAT' and ctx.get('card')!=source.name: continue
                    if event=='TURN_START' and ctx.get('player')!=self.players[owner].name: continue
                    if event=='ON_ATTACK' and ctx.get('source')!=source.name: continue
                    if event=='AFTER_DAMAGE' and ctx.get('target')!=source.name: continue
                    # Generic re-entrancy guard: an AFTER_DAMAGE/DAMAGE effect may emit
                    # AFTER_DAMAGE again. The same source/skill/trigger must not recursively
                    # react to its own effect chain forever.
                    if not hasattr(self, '_a04_active_effects'): self._a04_active_effects=set()
                    key=(id(source), str(sk.get('name')), str(trig))
                    if key in self._a04_active_effects: continue
                    self._a04_active_effects.add(key)
                    try:
                        self._a04_apply(owner,source,{**spec,'skill_name':sk.get('name')},ctx)
                    finally:
                        self._a04_active_effects.discard(key)
