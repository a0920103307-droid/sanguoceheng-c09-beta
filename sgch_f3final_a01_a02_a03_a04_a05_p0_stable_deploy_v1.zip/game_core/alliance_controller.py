from __future__ import annotations
from typing import Any, Dict

class AllianceFrontController:
    """B08 local/NPC front-end adapter over the frozen Grid13 AllianceEngine."""
    def __init__(self, core, growth):
        self.core=core; self.growth=growth; self.engine=core.modules['alliance'].AllianceEngine()
        self.player_id='PLAYER'; self.simulated_level=1
        self.history=[]; self.claimed_front_rewards=set()
        self._bootstrap()

    def _silver(self): return int(self.growth.roster.resources.get('銀幣',0))
    def _sync_player_silver(self):
        if self.player_id in self.engine.players: self.engine.players[self.player_id].silver=self._silver()
    def _sync_back_silver(self):
        if self.player_id in self.engine.players: self.growth.roster.resources['銀幣']=int(self.engine.players[self.player_id].silver)
    def _bootstrap(self):
        A=self.core.modules['alliance']
        self.engine.add_player(A.AlliancePlayer(self.player_id,level=self.simulated_level,silver=self._silver()))
        for pid,name in [('NPC_LIU','劉備'),('NPC_GUAN','關羽'),('NPC_SUN','孫策'),('NPC_ZHOU','周瑜')]:
            self.engine.add_player(A.AlliancePlayer(pid,level=50,silver=5000,resources={'display_name':name}))
        a=self.engine.create_alliance('NPC_LIU','NPC_ALLIANCE_1','桃園試作盟')
        self.engine.join_alliance('NPC_GUAN',a.alliance_id); self.engine.join_alliance('NPC_SUN',a.alliance_id)
        self.engine.create_alliance('NPC_ZHOU','NPC_ALLIANCE_2','江東試作盟')
        self.engine.list_hire_card('NPC_GUAN','NPC_HIRE_1','CARD_GUAN_YU','關羽')
        self.engine.list_hire_card('NPC_SUN','NPC_HIRE_2','CARD_SUN_CE','孫策')

    def _me(self): return self.engine.players[self.player_id]
    def _current(self):
        p=self._me(); return self.engine.alliances.get(p.alliance_id) if p.alliance_id else None
    def _reward(self, rewards:Dict[str,int]):
        for k,v in rewards.items(): self.growth.roster.resources[k]=int(self.growth.roster.resources.get(k,0))+int(v)
        self._sync_player_silver()

    def create(self,name:str):
        self._sync_player_silver(); aid='PLAYER_ALLIANCE'; self.engine.create_alliance(self.player_id,aid,(name or '我的聯盟').strip()[:20]); self._sync_back_silver(); self.history.append({'action':'CREATE','alliance_id':aid}); return {'alliance_id':aid}
    def join(self,aid:str='NPC_ALLIANCE_1'):
        self._sync_player_silver(); r=self.engine.join_alliance(self.player_id,aid); self.history.append(r); return r
    def contribute(self,amount:int=50):
        self._sync_player_silver(); r=self.engine.contribute_silver(self.player_id,int(amount)); self._sync_back_silver(); self.history.append(r); return r
    def upgrade_tech(self,tech='攻擊科技'):
        a=self._current()
        if not a: raise ValueError('尚未加入聯盟')
        # NPC leader acts as authorized local simulation when player is a member.
        actor=a.leader_id; r=self.engine.upgrade_tech(actor,str(tech)); self.history.append(r); return r
    def boss_hit(self,damage:int=400):
        a=self._current()
        if not a: raise ValueError('尚未加入聯盟')
        r=self.engine.hit_boss(self.player_id,max(0,int(damage)))
        if r.get('killed'):
            self._reward({'進化丹':2})
            r['front_reward']={'進化丹':2,'layer':'Temporary'}
        self.history.append(r); return r
    def claim_boss(self):
        r=self.engine.claim_boss_clear(self.player_id)
        key=f"{self._me().alliance_id}:{self._current().boss_index}"
        if key in self.claimed_front_rewards: raise ValueError('B08 前台獎勵已領取')
        self.claimed_front_rewards.add(key); reward={'銀幣':300,'聯盟徽記':1}; self._reward(reward); r['front_reward']=reward; self.history.append(r); return r
    def hire(self,listing_id='NPC_HIRE_1'):
        self._sync_player_silver(); r=self.engine.hire_card(self.player_id,str(listing_id)); self._sync_back_silver(); self.history.append(r); return r

    def export(self):
        p=self._me(); a=self._current()
        return {'alliance_id':p.alliance_id,'role':p.role,'hire_runs_today':p.hire_runs_today,'boss_runs_today':p.boss_runs_today,'boss_score':p.boss_score,'claimed_front_rewards':sorted(self.claimed_front_rewards),'history':self.history[-50:],
                'alliance':None if not a else {'alliance_id':a.alliance_id,'level':a.level,'construction_points':a.construction_points,'tech_levels':dict(a.tech_levels),'boss_index':a.boss_index,'boss_hp':a.boss_hp,'boss_killed':a.boss_killed,'boss_clear_claimed_by':sorted(a.boss_clear_claimed_by),'boss_last_hit_player':a.boss_last_hit_player}}
    def import_data(self,data):
        if not isinstance(data,dict): return
        aid=data.get('alliance_id')
        if aid and aid in self.engine.alliances and self._me().alliance_id is None:
            self.engine.join_alliance(self.player_id,aid)
        p=self._me(); p.hire_runs_today=int(data.get('hire_runs_today',0)); p.boss_runs_today=int(data.get('boss_runs_today',0)); p.boss_score=int(data.get('boss_score',0))
        self.claimed_front_rewards=set(data.get('claimed_front_rewards') or []); self.history=list(data.get('history') or [])[-50:]
        snap=data.get('alliance') or {}; a=self._current()
        if a and snap and snap.get('alliance_id')==a.alliance_id:
            a.level=int(snap.get('level',a.level)); a.construction_points=int(snap.get('construction_points',a.construction_points)); a.tech_levels={str(k):int(v) for k,v in (snap.get('tech_levels') or {}).items()}; a.boss_index=int(snap.get('boss_index',a.boss_index)); a.boss_hp=int(snap.get('boss_hp',a.boss_hp)); a.boss_killed=bool(snap.get('boss_killed',a.boss_killed)); a.boss_clear_claimed_by=set(snap.get('boss_clear_claimed_by') or []); a.boss_last_hit_player=snap.get('boss_last_hit_player')
        self._sync_player_silver()

    def state(self):
        p=self._me(); a=self._current(); A=self.core.modules['alliance']
        available=[]
        for x in self.engine.alliances.values():
            available.append({'alliance_id':x.alliance_id,'name':x.name,'level':x.level,'members':len(x.members),'joinable':p.alliance_id is None and len(x.members)<int(A.tp('member_cap'))})
        if not a:
            return {'version':'B08','in_alliance':False,'simulated_player_level':self.simulated_level,'unlock_level':None,'unlock_status':'UNCONFIRMED','available_alliances':available,'boundary':'本機 NPC 模擬；無正式伺服器'}
        hires=[{'listing_id':h.listing_id,'card_name':h.card_name,'owner_id':h.owner_id,'available':h.hired_by is None and h.owner_id!=self.player_id} for h in a.hire_listings.values()]
        members=[{'player_id':pid,'role':role,'boss_score':self.engine.players[pid].boss_score} for pid,role in a.members.items()]
        return {'version':'B08','in_alliance':True,'simulated_player_level':self.simulated_level,'alliance_id':a.alliance_id,'name':a.name,'role':p.role,'level':a.level,'members':members,'construction_points':a.construction_points,'tech_levels':dict(a.tech_levels),'boss':{'index':a.boss_index,'hp':a.boss_hp,'killed':a.boss_killed,'runs_today':p.boss_runs_today,'daily_limit':int(A.tp('alliance_boss_daily_limit')),'score':p.boss_score,'can_claim':a.boss_killed and self.player_id not in a.boss_clear_claimed_by},'hires':hires,'ranking':self.engine.alliance_ranking(),'available_alliances':available,'rewards_note':'通關前台獎勵數量為 Temporary；實際寫入 B06 資源','boundary':'本機 NPC 模擬；聯盟戰／城池與真人同步不在 B08'}
