from __future__ import annotations
from .ui_controller import UIActionResult
from .progression_runtime import GrowthRoster

class GrowthController:
    def __init__(self, progression_module): self.roster=GrowthRoster(progression_module)
    def state(self): return self.roster.state()
    def act(self,action,**d):
        try:
            n=str(d.get('name') or '張遼')
            if action=='level_up': r=self.roster.level_up(n,int(d.get('times',1)))
            elif action=='evolve': r=self.roster.evolve(n)
            elif action=='equip_item': r=self.roster.equip_item(n,str(d['item']))
            elif action=='strengthen_equipment': r=self.roster.strengthen_equipment(n,str(d['slot']))
            elif action=='equip_growth_horse': r=self.roster.equip_horse(n,str(d['horse']))
            elif action=='strengthen_growth_horse': r=self.roster.strengthen_horse(n)
            elif action=='study_book': r=self.roster.study_book(n,str(d['book']))
            elif action=='refine_equipment': r=self.roster.refine_equipment(n,str(d['slot']),str(d['skill']))
            elif action=='claim_f3d_test_pack': r=self.roster.claim_f3d_test_pack()
            elif action=='soldier_upgrade': r=self.roster.upgrade_soldier(str(d.get('soldier') or n),int(d.get('times',1)))
            else: raise ValueError('未知養成操作')
            return UIActionResult(True,self.state(),str(r))
        except Exception as exc: return UIActionResult(False,self.state(),str(exc))
