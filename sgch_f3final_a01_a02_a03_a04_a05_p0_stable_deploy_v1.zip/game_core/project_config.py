from __future__ import annotations
import json, os
from dataclasses import dataclass
from pathlib import Path

ALLOWED_ENVS={"dev","test","staging","production"}

@dataclass(frozen=True)
class ProjectConfig:
    environment: str
    host: str
    port: int
    open_browser: bool
    log_level: str
    save_dir: Path
    beta_tools: bool
    allow_guest: bool
    secure_cookie: bool
    admin_token: str | None


def load_project_config(base: Path, environment: str | None=None) -> ProjectConfig:
    env=(environment or os.getenv("SGCH_ENV") or "dev").strip().lower()
    if env not in ALLOWED_ENVS:
        raise ValueError(f"SGCH_ENV 必須是 {sorted(ALLOWED_ENVS)}，收到：{env}")
    path=base/"config"/f"{env}.json"
    data=json.loads(path.read_text(encoding="utf-8"))
    host=os.getenv("SGCH_HOST",str(data["host"]))
    port=int(os.getenv("SGCH_PORT",str(data["port"])))
    raw_save=os.getenv("SGCH_SAVE_DIR",str(data["save_dir"]))
    save_dir=Path(raw_save)
    if not save_dir.is_absolute(): save_dir=base/save_dir
    browser=os.getenv("SGCH_OPEN_BROWSER")
    open_browser=data.get("open_browser",False) if browser is None else browser.lower() in {"1","true","yes","on"}
    def env_bool(name:str, default:bool)->bool:
        raw=os.getenv(name)
        return default if raw is None else raw.strip().lower() in {"1","true","yes","on"}
    beta_tools=env_bool("SGCH_BETA_TOOLS", bool(data.get("beta_tools", env in {"dev","test","staging"})))
    allow_guest=env_bool("SGCH_ALLOW_GUEST", bool(data.get("allow_guest", env != "production")))
    secure_cookie=env_bool("SGCH_COOKIE_SECURE", bool(data.get("secure_cookie", env == "production")))
    admin_token=(os.getenv("SGCH_ADMIN_TOKEN") or '').strip() or None
    return ProjectConfig(env,host,port,open_browser,str(data.get("log_level","INFO")),save_dir,beta_tools,allow_guest,secure_cookie,admin_token)
