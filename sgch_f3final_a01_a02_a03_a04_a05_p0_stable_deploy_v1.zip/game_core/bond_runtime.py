from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, List, Any

CATALOG=Path(__file__).resolve().parent.parent/'runtime_modules'/'cards'/'bond_catalog_v0.1.json'

def load_bond_catalog():
    return json.loads(CATALOG.read_text(encoding='utf-8'))

class BondEngine:
    def __init__(self, catalog=None):
        self.catalog=catalog or load_bond_catalog()

    def evaluate(self, names:List[str], equipment_by_general:Dict[str,List[str]]|None=None)->Dict[str,Any]:
        names=list(dict.fromkeys(str(x) for x in names))
        name_set=set(names); equipment_by_general=equipment_by_general or {}
        out=[]; per={n:{'attack_pct':0,'hp_pct':0,'active_bonds':[]} for n in names}
        for b in self.catalog.get('bonds',[]):
            members=list(b.get('members') or [])
            present=[n for n in members if n in name_set]
            if b.get('kind')=='EXCLUSIVE_EQUIPMENT':
                owner=members[0] if members else None
                active=bool(owner in name_set and b.get('equipment') in set(equipment_by_general.get(owner,[]) or []))
            else:
                active=len(present)>=int(b.get('min_members') or len(members))
            rec={**b,'present_members':present,'active':active}
            out.append(rec)
            if active:
                for n in present:
                    if n not in per: continue
                    per[n]['active_bonds'].append(b['bond_id'])
                    for eff in b.get('effects',[]):
                        if eff.get('type')=='ATTACK_PCT': per[n]['attack_pct']+=int(eff.get('value') or 0)
                        elif eff.get('type')=='HP_PCT': per[n]['hp_pct']+=int(eff.get('value') or 0)
        return {'version':self.catalog.get('version'),'bonds':out,'per_general':per,
                'active_count':sum(1 for x in out if x['active']),
                'policy':self.catalog.get('policy',{})}
