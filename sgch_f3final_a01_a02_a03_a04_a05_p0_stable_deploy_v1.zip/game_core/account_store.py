from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Protocol


@dataclass(frozen=True)
class AccountRecord:
    player_id: str
    username: str
    password_hash: str
    created_at: int


class AccountStoreError(RuntimeError):
    pass


class DuplicateAccountError(AccountStoreError):
    pass


class AccountStore(Protocol):
    backend_name: str

    def create(self, record: AccountRecord) -> None: ...
    def get_by_username(self, username: str) -> Optional[AccountRecord]: ...
    def get_by_player_id(self, player_id: str) -> Optional[AccountRecord]: ...


class SQLiteAccountStore:
    backend_name = "sqlite"

    def __init__(self, db_path: str | Path):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _db(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self._db() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS players(
                  player_id TEXT PRIMARY KEY,
                  username TEXT UNIQUE NOT NULL,
                  password_hash TEXT NOT NULL,
                  created_at INTEGER NOT NULL
                )
                """
            )

    @staticmethod
    def _row(row) -> Optional[AccountRecord]:
        if row is None:
            return None
        return AccountRecord(
            player_id=str(row["player_id"]),
            username=str(row["username"]),
            password_hash=str(row["password_hash"]),
            created_at=int(row["created_at"]),
        )

    def create(self, record: AccountRecord) -> None:
        try:
            with self._db() as con:
                con.execute(
                    "INSERT INTO players(player_id,username,password_hash,created_at) VALUES(?,?,?,?)",
                    (record.player_id, record.username, record.password_hash, record.created_at),
                )
        except sqlite3.IntegrityError as exc:
            raise DuplicateAccountError("account already exists") from exc

    def get_by_username(self, username: str) -> Optional[AccountRecord]:
        with self._db() as con:
            row = con.execute(
                "SELECT player_id,username,password_hash,created_at FROM players WHERE username=?",
                (username,),
            ).fetchone()
        return self._row(row)

    def get_by_player_id(self, player_id: str) -> Optional[AccountRecord]:
        with self._db() as con:
            row = con.execute(
                "SELECT player_id,username,password_hash,created_at FROM players WHERE player_id=?",
                (player_id,),
            ).fetchone()
        return self._row(row)


class PostgresAccountStore:
    """Persistent account store for Render PostgreSQL.

    Import is intentionally lazy so local/dev SQLite mode does not require psycopg.
    A01 only moves account records. Session persistence remains in AuthStore's local
    SQLite table until A02.
    """

    backend_name = "postgres"

    def __init__(self, database_url: str):
        self.database_url = str(database_url or "").strip()
        if not self.database_url:
            raise AccountStoreError("PostgreSQL account backend requires DATABASE_URL")
        try:
            import psycopg  # type: ignore
        except ImportError as exc:
            raise AccountStoreError(
                "PostgreSQL account backend requires psycopg; install requirements.txt"
            ) from exc
        self._psycopg = psycopg
        self._init()

    def _db(self):
        return self._psycopg.connect(self.database_url)

    def _init(self):
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS auth_players(
                      player_id VARCHAR(40) PRIMARY KEY,
                      username VARCHAR(32) UNIQUE NOT NULL,
                      password_hash TEXT NOT NULL,
                      created_at BIGINT NOT NULL
                    )
                    """
                )
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_auth_players_username ON auth_players(username)"
                )

    @staticmethod
    def _record(row) -> Optional[AccountRecord]:
        if row is None:
            return None
        return AccountRecord(
            player_id=str(row[0]),
            username=str(row[1]),
            password_hash=str(row[2]),
            created_at=int(row[3]),
        )

    def create(self, record: AccountRecord) -> None:
        try:
            with self._db() as con:
                with con.cursor() as cur:
                    cur.execute(
                        "INSERT INTO auth_players(player_id,username,password_hash,created_at) VALUES(%s,%s,%s,%s)",
                        (record.player_id, record.username, record.password_hash, record.created_at),
                    )
        except self._psycopg.errors.UniqueViolation as exc:
            raise DuplicateAccountError("account already exists") from exc

    def get_by_username(self, username: str) -> Optional[AccountRecord]:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    "SELECT player_id,username,password_hash,created_at FROM auth_players WHERE username=%s",
                    (username,),
                )
                row = cur.fetchone()
        return self._record(row)

    def get_by_player_id(self, player_id: str) -> Optional[AccountRecord]:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    "SELECT player_id,username,password_hash,created_at FROM auth_players WHERE player_id=%s",
                    (player_id,),
                )
                row = cur.fetchone()
        return self._record(row)


def build_account_store(sqlite_path: str | Path) -> AccountStore:
    """Build the A01 account backend without silently hard-switching production.

    Default is SQLite. PostgreSQL is enabled only when SGCH_AUTH_BACKEND=postgres.
    The URL is read from SGCH_AUTH_DATABASE_URL first, then Render's DATABASE_URL.
    """

    backend = (os.getenv("SGCH_AUTH_BACKEND") or "sqlite").strip().lower()
    if backend == "sqlite":
        return SQLiteAccountStore(sqlite_path)
    if backend == "postgres":
        url = (os.getenv("SGCH_AUTH_DATABASE_URL") or os.getenv("DATABASE_URL") or "").strip()
        return PostgresAccountStore(url)
    raise AccountStoreError("SGCH_AUTH_BACKEND must be sqlite or postgres")
