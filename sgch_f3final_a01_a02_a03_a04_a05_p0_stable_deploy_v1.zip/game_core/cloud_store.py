from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from .savegame import migrate_save

CLOUD_SCHEMA = 'sgch.cloudsave'
CLOUD_SCHEMA_VERSION = 1


class CloudSaveError(RuntimeError):
    pass


class CloudConflictError(CloudSaveError):
    def __init__(self, current_revision: int):
        super().__init__(f'雲端存檔衝突：目前版本為 {current_revision}')
        self.current_revision = current_revision


@dataclass
class CloudLoadResult:
    document: Dict[str, Any]
    revision: int
    updated_at: int
    recovered: bool = False
    source: str = 'cloud'


class _Codec:
    @staticmethod
    def encode(doc: Dict[str, Any]) -> tuple[str, str]:
        normalized = migrate_save(doc)
        raw = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        return raw, hashlib.sha256(raw.encode('utf-8')).hexdigest()

    @staticmethod
    def decode(raw: str, checksum: str) -> Dict[str, Any]:
        actual = hashlib.sha256(raw.encode('utf-8')).hexdigest()
        if actual != checksum:
            raise CloudSaveError('雲端存檔 checksum 不符')
        return migrate_save(json.loads(raw))


class SQLiteCloudSaveStore:
    backend_name = 'sqlite'

    def __init__(self, db_path: str | Path):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _db(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self._db() as con:
            con.executescript(
                '''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS cloud_saves(
                  player_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, save_json TEXT NOT NULL,
                  checksum TEXT NOT NULL, updated_at INTEGER NOT NULL, schema_version INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS cloud_backups(
                  backup_id INTEGER PRIMARY KEY AUTOINCREMENT, player_id TEXT NOT NULL,
                  revision INTEGER NOT NULL, save_json TEXT NOT NULL, checksum TEXT NOT NULL,
                  created_at INTEGER NOT NULL, reason TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS idx_cloud_backups_player ON cloud_backups(player_id,backup_id DESC);
                '''
            )

    _encode = staticmethod(_Codec.encode)
    _decode = staticmethod(_Codec.decode)

    def current_revision(self, player_id: str) -> int:
        with self._db() as con:
            r = con.execute('SELECT revision FROM cloud_saves WHERE player_id=?', (player_id,)).fetchone()
        return int(r['revision']) if r else 0

    def save(self, player_id: str, doc: Dict[str, Any], *, expected_revision: Optional[int] = None, reason='sync') -> int:
        raw, checksum = self._encode(doc)
        now = int(time.time())
        with self._db() as con:
            con.execute('BEGIN IMMEDIATE')
            old = con.execute('SELECT * FROM cloud_saves WHERE player_id=?', (player_id,)).fetchone()
            current = int(old['revision']) if old else 0
            if expected_revision is not None and int(expected_revision) != current:
                raise CloudConflictError(current)
            if old:
                con.execute(
                    'INSERT INTO cloud_backups(player_id,revision,save_json,checksum,created_at,reason) VALUES(?,?,?,?,?,?)',
                    (player_id, current, old['save_json'], old['checksum'], now, reason),
                )
            revision = current + 1
            con.execute(
                'INSERT OR REPLACE INTO cloud_saves(player_id,revision,save_json,checksum,updated_at,schema_version) VALUES(?,?,?,?,?,?)',
                (player_id, revision, raw, checksum, now, CLOUD_SCHEMA_VERSION),
            )
        return revision

    def load(self, player_id: str) -> Optional[CloudLoadResult]:
        with self._db() as con:
            row = con.execute('SELECT * FROM cloud_saves WHERE player_id=?', (player_id,)).fetchone()
        if not row:
            return None
        try:
            return CloudLoadResult(self._decode(row['save_json'], row['checksum']), int(row['revision']), int(row['updated_at']))
        except Exception:
            recovered = self.restore_latest_valid(player_id, reason='auto_corruption_recovery')
            if recovered:
                return recovered
            raise

    def list_backups(self, player_id: str, limit: int = 20):
        with self._db() as con:
            rows = con.execute(
                'SELECT backup_id,revision,created_at,reason FROM cloud_backups WHERE player_id=? ORDER BY backup_id DESC LIMIT ?',
                (player_id, int(limit)),
            ).fetchall()
        return [dict(r) for r in rows]

    def restore(self, player_id: str, backup_id: int, *, reason='manual_restore') -> CloudLoadResult:
        with self._db() as con:
            row = con.execute('SELECT * FROM cloud_backups WHERE player_id=? AND backup_id=?', (player_id, int(backup_id))).fetchone()
        if not row:
            raise CloudSaveError('找不到指定備份')
        doc = self._decode(row['save_json'], row['checksum'])
        revision = self.save(player_id, doc, expected_revision=self.current_revision(player_id), reason=reason)
        return CloudLoadResult(doc, revision, int(time.time()), True, 'backup')

    def restore_latest_valid(self, player_id: str, *, reason='auto_recovery') -> Optional[CloudLoadResult]:
        with self._db() as con:
            rows = con.execute('SELECT * FROM cloud_backups WHERE player_id=? ORDER BY backup_id DESC', (player_id,)).fetchall()
        for row in rows:
            try:
                doc = self._decode(row['save_json'], row['checksum'])
                revision = self.save(player_id, doc, expected_revision=self.current_revision(player_id), reason=reason)
                return CloudLoadResult(doc, revision, int(time.time()), True, 'backup')
            except CloudConflictError:
                raise
            except Exception:
                continue
        return None


class PostgresCloudSaveStore:
    backend_name = 'postgres'

    def __init__(self, database_url: str):
        self.database_url = str(database_url or '').strip()
        if not self.database_url:
            raise CloudSaveError('PostgreSQL save backend requires DATABASE_URL')
        try:
            import psycopg  # type: ignore
        except ImportError as exc:
            raise CloudSaveError('PostgreSQL save backend requires psycopg; install requirements.txt') from exc
        self._psycopg = psycopg
        self._init()

    def _db(self):
        return self._psycopg.connect(self.database_url)

    def _init(self):
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    '''
                    CREATE TABLE IF NOT EXISTS player_cloud_saves(
                      player_id VARCHAR(40) PRIMARY KEY,
                      revision BIGINT NOT NULL,
                      save_json TEXT NOT NULL,
                      checksum VARCHAR(64) NOT NULL,
                      updated_at BIGINT NOT NULL,
                      schema_version INTEGER NOT NULL
                    )
                    '''
                )
                cur.execute(
                    '''
                    CREATE TABLE IF NOT EXISTS player_cloud_backups(
                      backup_id BIGSERIAL PRIMARY KEY,
                      player_id VARCHAR(40) NOT NULL,
                      revision BIGINT NOT NULL,
                      save_json TEXT NOT NULL,
                      checksum VARCHAR(64) NOT NULL,
                      created_at BIGINT NOT NULL,
                      reason TEXT NOT NULL
                    )
                    '''
                )
                cur.execute('CREATE INDEX IF NOT EXISTS idx_player_cloud_backups_player ON player_cloud_backups(player_id,backup_id DESC)')

    _encode = staticmethod(_Codec.encode)
    _decode = staticmethod(_Codec.decode)

    def current_revision(self, player_id: str) -> int:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute('SELECT revision FROM player_cloud_saves WHERE player_id=%s', (player_id,))
                row = cur.fetchone()
        return int(row[0]) if row else 0

    def save(self, player_id: str, doc: Dict[str, Any], *, expected_revision: Optional[int] = None, reason='sync') -> int:
        raw, checksum = self._encode(doc)
        now = int(time.time())
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute('SELECT revision,save_json,checksum FROM player_cloud_saves WHERE player_id=%s FOR UPDATE', (player_id,))
                old = cur.fetchone()
                current = int(old[0]) if old else 0
                if expected_revision is not None and int(expected_revision) != current:
                    raise CloudConflictError(current)
                if old:
                    cur.execute(
                        'INSERT INTO player_cloud_backups(player_id,revision,save_json,checksum,created_at,reason) VALUES(%s,%s,%s,%s,%s,%s)',
                        (player_id, current, old[1], old[2], now, reason),
                    )
                revision = current + 1
                cur.execute(
                    '''
                    INSERT INTO player_cloud_saves(player_id,revision,save_json,checksum,updated_at,schema_version)
                    VALUES(%s,%s,%s,%s,%s,%s)
                    ON CONFLICT(player_id) DO UPDATE SET
                      revision=EXCLUDED.revision,
                      save_json=EXCLUDED.save_json,
                      checksum=EXCLUDED.checksum,
                      updated_at=EXCLUDED.updated_at,
                      schema_version=EXCLUDED.schema_version
                    ''',
                    (player_id, revision, raw, checksum, now, CLOUD_SCHEMA_VERSION),
                )
        return revision

    def load(self, player_id: str) -> Optional[CloudLoadResult]:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute('SELECT revision,save_json,checksum,updated_at FROM player_cloud_saves WHERE player_id=%s', (player_id,))
                row = cur.fetchone()
        if not row:
            return None
        try:
            return CloudLoadResult(self._decode(row[1], row[2]), int(row[0]), int(row[3]))
        except Exception:
            recovered = self.restore_latest_valid(player_id, reason='auto_corruption_recovery')
            if recovered:
                return recovered
            raise

    def list_backups(self, player_id: str, limit: int = 20):
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    'SELECT backup_id,revision,created_at,reason FROM player_cloud_backups WHERE player_id=%s ORDER BY backup_id DESC LIMIT %s',
                    (player_id, int(limit)),
                )
                rows = cur.fetchall()
        return [
            {'backup_id': int(r[0]), 'revision': int(r[1]), 'created_at': int(r[2]), 'reason': str(r[3])}
            for r in rows
        ]

    def restore(self, player_id: str, backup_id: int, *, reason='manual_restore') -> CloudLoadResult:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    'SELECT revision,save_json,checksum,created_at FROM player_cloud_backups WHERE player_id=%s AND backup_id=%s',
                    (player_id, int(backup_id)),
                )
                row = cur.fetchone()
        if not row:
            raise CloudSaveError('找不到指定備份')
        doc = self._decode(row[1], row[2])
        revision = self.save(player_id, doc, expected_revision=self.current_revision(player_id), reason=reason)
        return CloudLoadResult(doc, revision, int(time.time()), True, 'backup')

    def restore_latest_valid(self, player_id: str, *, reason='auto_recovery') -> Optional[CloudLoadResult]:
        with self._db() as con:
            with con.cursor() as cur:
                cur.execute(
                    'SELECT backup_id,revision,save_json,checksum,created_at FROM player_cloud_backups WHERE player_id=%s ORDER BY backup_id DESC',
                    (player_id,),
                )
                rows = cur.fetchall()
        for row in rows:
            try:
                doc = self._decode(row[2], row[3])
                revision = self.save(player_id, doc, expected_revision=self.current_revision(player_id), reason=reason)
                return CloudLoadResult(doc, revision, int(time.time()), True, 'backup')
            except CloudConflictError:
                raise
            except Exception:
                continue
        return None


class CloudSaveStore:
    """A03 backend-selecting facade while preserving the existing constructor."""

    def __new__(cls, db_path: str | Path):
        backend = (os.getenv('SGCH_SAVE_BACKEND') or os.getenv('SGCH_AUTH_BACKEND') or 'sqlite').strip().lower()
        if backend == 'sqlite':
            return SQLiteCloudSaveStore(db_path)
        if backend == 'postgres':
            url = (
                os.getenv('SGCH_SAVE_DATABASE_URL')
                or os.getenv('SGCH_AUTH_DATABASE_URL')
                or os.getenv('DATABASE_URL')
                or ''
            ).strip()
            return PostgresCloudSaveStore(url)
        raise CloudSaveError('SGCH_SAVE_BACKEND must be sqlite or postgres')
