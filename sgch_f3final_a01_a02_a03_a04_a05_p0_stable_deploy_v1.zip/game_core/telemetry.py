from __future__ import annotations
import hashlib, json, secrets, sqlite3, threading, time
from dataclasses import dataclass
from pathlib import Path

FUNNEL_EVENTS = [
    'login','tutorial_start','tutorial_complete','recruit','lineup','stage_start','stage_success'
]
CLIENT_EVENTS = {'page_load','leave_point','js_error','api_error','beta_session_start'}
ALLOWED_METADATA = {
    'method','action','stage_id','dungeon_id','opponent_id','screen','result',
    'draw_count','duration_bucket','performance_tier','online','tutorial_step'
}

@dataclass(frozen=True)
class TelemetryEvent:
    event_name: str
    player_hash: str | None = None
    session_id: str | None = None
    category: str = 'gameplay'
    screen: str | None = None
    duration_ms: int | None = None
    success: bool | None = None
    error_code: str | None = None
    metadata: dict | None = None

class TelemetryStore:
    """C07 closed-test analytics store. Deliberately separate from save-game DBs."""
    def __init__(self, db_path: Path, secret_path: Path | None = None):
        self.db_path=Path(db_path); self.db_path.parent.mkdir(parents=True,exist_ok=True)
        self.secret_path=Path(secret_path or self.db_path.with_name('telemetry.secret'))
        self._lock=threading.RLock(); self._secret=self._load_secret(); self._init_db()

    def _load_secret(self):
        if self.secret_path.exists(): return self.secret_path.read_text(encoding='utf-8').strip()
        value=secrets.token_hex(32); self.secret_path.write_text(value,encoding='utf-8'); return value

    def _connect(self):
        con=sqlite3.connect(self.db_path,timeout=10); con.row_factory=sqlite3.Row; return con

    def _init_db(self):
        with self._connect() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS telemetry_events(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                player_hash TEXT,
                session_id TEXT,
                event_name TEXT NOT NULL,
                category TEXT NOT NULL,
                screen TEXT,
                duration_ms INTEGER,
                success INTEGER,
                error_code TEXT,
                metadata_json TEXT NOT NULL DEFAULT '{}'
            )''')
            con.execute('CREATE INDEX IF NOT EXISTS idx_telemetry_event ON telemetry_events(event_name, ts)')
            con.execute('CREATE INDEX IF NOT EXISTS idx_telemetry_player ON telemetry_events(player_hash, ts)')

    def player_hash(self, player_id: str | None):
        if not player_id:return None
        return hashlib.sha256((self._secret+'|'+str(player_id)).encode()).hexdigest()[:20]

    @staticmethod
    def sanitize_metadata(metadata):
        out={}
        for k,v in (metadata or {}).items():
            if k not in ALLOWED_METADATA: continue
            if isinstance(v,(str,int,float,bool)) or v is None:
                out[k]=v if not isinstance(v,str) else v[:120]
        return out

    def record(self, event: TelemetryEvent):
        duration=None if event.duration_ms is None else max(0,min(int(event.duration_ms),600000))
        sid=(str(event.session_id)[:80] if event.session_id else None)
        with self._lock,self._connect() as con:
            con.execute('''INSERT INTO telemetry_events(ts,player_hash,session_id,event_name,category,screen,duration_ms,success,error_code,metadata_json)
              VALUES(?,?,?,?,?,?,?,?,?,?)''',(time.time(),event.player_hash,sid,event.event_name[:64],event.category[:32],(event.screen or '')[:48] or None,duration,None if event.success is None else int(bool(event.success)),(event.error_code or '')[:80] or None,json.dumps(self.sanitize_metadata(event.metadata),ensure_ascii=False)))

    def record_for_player(self, player_id, event_name, **kwargs):
        self.record(TelemetryEvent(event_name=event_name,player_hash=self.player_hash(player_id),**kwargs))

    def summary(self):
        with self._connect() as con:
            total=con.execute('SELECT COUNT(*) n FROM telemetry_events').fetchone()['n']
            players=con.execute("SELECT COUNT(DISTINCT player_hash) n FROM telemetry_events WHERE player_hash IS NOT NULL").fetchone()['n']
            funnel=[]; prev=None
            for name in FUNNEL_EVENTS:
                n=con.execute('SELECT COUNT(DISTINCT player_hash) n FROM telemetry_events WHERE event_name=? AND player_hash IS NOT NULL',(name,)).fetchone()['n']
                funnel.append({'event':name,'players':n,'from_previous_pct':None if prev in (None,0) else round(n*100/prev,1)})
                prev=n
            errors=[dict(r) for r in con.execute("SELECT COALESCE(error_code,'UNKNOWN') error_code, COUNT(*) count, MAX(ts) last_ts FROM telemetry_events WHERE category='error' GROUP BY COALESCE(error_code,'UNKNOWN') ORDER BY count DESC,last_ts DESC LIMIT 20")]
            loads=dict(con.execute("SELECT COUNT(duration_ms) samples, COALESCE(ROUND(AVG(duration_ms),1),0) avg_ms, COALESCE(MAX(duration_ms),0) max_ms FROM telemetry_events WHERE event_name='page_load'").fetchone())
            exits=[dict(r) for r in con.execute("SELECT COALESCE(screen,'UNKNOWN') screen,COUNT(*) count FROM telemetry_events WHERE event_name='leave_point' GROUP BY COALESCE(screen,'UNKNOWN') ORDER BY count DESC LIMIT 20")]
        return {'schema':'sgch.telemetry.summary','total_events':total,'unique_testers':players,'funnel':funnel,'errors':errors,'load_time':loads,'leave_points':exits}

    def participant_progress(self, player_id: str):
        ph=self.player_hash(player_id)
        with self._connect() as con:
            rows=con.execute("SELECT ts,event_name,session_id FROM telemetry_events WHERE player_hash=? ORDER BY ts",(ph,)).fetchall()
        if not rows:
            return {'schema':'sgch.closed_beta.participant','player_hash':ph,'events':0,'sessions':0,'first_seen':None,'last_seen':None,'first_hour_events':0,'returned_24h':False,'returned_3d':False,'milestones':{}}
        first=float(rows[0]['ts']); last=float(rows[-1]['ts'])
        names={r['event_name'] for r in rows}
        return {
            'schema':'sgch.closed_beta.participant','player_hash':ph,'events':len(rows),
            'sessions':len({r['session_id'] for r in rows if r['session_id']}),
            'first_seen':first,'last_seen':last,
            'first_hour_events':sum(1 for r in rows if float(r['ts'])<=first+3600),
            'returned_24h':last-first>=24*3600,'returned_3d':last-first>=72*3600,
            'milestones':{name:(name in names) for name in ['login','tutorial_start','tutorial_complete','recruit','lineup','stage_start','stage_success']}
        }

    def export_redacted(self, limit=5000):
        limit=max(1,min(int(limit),10000))
        with self._connect() as con:
            rows=con.execute('SELECT id,ts,player_hash,session_id,event_name,category,screen,duration_ms,success,error_code,metadata_json FROM telemetry_events ORDER BY id DESC LIMIT ?',(limit,)).fetchall()
        out=[]
        for r in rows:
            x=dict(r); x['metadata']=json.loads(x.pop('metadata_json') or '{}'); out.append(x)
        return list(reversed(out))
