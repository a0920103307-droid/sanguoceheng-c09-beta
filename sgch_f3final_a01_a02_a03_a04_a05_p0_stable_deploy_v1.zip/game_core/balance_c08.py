from __future__ import annotations
import json
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
DOC=json.loads((BASE/'c08_balance_catalog.json').read_text(encoding='utf-8'))
P=DOC['parameters']

def value(key): return P[key]['balance_value']
def temporary_value(key): return P[key]['temporary_value']

def apply_legacy_balance(modules):
    # Runtime-only overlays: source files remain intact as historical Temporary evidence.
    b=modules['battle'].PARAMS
    b['initial_fire']['value']=int(value('battle.initial_fire'))
    b['fire_per_turn']['value']=int(value('battle.fire_per_turn'))
    b['draw_per_turn']['value']=int(value('battle.draw_per_turn'))
    b['gate_hp']['value']=int(value('battle.player_gate_hp'))
    pvp=modules['pvp'].TEMP
    ladder=value('pvp.ladder'); ch=value('pvp.win_chests')
    pvp['micro_points_per_win']['value']=int(ladder['win'])
    pvp['micro_points_per_loss']['value']=int(ladder['loss'])
    pvp['micro_rank_thresholds']['value']=dict(ladder['ranks'])
    pvp['micro_chest_win_thresholds']['value']=list(ch['thresholds'])
    pvp['micro_chest_rewards']['value']=dict(ch['rewards'])
    return modules

def stage_gate_hp(order:int)->int:
    return int(value('pve.enemy_gate_hp')[int(order)-1])

def enemy_bonus(order:int):
    o=int(order)
    if o<=3:return (0,0)
    if o<=6:return (0,1)
    if o<=8:return (1,1)
    return (1,2)
