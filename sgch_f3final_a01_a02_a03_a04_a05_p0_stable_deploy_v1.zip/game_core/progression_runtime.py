from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional
from copy import deepcopy
from .general_runtime import load_catalog
from .support_runtime import support_catalog, f3d_beta_config, equipment_detail, horse_detail, book_detail
from .balance_c08 import value as c08_value

# A08 Temporary economy. Original rules are read from frozen Grid07; exact costs/stat curves are not claimed as original.
_GC=c08_value('growth.costs')
TEMP = {
    'level_cap': 20,
    'level_xp_cost': int(_GC['level_xp']),
    'level_silver_cost': int(_GC['level_silver']),
    'level_attack_every': 5,
    'level_hp_every': 3,
    'star_attack_bonus': 1,
    'star_hp_bonus': 1,
    'horse_feed_per_level': int(_GC['horse_feed']),
    'equipment_stone_per_star': int(_GC['equipment_stone']),
    'book_pages_to_master': int(_GC['book_pages']),
}

STARTER_RESOURCES = {
    '銀幣': 1600,
    '武將經驗': 60,
    '進化丹': 6,
    '張遼碎片': 50,
    '馬糧': 12,
    '鍛造石': 16,
    '兵書殘頁': 8,
    '兵符': 80,
}


@dataclass
class SoldierGrowth:
    name: str
    role_code: str
    level: int = 1
    quality: str = '藍'
    history: list = field(default_factory=list)

@dataclass
class GeneralGrowth:
    name: str
    level: int = 1
    star: int = 1
    quality: str = '橙'
    equipped_weapon: Optional[str] = None
    weapon_star: int = 1
    equipped_armor: Optional[str] = None
    armor_star: int = 1
    equipped_horse: Optional[str] = None
    horse_level: int = 1
    equipped_book: Optional[str] = None
    book_mastered: bool = False  # legacy save compatibility; books are not equipped to one general in F3-D
    refined_weapon_skill: Optional[str] = None
    refined_armor_skill: Optional[str] = None
    history: list = field(default_factory=list)

class GrowthRoster:
    def __init__(self, progression_module, starter='張遼'):
        self.m=progression_module
        self.catalog=load_catalog()
        by={x['name']:x for x in self.catalog['cards']}
        if starter not in by: raise KeyError(starter)
        self.generals={starter:GeneralGrowth(starter, quality=by[starter].get('quality') or '橙')}
        self.resources=deepcopy(STARTER_RESOURCES)
        # P04-FINAL.2: normal player progression starts at Lv.1. Late-game support is not pre-owned.
        self.account_level=1
        self.owned_equipment={}
        self.owned_horses={}
        self.owned_books={}
        self.book_levels={}
        self.f3d_test_pack_claimed=False
        # F3-C: all seven known role lines are open in the closed-beta sandbox. Only 箭手/攻城兵 are restored card names.
        soldier_payload=__import__('json').loads((__import__('pathlib').Path(__file__).resolve().parent.parent/'runtime_modules'/'soldier'/'soldier_catalog_v0.9.json').read_text(encoding='utf-8'))
        self.soldiers={x['name']:SoldierGrowth(x['name'],x['role_code'],1,x.get('quality') or '藍') for x in soldier_payload['cards']}
        self.owned_soldiers={x['name']:1 for x in soldier_payload['cards']}
        self.history=[]


    def unlocks(self):
        lv=int(self.account_level)
        return {
            'pvp':{'unlocked':lv>=15,'unlock_level':15,'confidence':'A','label':'討伐／PVP'},
            'horse':{'unlocked':bool(f3d_beta_config()['parameters']['beta_support_access']) or lv>=20,'original_unlocked':lv>=20,'unlock_level':20,'confidence':'A','label':'戰馬','beta_override':bool(f3d_beta_config()['parameters']['beta_support_access']) and lv<20},
            'book':{'unlocked':bool(f3d_beta_config()['parameters']['beta_support_access']) or lv>=32,'original_unlocked':lv>=32,'unlock_level':32,'confidence':'A','label':'兵書房','beta_override':bool(f3d_beta_config()['parameters']['beta_support_access']) and lv<32},
            'equipment':{'unlocked':bool(f3d_beta_config()['parameters']['beta_support_access']),'original_unlocked':False,'unlock_level':None,'confidence':'UNCONFIRMED','label':'裝備','beta_override':bool(f3d_beta_config()['parameters']['beta_support_access']),'note':'原版裝備系統存在，但開放等級未確認；F3-D 封測沙盒提前開放。'},
            'alliance':{'unlocked':False,'unlock_level':None,'confidence':'UNCONFIRMED','label':'聯盟','note':'聯盟系統存在，但目前沒有採信的正式開放等級；封測不提前開放。'},
            'soldier':{'unlocked':True,'unlock_level':None,'confidence':'PARTIAL_BETA_OPEN','label':'士兵','note':'封測提前開放七條已知職能線；箭手/攻城兵為可追溯名稱，其餘為封測重建卡名；原版正式解鎖等級待還原。'},
        }

    def _require_unlock(self,key):
        rec=self.unlocks()[key]
        if rec.get('unlocked'): return
        if rec.get('unlock_level') is not None: raise ValueError(f"需要主公等級 {rec['unlock_level']} 才能使用{rec['label']}")
        raise ValueError(rec.get('note') or f"{rec['label']}尚未開放")

    def profile(self,name='張遼') -> GeneralGrowth:
        if name not in self.generals: raise ValueError('尚未持有此武將')
        return self.generals[name]

    def _spend(self, needs:Dict[str,int]):
        for k,v in needs.items():
            if int(self.resources.get(k,0)) < int(v): raise ValueError(f'資源不足：{k} 需要 {v}')
        for k,v in needs.items(): self.resources[k]=int(self.resources.get(k,0))-int(v)

    def level_up(self,name='張遼',times=1):
        p=self.profile(name); done=[]
        for _ in range(max(1,int(times))):
            if p.level>=TEMP['level_cap']: break
            needs={'武將經驗':TEMP['level_xp_cost'],'銀幣':TEMP['level_silver_cost']}
            self._spend(needs); old=p.level; p.level+=1
            r={'action':'LEVEL_UP','name':name,'from':old,'to':p.level,'consumed':needs,'layer':'BALANCE_C08'}; p.history.append(r); self.history.append(r); done.append(r)
        if not done: raise ValueError('已達目前等級上限')
        return done[-1]

    def evolve(self,name='張遼'):
        p=self.profile(name)
        if p.star>=5: raise ValueError('已達5星上限')
        # Delegate requirements/star semantics to frozen Grid07; use fragments for orange starter.
        class Dummy:
            kind='GENERAL'
            def __init__(self,n,q): self.name=n; self.quality=q; self.attack=1; self.max_hp=1; self.hp=1
        d=Dummy(p.name,p.quality); self.m.set_progression(d,star=p.star,quality=p.quality)
        req=self.m.evolution_requirements(d,use_fragments=True)
        needs={'進化丹':int(req['evolution_pills']),'銀幣':int(req['silver'] or 0),f'{name}碎片':int(req['fragments'])}
        needs={k:v for k,v in needs.items() if v>0}; self._spend(needs)
        old=p.star; p.star+=1
        r={'action':'EVOLVE','name':name,'from_star':old,'to_star':p.star,'skill_unlock_count':self.unlocked_skill_count(name),'consumed':needs,'numeric_confidence':req['numeric_confidence'],'layer':'ORIGINAL_RULE_TEMP_NUMBERS'}
        p.history.append(r); self.history.append(r); return r

    def unlocked_skill_count(self,name='張遼'):
        return int(self.m.CATALOG['star_to_unlocked_skill_count'][str(self.profile(name).star)])

    def equip_item(self,name,item):
        self._require_unlock('equipment')
        p=self.profile(name); cat=support_catalog()
        rec=next((x for x in cat['equipment'] if x['name']==item),None)
        if not rec or self.owned_equipment.get(item,0)<1: raise ValueError('未持有此裝備')
        if rec['slot']=='WEAPON': p.equipped_weapon=item; p.weapon_star=max(1,p.weapon_star)
        elif rec['slot']=='ARMOR': p.equipped_armor=item; p.armor_star=max(1,p.armor_star)
        else: raise ValueError('未知裝備欄位')
        r={'action':'EQUIP_ITEM','name':name,'item':item,'slot':rec['slot']}; p.history.append(r); self.history.append(r); return r

    def strengthen_equipment(self,name,slot):
        self._require_unlock('equipment')
        p=self.profile(name); attr='weapon_star' if str(slot).upper()=='WEAPON' else 'armor_star'; equipped=p.equipped_weapon if attr=='weapon_star' else p.equipped_armor
        if not equipped: raise ValueError('請先裝備該欄位裝備')
        old=getattr(p,attr)
        if old>=5: raise ValueError('裝備已達5星')
        cfg=f3d_beta_config()['parameters']; needs={'鍛造石':int(cfg['equipment_star_stone_cost']),'銀幣':int(cfg['equipment_star_silver_cost'])}; self._spend(needs); setattr(p,attr,old+1)
        r={'action':'EQUIPMENT_STAR','name':name,'item':equipped,'from':old,'to':old+1,'consumed':needs,'layer':'TEMPORARY_COST'}; p.history.append(r); self.history.append(r); return r

    def equip_horse(self,name,horse):
        self._require_unlock('horse')
        p=self.profile(name)
        if self.owned_horses.get(horse,0)<1: raise ValueError('未持有此戰馬')
        if not any(x['name']==horse for x in support_catalog()['horses']): raise ValueError('未知戰馬')
        p.equipped_horse=horse; p.horse_level=max(1,p.horse_level)
        r={'action':'EQUIP_HORSE','name':name,'horse':horse}; p.history.append(r); self.history.append(r); return r

    def strengthen_horse(self,name):
        self._require_unlock('horse')
        p=self.profile(name)
        if not p.equipped_horse: raise ValueError('請先裝備戰馬')
        cfg=f3d_beta_config()['parameters'];
        if p.horse_level>=int(cfg['horse_level_cap']): raise ValueError('戰馬已達封測等級上限')
        needs={'馬糧':int(cfg['horse_feed_cost']),'銀幣':int(cfg['horse_silver_cost'])}; self._spend(needs); old=p.horse_level; p.horse_level+=1
        r={'action':'HORSE_LEVEL','name':name,'horse':p.equipped_horse,'from':old,'to':p.horse_level,'consumed':needs,'layer':'TEMPORARY_COST'}; p.history.append(r); self.history.append(r); return r

    def study_book(self,name,book):
        # F3-D: books are deck tactical cards, not equipment bound to one general.
        self._require_unlock('book')
        if self.owned_books.get(book,0)<1: raise ValueError('未持有此兵書')
        rec=next((x for x in support_catalog()['books'] if x['name']==book),None)
        if not rec: raise ValueError('未知兵書')
        cur=int(self.book_levels.get(book,1)); cap=max(1,int(rec.get('max_level') or 1))
        if cur>=cap: raise ValueError('此兵書已達目前最高等級')
        cfg=f3d_beta_config()['parameters']; needs={'兵書殘頁':int(cfg['book_page_cost']),'銀幣':int(cfg['book_silver_cost'])}; self._spend(needs)
        self.book_levels[book]=cur+1
        r={'action':'BOOK_LEVEL','book':book,'from':cur,'to':cur+1,'consumed':needs,'layer':'BETA_COST_ORIGINAL_LEVEL_STRUCTURE'}; self.history.append(r); return r

    def refine_equipment(self,name,slot,skill_name):
        self._require_unlock('equipment'); p=self.profile(name); slot=str(slot).upper()
        item=p.equipped_weapon if slot=='WEAPON' else p.equipped_armor if slot=='ARMOR' else None
        if not item: raise ValueError('請先穿戴對應裝備')
        cat=load_catalog(); card=next((x for x in cat['cards'] if x['name']==name),None)
        skills=[str(x.get('name')) for x in (card.get('skills') if card else []) if x.get('name')]
        if skill_name not in skills: raise ValueError('淬鍊只能選該武將既有技能；五星只會使既有技能+1')
        cfg=f3d_beta_config()['parameters']; needs={'鍛造石':int(cfg['equipment_refine_stone_cost']),'銀幣':int(cfg['equipment_refine_silver_cost'])}; self._spend(needs)
        if slot=='WEAPON': p.refined_weapon_skill=skill_name
        else: p.refined_armor_skill=skill_name
        star=p.weapon_star if slot=='WEAPON' else p.armor_star
        r={'action':'EQUIPMENT_REFINE','name':name,'item':item,'slot':slot,'skill':skill_name,'five_star_skill_plus_one_active':bool(star>=5),'consumed':needs,'layer':'ORIGINAL_RULE_BETA_COST'}; p.history.append(r); self.history.append(r); return r

    def claim_f3d_test_pack(self):
        if self.f3d_test_pack_claimed: raise ValueError('F3-D 測試支援包已領取')
        pack=f3d_beta_config()['test_pack']
        for k,v in pack['resources'].items(): self.resources[k]=int(self.resources.get(k,0))+int(v)
        for n in pack['equipment']: self.owned_equipment[n]=max(1,int(self.owned_equipment.get(n,0)))
        for n in pack['horses']: self.owned_horses[n]=max(1,int(self.owned_horses.get(n,0)))
        for n in pack['books']:
            self.owned_books[n]=max(1,int(self.owned_books.get(n,0))); self.book_levels.setdefault(n,1)
        self.f3d_test_pack_claimed=True
        r={'action':'CLAIM_F3D_TEST_PACK','equipment':list(pack['equipment']),'horses':list(pack['horses']),'books':list(pack['books']),'resources':dict(pack['resources']),'layer':'CLOSED_BETA_ONLY'}; self.history.append(r); return r

    def support_state(self):
        cat=support_catalog()
        eq=[]
        for x in cat['equipment']:
            d=equipment_detail(x); d['owned']=int(self.owned_equipment.get(x['name'],0)); eq.append(d)
        hs=[]
        for x in cat['horses']:
            d=horse_detail(x); d['owned']=int(self.owned_horses.get(x['name'],0)); hs.append(d)
        bs=[]
        for x in cat['books']:
            d=book_detail(x); d['owned']=int(self.owned_books.get(x['name'],0)); d['level']=int(self.book_levels.get(x['name'],1)); bs.append(d)
        return {'version':'F3-D','test_pack_claimed':bool(self.f3d_test_pack_claimed),'equipment':eq,'horses':hs,'books':bs,'exclusive_fates':list(cat['exclusive_fates']),'rules':{'equipment':'武器加攻擊、防具加生命；五星裝備淬鍊命中的既有技能+1；裝備不占牌組聲望。','horse':'20級開啟為原版確認規則；一匹戰馬掛載武將，等級提升會提高技能等級。','book':'32級兵書房為原版確認規則；兵書是牌組戰術卡，不掛在單一武將、不占戰場格。','beta':'F3-D 為封測完整測試，提前開放支援系統；未確認數值不冒充原版。'}}

    def soldier_profile(self,name):
        if name not in self.soldiers: raise ValueError('未知士兵')
        return self.soldiers[name]

    def upgrade_soldier(self,name,times=1):
        p=self.soldier_profile(name); done=None
        import json
        from pathlib import Path
        cfg=json.loads((Path(__file__).resolve().parent.parent/'runtime_modules'/'soldier'/'temporary_soldier_f3c_params.json').read_text(encoding='utf-8'))['parameters']
        for _ in range(max(1,int(times))):
            if p.level>=int(cfg['max_soldier_level']['value']): break
            mult=1+(p.level//5)*int(cfg['cost_growth_every_5_levels']['value'])
            needs={'兵符':int(cfg['soldier_symbol_base_cost']['value'])*mult,'銀幣':int(cfg['silver_base_cost']['value'])*mult}
            self._spend(needs); old=p.level;p.level+=1
            r={'action':'SOLDIER_UPGRADE','name':name,'role_code':p.role_code,'from':old,'to':p.level,'consumed':needs,'layer':'BETA_BALANCE'}
            p.history.append(r);self.history.append(r);done=r
        if done is None: raise ValueError('已達封測士兵等級上限')
        return done

    def soldier_runtime_view(self,name):
        import json
        from pathlib import Path
        payload=json.loads((Path(__file__).resolve().parent.parent/'runtime_modules'/'soldier'/'soldier_catalog_v0.9.json').read_text(encoding='utf-8'))
        d=next(x for x in payload['cards'] if x['name']==name);p=self.soldier_profile(name)
        cfg=json.loads((Path(__file__).resolve().parent.parent/'runtime_modules'/'soldier'/'temporary_soldier_f3c_params.json').read_text(encoding='utf-8'))['parameters']
        atk=int(d['attack'])+(p.level-1)//int(cfg['attack_growth_every_levels']['value']);hp=int(d['hp'])+(p.level-1)//int(cfg['hp_growth_every_levels']['value'])
        return {**asdict(p),'attack':atk,'hp':hp,'cost_fame':9,'core_skill':d['core_skill'],'official_name_confirmed':bool(d['official_name_confirmed']),'source_layer':d['source_layer']}

    def battle_modifiers(self,name='張遼'):
        p=self.profile(name)
        return {
            'attack_bonus': (p.level-1)//TEMP['level_attack_every'] + (p.star-1)*TEMP['star_attack_bonus'],
            'hp_bonus': (p.level-1)//TEMP['level_hp_every'] + (p.star-1)*TEMP['star_hp_bonus'],
            'unlocked_skill_count': self.unlocked_skill_count(name),
        }

    def apply_to_card(self,card):
        if card.name not in self.generals: return card
        p=self.profile(card.name); mod=self.battle_modifiers(card.name)
        card.attack+=mod['attack_bonus']; card.max_hp+=mod['hp_bonus']; card.hp=card.max_hp
        skills=list(getattr(card,'a04_skills',[]) or [])
        card.a08_all_skills=skills; card.a04_skills=skills[:mod['unlocked_skill_count']]
        card.a08_growth={'level':p.level,'star':p.star,'attack_bonus':mod['attack_bonus'],'hp_bonus':mod['hp_bonus']}
        return card

    def state(self):
        return {
            'version':'F3-D','account_level':int(self.account_level),'unlocks':self.unlocks(),'resources':dict(self.resources),
            'generals':{k:{**asdict(v),'unlocked_skill_count':self.unlocked_skill_count(k),'battle_modifiers':self.battle_modifiers(k)} for k,v in self.generals.items()},
            'owned_equipment':dict(self.owned_equipment),'owned_horses':dict(self.owned_horses),'owned_books':dict(self.owned_books),'book_levels':dict(self.book_levels),'f3d_test_pack_claimed':bool(self.f3d_test_pack_claimed),'support':self.support_state(),'owned_soldiers':dict(self.owned_soldiers),'soldiers':{k:self.soldier_runtime_view(k) for k in self.soldiers},
            'temporary_parameters':dict(TEMP),'xp_rule_note':'武將經驗用於武將升級；每級所需經驗與銀幣目前採封測平衡值，非聲稱原版精確曲線。',
        }
