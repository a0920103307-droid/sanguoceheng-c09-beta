# A05｜統一返回／導航邏輯

完成日期：2026-09-07

## 目標
統一 Web 頁面按鈕、瀏覽器返回、Android WebView 返回鍵與戰鬥／結算返回行為，避免不同入口各自跳頁、返回主介面或殘留戰鬥狀態。

## 本次修改
1. 新增後端 `back_stages` 動作：
   - 返回選關頁 `STAGE_SELECT`。
   - 清除當前 battle controller，避免離開戰鬥後舊戰鬥狀態殘留。
   - 保留已選關卡，方便重新挑戰或查看關卡。
2. 前端新增統一 `sgchNavigateBack()`：
   - 封測回報視窗開啟時：先關閉回報視窗。
   - 教學浮層開啟時：先關閉教學浮層。
   - 戰鬥中：確認後返回「選擇關卡」，不再直接丟回主介面。
   - 結算頁：返回「選擇關卡」。
   - 其他二級頁：返回主介面。
   - 主介面：不攔截系統返回。
3. `window.sgchHandleBack` 統一呼叫同一套返回規則，供 Android WebView 返回鍵使用。
4. 加入 History API：
   - 成功切換主要畫面時記錄 browser history state。
   - `popstate`（瀏覽器／系統返回）改走同一套 `sgchNavigateBack()`。
   - 返回過程使用同步旗標避免重複 push history。
5. 登入完成後建立目前 screen 的初始 history state，避免第一下返回出現錯誤層級。

## 返回層級
- MAIN → 交還系統處理
- STAGE_SELECT / GROWTH / TAVERN / COLLECTION / CODEX / DUNGEONS / ECONOMY / ARENA / ALLIANCE / FAIR_TEST → MAIN
- BATTLE → 確認 → STAGE_SELECT
- RESULT → STAGE_SELECT
- Beta Feedback overlay → 關閉 overlay
- Tutorial overlay → 關閉 overlay

## 驗收
- Python 全專案編譯：PASS
- 前端 JavaScript `node --check`：PASS
- `back_stages` 路由已加入 API dispatcher：PASS
- `back_stages` controller 會清除 battle controller：PASS（靜態檢查）
- `sgchHandleBack` 與 `popstate` 共用統一返回函式：PASS（靜態檢查）

## 第一階段完成節點
A01～A05 已完成候選整合，可封為「P0 穩定版」進行一次性部署與手機驗收。
