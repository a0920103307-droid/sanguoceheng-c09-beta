# Database migration

This prototype uses SQLite and creates/updates required tables with idempotent `CREATE TABLE IF NOT EXISTS` statements.

Run before first deployment:

```bash
python migrations/001_initialize_databases.py
```

Set `SGCH_ENV=staging` or `SGCH_ENV=production` before running if needed. The same environment must be used when starting the server.

## 003 auth session persistence
`003_auth_sessions_to_postgres.py` migrates only active, unexpired auth sessions from the legacy SQLite `sessions` table into PostgreSQL `auth_sessions`. Run dry-run first, then `--apply` only after the A01 account migration is verified.

## 004 player save persistence
`004_player_saves_to_postgres.py` migrates canonical `cloud_saves` and `cloud_backups` into PostgreSQL. Run after account/session migration checks and use dry-run before `--apply`.
