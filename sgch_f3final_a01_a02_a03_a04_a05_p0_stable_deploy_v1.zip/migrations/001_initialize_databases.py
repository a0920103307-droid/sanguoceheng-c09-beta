from pathlib import Path
import os, sys
BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))
from game_core.project_config import load_project_config
from game_core.auth import AuthStore
from game_core.cloud_store import CloudSaveStore
from game_core.telemetry import TelemetryStore
from game_core.closed_beta import ClosedBetaStore

cfg=load_project_config(BASE)
AuthStore(cfg.save_dir/'auth'/'accounts.sqlite3')
CloudSaveStore(cfg.save_dir/'cloud'/'cloud_saves.sqlite3')
TelemetryStore(cfg.save_dir/'telemetry'/'telemetry.sqlite3')
ClosedBetaStore(cfg.save_dir/'beta'/'feedback.sqlite3')
print(f'Database initialization complete: env={cfg.environment}, save_dir={cfg.save_dir}')
