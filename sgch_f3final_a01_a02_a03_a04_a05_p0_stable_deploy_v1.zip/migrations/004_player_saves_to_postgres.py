from __future__ import annotations
import argparse, os, sqlite3
from pathlib import Path


def rows(path, table):
    if not path.exists(): return []
    con=sqlite3.connect(path); con.row_factory=sqlite3.Row
    try:return [dict(r) for r in con.execute(f'SELECT * FROM {table}').fetchall()]
    except sqlite3.OperationalError:return []
    finally:con.close()


def main():
    ap=argparse.ArgumentParser(description='Migrate SGCH canonical player saves SQLite -> PostgreSQL')
    ap.add_argument('--sqlite',required=True)
    ap.add_argument('--database-url',default=os.getenv('SGCH_SAVE_DATABASE_URL') or os.getenv('SGCH_AUTH_DATABASE_URL') or os.getenv('DATABASE_URL'))
    ap.add_argument('--apply',action='store_true')
    args=ap.parse_args(); p=Path(args.sqlite)
    saves=rows(p,'cloud_saves'); backups=rows(p,'cloud_backups')
    print(f'saves={len(saves)} backups={len(backups)}')
    if not args.apply:
        print('DRY_RUN: no PostgreSQL writes performed'); return 0
    if not args.database_url: raise SystemExit('DATABASE_URL is required with --apply')
    import psycopg
    with psycopg.connect(args.database_url) as con:
        with con.cursor() as cur:
            cur.execute(Path(__file__).with_name('004_player_saves_postgres.sql').read_text(encoding='utf-8'))
            for r in saves:
                cur.execute('''INSERT INTO player_cloud_saves(player_id,revision,save_json,checksum,updated_at,schema_version)
                  VALUES(%s,%s,%s,%s,%s,%s) ON CONFLICT(player_id) DO UPDATE SET
                  revision=GREATEST(player_cloud_saves.revision,EXCLUDED.revision),
                  save_json=CASE WHEN EXCLUDED.revision>=player_cloud_saves.revision THEN EXCLUDED.save_json ELSE player_cloud_saves.save_json END,
                  checksum=CASE WHEN EXCLUDED.revision>=player_cloud_saves.revision THEN EXCLUDED.checksum ELSE player_cloud_saves.checksum END,
                  updated_at=GREATEST(player_cloud_saves.updated_at,EXCLUDED.updated_at),
                  schema_version=GREATEST(player_cloud_saves.schema_version,EXCLUDED.schema_version)''',
                  (r['player_id'],int(r['revision']),r['save_json'],r['checksum'],int(r['updated_at']),int(r['schema_version'])))
            for r in backups:
                cur.execute('''INSERT INTO player_cloud_backups(player_id,revision,save_json,checksum,created_at,reason)
                  SELECT %s,%s,%s,%s,%s,%s WHERE NOT EXISTS(
                    SELECT 1 FROM player_cloud_backups WHERE player_id=%s AND revision=%s AND checksum=%s AND created_at=%s)''',
                  (r['player_id'],int(r['revision']),r['save_json'],r['checksum'],int(r['created_at']),r['reason'],r['player_id'],int(r['revision']),r['checksum'],int(r['created_at'])))
    print('migration_complete=1'); return 0

if __name__=='__main__': raise SystemExit(main())
