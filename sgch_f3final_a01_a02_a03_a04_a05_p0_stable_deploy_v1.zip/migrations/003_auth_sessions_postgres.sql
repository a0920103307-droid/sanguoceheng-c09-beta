CREATE TABLE IF NOT EXISTS auth_sessions(
  token_hash VARCHAR(64) PRIMARY KEY,
  player_id VARCHAR(40) NOT NULL,
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_player_id ON auth_sessions(player_id);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_expires_at ON auth_sessions(expires_at);
