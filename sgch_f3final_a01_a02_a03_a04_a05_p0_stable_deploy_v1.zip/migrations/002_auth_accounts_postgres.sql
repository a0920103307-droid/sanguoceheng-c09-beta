-- A01 | Account persistence schema for Render PostgreSQL.
-- Safe/idempotent: creates only the account table + lookup index.
-- Sessions intentionally stay out of PostgreSQL until A02.

CREATE TABLE IF NOT EXISTS auth_players(
  player_id VARCHAR(40) PRIMARY KEY,
  username VARCHAR(32) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at BIGINT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_auth_players_username
  ON auth_players(username);
