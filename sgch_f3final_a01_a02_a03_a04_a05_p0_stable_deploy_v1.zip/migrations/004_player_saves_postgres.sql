CREATE TABLE IF NOT EXISTS player_cloud_saves(
  player_id VARCHAR(40) PRIMARY KEY,
  revision BIGINT NOT NULL,
  save_json TEXT NOT NULL,
  checksum VARCHAR(64) NOT NULL,
  updated_at BIGINT NOT NULL,
  schema_version INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS player_cloud_backups(
  backup_id BIGSERIAL PRIMARY KEY,
  player_id VARCHAR(40) NOT NULL,
  revision BIGINT NOT NULL,
  save_json TEXT NOT NULL,
  checksum VARCHAR(64) NOT NULL,
  created_at BIGINT NOT NULL,
  reason TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_player_cloud_backups_player ON player_cloud_backups(player_id,backup_id DESC);
