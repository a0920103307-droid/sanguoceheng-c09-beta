from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))

from game_core.project_config import load_project_config


def load_sqlite_accounts(path: Path):
    if not path.exists():
        return []
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    try:
        exists = con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='players'"
        ).fetchone()
        if not exists:
            return []
        rows = con.execute(
            "SELECT player_id,username,password_hash,created_at FROM players ORDER BY created_at,player_id"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="A01: migrate account records from the legacy SQLite auth DB to Render PostgreSQL"
    )
    parser.add_argument("--apply", action="store_true", help="perform inserts; default is dry-run")
    parser.add_argument("--sqlite", help="override legacy accounts.sqlite3 path")
    args = parser.parse_args()

    cfg = load_project_config(BASE)
    sqlite_path = Path(args.sqlite) if args.sqlite else cfg.save_dir / "auth" / "accounts.sqlite3"
    rows = load_sqlite_accounts(sqlite_path)
    print(f"A01 source={sqlite_path} accounts={len(rows)} mode={'APPLY' if args.apply else 'DRY_RUN'}")

    database_url = (os.getenv("SGCH_AUTH_DATABASE_URL") or os.getenv("DATABASE_URL") or "").strip()
    if not database_url:
        print("ERROR: SGCH_AUTH_DATABASE_URL or DATABASE_URL is required", file=sys.stderr)
        return 2

    try:
        import psycopg  # type: ignore
    except ImportError:
        print("ERROR: psycopg is not installed; run pip install -r requirements.txt", file=sys.stderr)
        return 3

    schema_sql = (BASE / "migrations" / "002_auth_accounts_postgres.sql").read_text(encoding="utf-8")
    with psycopg.connect(database_url) as con:
        with con.cursor() as cur:
            cur.execute(schema_sql)
            cur.execute("SELECT player_id,username FROM auth_players")
            by_pid = {str(pid): str(username) for pid, username in cur.fetchall()}
            cur.execute("SELECT username,player_id FROM auth_players")
            by_user = {str(username): str(pid) for username, pid in cur.fetchall()}

            conflicts = []
            missing = []
            for row in rows:
                pid = str(row["player_id"])
                user = str(row["username"])
                existing_user = by_pid.get(pid)
                existing_pid = by_user.get(user)
                if existing_user is not None and existing_user != user:
                    conflicts.append((pid, user, "player_id already mapped to another username"))
                elif existing_pid is not None and existing_pid != pid:
                    conflicts.append((pid, user, "username already mapped to another player_id"))
                elif existing_user is None and existing_pid is None:
                    missing.append(row)

            print(f"existing={len(rows)-len(missing)-len(conflicts)} missing={len(missing)} conflicts={len(conflicts)}")
            for pid, user, reason in conflicts:
                print(f"CONFLICT player_id={pid} username={user}: {reason}")

            if conflicts:
                print("ABORT: resolve conflicts before cutover; no account rows inserted", file=sys.stderr)
                con.rollback()
                return 4

            if not args.apply:
                con.rollback()
                print("DRY_RUN complete; no changes committed")
                return 0

            for row in missing:
                cur.execute(
                    "INSERT INTO auth_players(player_id,username,password_hash,created_at) VALUES(%s,%s,%s,%s)",
                    (
                        row["player_id"],
                        row["username"],
                        row["password_hash"],
                        int(row["created_at"]),
                    ),
                )
            con.commit()
            print(f"APPLY complete; inserted={len(missing)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
