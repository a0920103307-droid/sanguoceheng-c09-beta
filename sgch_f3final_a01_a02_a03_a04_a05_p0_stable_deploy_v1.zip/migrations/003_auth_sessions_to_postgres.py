from __future__ import annotations

import argparse
import os
import sqlite3
import time
from pathlib import Path


def load_rows(sqlite_path: Path):
    if not sqlite_path.exists():
        return []
    con = sqlite3.connect(sqlite_path)
    con.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in con.execute(
            "SELECT token_hash,player_id,expires_at,created_at FROM sessions WHERE expires_at>? ORDER BY created_at",
            (int(time.time()),),
        ).fetchall()]
    except sqlite3.OperationalError:
        return []
    finally:
        con.close()


def main():
    ap = argparse.ArgumentParser(description="Migrate active SGCH auth sessions from SQLite to PostgreSQL")
    ap.add_argument("--sqlite", required=True, help="Path to existing accounts.sqlite3")
    ap.add_argument("--database-url", default=os.getenv("SGCH_SESSION_DATABASE_URL") or os.getenv("SGCH_AUTH_DATABASE_URL") or os.getenv("DATABASE_URL"))
    ap.add_argument("--apply", action="store_true", help="Actually write to PostgreSQL; default is dry-run")
    args = ap.parse_args()
    rows = load_rows(Path(args.sqlite))
    print(f"active_sessions={len(rows)}")
    if not args.apply:
        print("DRY_RUN: no PostgreSQL writes performed")
        return 0
    if not args.database_url:
        raise SystemExit("DATABASE_URL is required with --apply")
    import psycopg
    inserted = 0
    with psycopg.connect(args.database_url) as con:
        with con.cursor() as cur:
            cur.execute(Path(__file__).with_name("003_auth_sessions_postgres.sql").read_text(encoding="utf-8"))
            for r in rows:
                cur.execute(
                    """
                    INSERT INTO auth_sessions(token_hash,player_id,expires_at,created_at)
                    VALUES(%s,%s,%s,%s)
                    ON CONFLICT(token_hash) DO UPDATE SET
                      player_id=EXCLUDED.player_id,
                      expires_at=EXCLUDED.expires_at,
                      created_at=EXCLUDED.created_at
                    """,
                    (r["token_hash"], r["player_id"], int(r["expires_at"]), int(r["created_at"])),
                )
                inserted += 1
    print(f"migrated_sessions={inserted}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
