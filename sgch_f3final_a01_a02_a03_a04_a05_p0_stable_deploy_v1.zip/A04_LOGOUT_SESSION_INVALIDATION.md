# A04｜登出／Session 失效狀態統一

完成日期：2026-09-07

## 目標
統一「主動登出」與「Session 過期／被撤銷」後的前後端狀態，避免畫面上方顯示未登入，但舊的遊戲頁面、商城、招募、圖鑑或戰鬥內容仍殘留。

## 本次修改
1. 後端新增統一 `_auth_required()`：
   - 受保護 API Session 無效時固定回傳 HTTP 401 / `AUTH_REQUIRED`。
   - 同時清除 `sgch_session` 與 `sgch_guest` Cookie，避免失效 Cookie 繼續殘留。
2. 主動登出：
   - 撤銷 Session。
   - 清除 guest session。
   - 移除該玩家記憶體 controller cache。
   - 清除登入 Cookie。
   - 回傳 `logged_out: true`。
3. 前端加入全域 401 處理：
   - 非登入／註冊／恢復等公開 Auth API 收到 401 時，立即切換到統一未登入 UI。
   - 不再只依賴某一個 `act()` 流程處理 Session 失效。
4. 統一未登入 UI：
   - 清空 `S`、已選卡、真人 PVP 暫存狀態。
   - 停止真人 PVP polling。
   - 隱藏主頁、選關、養成、招募、圖鑑、副本、商城、競技、聯盟、公平測試、戰鬥、結算、教學、回報視窗。
   - 隱藏封測回報浮動按鈕。
   - 資源列清空、身份列固定顯示「未登入」。
   - 清空密碼欄位。
5. `boot()` 遇到 Session 失效時改走同一個 `enterLoggedOutUi()`，避免兩套狀態切換邏輯互相打架。

## 保留設計
- 本機封測 recovery 資料不因登出而刪除，避免使用者因 Render 重建而失去帳號／存檔恢復能力。
- 錯誤密碼登入的 401 不會被全域 Session 失效處理攔截，仍可正常顯示登入錯誤。

## 本機驗收
- 未登入讀取 `/api/state` → 401 `AUTH_REQUIRED`：PASS
- 註冊新帳號 → 201：PASS
- 登入狀態 `/api/auth/me` → authenticated=true：PASS
- 登入後 `/api/state` → 200：PASS
- 主動登出 → logged_out=true：PASS
- 登出後 `/api/auth/me` → authenticated=false：PASS
- 登出後 `/api/state` → 401 `AUTH_REQUIRED`：PASS
- 全 Python 編譯：PASS

## 範圍邊界
A04 只處理登出／失效狀態一致性；返回與導航規則留給 A05。
