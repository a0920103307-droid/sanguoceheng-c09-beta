# A01 驗收結果｜帳號資料持久化

狀態：**程式候選版完成；尚未部署、尚未切換 Render PostgreSQL。**

已完成：
- 帳號資料存取層拆分。
- PostgreSQL `auth_players` schema。
- SQLite → PostgreSQL dry-run / apply 遷移工具。
- 安全切換旗標 `SGCH_AUTH_BACKEND=sqlite|postgres`，預設 sqlite。
- PostgreSQL driver 依賴加入 requirements。
- 回滾策略與操作順序文件化。
- SQLite 註冊／登入／重複帳號／Session 相容性 smoke test 通過。
- 全 Python 編譯檢查通過。

A01 尚需真實 Render 環境驗收：
1. 取得目前線上 `accounts.sqlite3` 或在舊實例可讀期間執行遷移。
2. 對 Render PostgreSQL 執行 dry-run，確認 conflicts=0。
3. apply 後核對筆數。
4. 設定 `SGCH_AUTH_BACKEND=postgres`。
5. 驗證既有帳號在 restart / redeploy 後仍可登入。

注意：Session 仍為 SQLite，這是刻意保留給 A02；玩家存檔仍未處理，屬 A03。
