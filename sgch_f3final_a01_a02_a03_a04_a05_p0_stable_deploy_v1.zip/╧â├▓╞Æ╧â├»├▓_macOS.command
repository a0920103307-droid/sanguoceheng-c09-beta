#!/bin/bash
cd "$(dirname "$0")"
export SGCH_ENV=staging
python3 start_game.py
