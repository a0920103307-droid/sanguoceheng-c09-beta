# P04-FINAL.3｜F3-A 卡牌資料結構重整完成報告

## 結果
PASS（本機資料結構與語法驗證）

## 完成內容
- 新增 `card_schema_v0.3.json` 與 `card_catalog_v0.3.json`。
- 將武將、士兵、戰馬、兵書、軍令、裝備統一成同一份卡牌資料契約。
- 新增 progression / placement / relationships / acquisition_detail / evidence 五組正式欄位。
- 保留舊 attack/hp/cost_fame/skills 欄位，避免目前原型戰鬥中斷。
- 卡牌載入器預設改讀 v0.3，並增加新欄位驗證。
- 只有分類線索、沒有實際卡名的兵種不偽造成卡牌，改放 `soldier_role_definitions`。
- 張遼→龍鱗刀、小喬→煙蘿紗衣以專屬裝備/緣分接口落入資料結構。
- 戰馬定義為掛載武將、不占戰場格；兵書/軍令不占戰場格；裝備不進牌組。

## 統一後卡牌數
- 武將 GENERAL：55
- 士兵 SOLDIER：2（只錄入目前可追溯實際卡名）
- 戰馬 HORSE：12
- 兵書 BOOK：15
- 軍令 ORDER：6
- 裝備 EQUIPMENT：26
- 合計：116

## 驗證
- `card_loader.load_catalog()`：PASS，載入 116 張。
- Python `py_compile`：PASS。
- 場上占格規則檢查：PASS。
- 非場上卡（戰馬/兵書/軍令/裝備）占格規則：PASS。
- 專屬裝備關係存在性檢查：PASS。

## 邊界
F3-A 不調最終戰鬥數值。武將/士兵的暫定攻血與未確認 Cost 仍保留 C/UNCONFIRMED 標記，留待 F3-G 數值重整。

## 下一步
F3-B｜武將差異化與情緣系統。
