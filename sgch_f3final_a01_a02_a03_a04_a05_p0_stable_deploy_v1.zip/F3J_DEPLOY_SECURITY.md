# F3-J｜安全／部署／封測環境

## 環境分離
- `staging`：封測驗證，可開 `SGCH_BETA_TOOLS=1`、訪客登入。
- `production`：預設關閉封測捷徑與訪客登入，Cookie 預設 `Secure`。
- 正式部署不可把 `.env`、`save_data/`、`logs/`、SQLite 資料庫打入公開程式包。

## 管理資料
`/api/beta/report`、`/api/telemetry/summary`、`/api/telemetry/export` 在 production 需要 `X-SGCH-Admin`，值必須等於主機 Secret `SGCH_ADMIN_TOKEN`。

## 安全標頭
Web/API 統一加入 `nosniff`、DENY frame、same-origin referrer、Permissions-Policy 與 CSP。

## 封測工具
`beta_set_test_level`、F3-D 測試包、封測初始資源包在 production 預設停用；受控封測時由主機環境變數 `SGCH_BETA_TOOLS=1` 顯式開啟。

## 備份
部署前／重大版本前執行：
`python ops/backup_runtime.py --save-dir <實際 save_data 路徑>`

## 部署前檢查
`python ops/preflight.py`

## 外部封測阻擋事項
若程式碼倉庫仍為 Public，外部封測前應先修復 Render 對 Private GitHub repo 的授權，再把 repo 設為 Private。不要先改 Private 而讓 Render 失去 clone 權限。
