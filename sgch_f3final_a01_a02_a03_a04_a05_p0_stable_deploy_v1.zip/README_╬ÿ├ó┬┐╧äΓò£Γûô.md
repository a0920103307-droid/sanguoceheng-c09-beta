# 三國策衡 Prototype v0.4 — D10 IP Clean｜C09 / P01 部署 README

## 用途
此包是 C09 真人封閉測試／下一步 P01 部署檢查專用的純淨遊戲 Build。它不是內部交接包，只包含部署與執行所需的純淨遊戲資產。

## 環境需求
- Python 3.10+
- Runtime 無第三方 Python 套件，`requirements.txt` 僅記錄需求。
- 預設 staging：`0.0.0.0:8080`

## Windows 本機／內網啟動
1. 安裝 Python 3.10+，確認 `py -3 --version` 或 `python --version`。
2. 雙擊 `啟動_Windows.bat`。
3. 同機瀏覽器開 `http://127.0.0.1:8080/`。

## macOS 本機／內網啟動
1. 確認 `python3 --version` 為 3.10+。
2. 首次若被系統阻擋，可在終端執行 `chmod +x 啟動_macOS.command`。
3. 雙擊 `啟動_macOS.command`，或終端執行 `./啟動_macOS.command`。
4. 同機瀏覽器開 `http://127.0.0.1:8080/`。

## 第一次部署前：資料庫初始化
Staging：
```bash
export SGCH_ENV=staging
python3 migrations/001_initialize_databases.py
```
Windows PowerShell：
```powershell
$env:SGCH_ENV='staging'
py -3 migrations/001_initialize_databases.py
```
資料會放在 `save_data/staging/`。正式環境改用 `SGCH_ENV=production`。

## Linux／雲端部署
```bash
cd /path/to/build
export SGCH_ENV=production
export SGCH_HOST=0.0.0.0
export SGCH_PORT=8080
python3 migrations/001_initialize_databases.py
python3 start_game.py
```
建議由 Nginx／Caddy／Cloudflare Tunnel 等提供 HTTPS 反向代理。PWA 與外部手機測試建議使用 HTTPS。

## 登入與測試帳號
開啟首頁後可使用「註冊」建立測試帳號：帳號 3–32 字、密碼至少 8 字。正式 C09 建議每位測試者使用獨立帳號，不使用訪客模式，以利 24h／3d 回流追蹤。

## Web / PWA
`web/` 內含首頁、manifest、service worker、offline page 與角色／Icon 資產。伺服器啟動後由同一服務提供。

## 資料庫位置
依 `config/<environment>.json` 的 `save_dir` 建立：
- `auth/accounts.sqlite3`
- `cloud/cloud_saves.sqlite3`
- `telemetry/telemetry.sqlite3`
- `beta/feedback.sqlite3`

## P01 部署檢查重點
1. Python 3.10+ 可啟動。
2. `migrations/001_initialize_databases.py` 可重複執行而不破壞資料。
3. 首頁／PWA manifest／service worker 正常回應。
4. 註冊、登入、登出正常。
5. 登入後可進入教學與主遊戲流程。
6. 重啟服務後正式帳號雲端存檔仍存在。
7. `save_data` 有寫入權限，且不應提交到公開原始碼庫。
8. 對外部署必須使用 HTTPS，並限制管理／資料匯出端點只給測試管理者。

## Build 標記
- Product: 三國策衡
- Prototype: v0.4
- IP Clean milestone: D10
- Package purpose: C09 deployment / P01 deployment check
