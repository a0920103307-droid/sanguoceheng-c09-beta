from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional
import json

BASE = Path(__file__).resolve().parent
CATALOG = json.loads((BASE/'dungeon_catalog_v1.0.json').read_text(encoding='utf-8'))
TEMP = json.loads((BASE/'temporary_dungeon_params.json').read_text(encoding='utf-8'))['parameters']
def tp(k): return TEMP[k]['value']

@dataclass(frozen=True)
class DungeonDef:
    dungeon_id: str
    name: str
    category: str
    implemented: bool = True
    unlock_level: Optional[int] = None
    confidence: str = 'C'
    drop_semantic: str = ''
    notes: str = ''

@dataclass
class DungeonState:
    player_level: int = 1
    daily_runs: Dict[str, int] = field(default_factory=dict)
    inventory: Dict[str, int] = field(default_factory=dict)
    alliance_score: int = 0
    boss_index: int = 1
    boss_hp: int = field(default_factory=lambda: int(tp('alliance_boss_hp')))
    boss_killed: bool = False
    claimed_boss_clear: bool = False


def dungeon_defs() -> Dict[str, DungeonDef]:
    out = {}
    for r in CATALOG['dungeons']:
        out[r['dungeon_id']] = DungeonDef(
            dungeon_id=r['dungeon_id'], name=r['name'], category=r['category'],
            implemented=bool(r['implemented']), unlock_level=r.get('unlock_level'),
            confidence=r.get('confidence','C'), drop_semantic=r.get('drop_semantic',''),
            notes=r.get('flow','')
        )
    return out

class DungeonEngine:
    def __init__(self, state: Optional[DungeonState] = None):
        self.state = state or DungeonState()
        self.defs = dungeon_defs()
        self.log: List[Dict[str,Any]] = []

    def _daily_limit(self, d: DungeonDef) -> int:
        if d.category == 'ALLIANCE_BOSS':
            return int(tp('alliance_boss_daily_limit'))
        return int(tp('generic_daily_limit'))

    def can_enter(self, dungeon_id: str) -> bool:
        d = self.defs[dungeon_id]
        if not d.implemented:
            return False
        if d.unlock_level is not None and self.state.player_level < d.unlock_level:
            return False
        return self.state.daily_runs.get(dungeon_id, 0) < self._daily_limit(d)

    def begin(self, dungeon_id: str) -> Dict[str,Any]:
        d = self.defs[dungeon_id]
        if not d.implemented:
            raise ValueError('dungeon not implemented')
        if d.unlock_level is not None and self.state.player_level < d.unlock_level:
            raise ValueError('player level too low')
        used = self.state.daily_runs.get(dungeon_id,0)
        limit = self._daily_limit(d)
        if used >= limit:
            raise ValueError('daily dungeon limit reached')
        self.state.daily_runs[dungeon_id] = used + 1
        r={'action':'DUNGEON_BEGIN','dungeon_id':dungeon_id,'run':used+1,'daily_limit':limit,'limit_confidence':'C'}
        self.log.append(r); return r

    def finish(self, dungeon_id: str, won: bool, *, reward_variant: Optional[str]=None) -> Dict[str,Any]:
        d = self.defs[dungeon_id]
        if d.category == 'ALLIANCE_BOSS':
            raise ValueError('use hit_alliance_boss for alliance boss')
        if not won:
            r={'action':'DUNGEON_LOSS','dungeon_id':dungeon_id,'drops':[]}; self.log.append(r); return r
        drops=[]
        if d.category == 'HORSE':
            if reward_variant in ('綠整馬','藍整馬'):
                item = reward_variant
            elif reward_variant in ('紫馬碎片','橙馬碎片'):
                item = reward_variant
            else:
                item = '戰馬掉落（類型未指定）'
            qty=int(tp('horse_reward_qty')); self._add(item,qty); drops.append(self._drop(item,qty,'A semantic/C qty'))
        elif d.category == 'RESOURCE':
            for item in ('美酒','玄鐵'):
                qty=int(tp('resource_reward_qty')); self._add(item,qty); drops.append(self._drop(item,qty,'A identity/C qty'))
        elif d.category == 'EQUIPMENT':
            item = reward_variant or '裝備碎片'
            qty=int(tp('equipment_reward_qty')); self._add(item,qty); drops.append(self._drop(item,qty,'A semantic/C qty'))
        elif d.category == 'TREASURE':
            item = reward_variant or '銀幣/物品'
            qty=int(tp('treasure_reward_qty')); self._add(item,qty); drops.append(self._drop(item,qty,'A semantic/C qty'))
        else:
            raise ValueError('unsupported implemented dungeon category')
        r={'action':'DUNGEON_WIN','dungeon_id':dungeon_id,'drops':drops}; self.log.append(r); return r

    def _add(self,item:str,qty:int):
        self.state.inventory[item]=self.state.inventory.get(item,0)+qty
    @staticmethod
    def _drop(item,qty,confidence): return {'item':item,'qty':qty,'confidence':confidence}

    def hit_alliance_boss(self, damage: int, *, player_id: str='P1') -> Dict[str,Any]:
        d=self.defs['ALLIANCE_BOSS']
        used=self.state.daily_runs.get(d.dungeon_id,0)
        limit=self._daily_limit(d)
        if used>=limit: raise ValueError('daily dungeon limit reached')
        if self.state.boss_killed: raise ValueError('current boss already defeated')
        if damage < 0: raise ValueError('damage must be nonnegative')
        self.state.daily_runs[d.dungeon_id]=used+1
        actual=min(damage,self.state.boss_hp)
        self.state.boss_hp-=actual
        score=actual*int(tp('alliance_score_per_damage'))
        self.state.alliance_score+=score
        killed=self.state.boss_hp<=0
        last_hit_reward=[]
        if killed:
            self.state.boss_killed=True
            q=int(tp('alliance_last_hit_reward_qty'))
            self._add('殺擊獎勵',q); last_hit_reward=[self._drop('殺擊獎勵',q,'A semantic/C qty')]
        r={'action':'ALLIANCE_BOSS_HIT','boss_index':self.state.boss_index,'damage':actual,'score_added':score,'boss_hp_after':self.state.boss_hp,'killed':killed,'last_hit_reward':last_hit_reward}
        self.log.append(r); return r

    def claim_alliance_clear_reward(self) -> Dict[str,Any]:
        if not self.state.boss_killed: raise ValueError('boss not defeated')
        if self.state.claimed_boss_clear: raise ValueError('clear reward already claimed')
        q=int(tp('alliance_clear_reward_qty'))
        self._add('聯盟BOSS通關獎勵',q); self.state.claimed_boss_clear=True
        r={'action':'ALLIANCE_CLEAR_REWARD','boss_index':self.state.boss_index,'reward':self._drop('聯盟BOSS通關獎勵',q,'A semantic/C qty')}
        self.log.append(r); return r

    def advance_alliance_boss(self) -> Dict[str,Any]:
        if not self.state.boss_killed: raise ValueError('current boss not defeated')
        if self.state.boss_index >= 3: raise ValueError('only 3 live bosses confirmed for this version snapshot')
        self.state.boss_index += 1
        self.state.boss_hp = int(tp('alliance_boss_hp'))
        self.state.boss_killed = False
        self.state.claimed_boss_clear = False
        r={'action':'ALLIANCE_BOSS_ADVANCE','boss_index':self.state.boss_index,'boss_hp':self.state.boss_hp,'boss_hp_confidence':'C'}
        self.log.append(r); return r

    def reset_daily(self):
        self.state.daily_runs.clear()


def planned_future_dungeons():
    return list(CATALOG['planned_not_live'])
