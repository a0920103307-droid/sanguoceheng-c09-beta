from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional
from copy import deepcopy
import importlib.util, json, sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
CATALOG = json.loads((BASE / "horse_catalog_v0.5.json").read_text(encoding="utf-8"))
TEMP = json.loads((BASE / "temporary_horse_params.json").read_text(encoding="utf-8"))["parameters"]

def hpv(name: str):
    return TEMP[name]["value"]

def _load_grid04():
    path = ROOT / "tactics" / "grid04_engine.py"
    spec = importlib.util.spec_from_file_location("grid04_engine_for_grid05", path)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load grid04 engine")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod

g4 = _load_grid04()
Card = g4.Card
PlayerState = g4.PlayerState
_state = g4._state
has_status = g4.has_status
pv = g4.pv
EffectResult = g4.EffectResult

@dataclass(frozen=True)
class HorseRecord:
    horse_id: str
    name: str
    quality: str
    skill_name: str
    binding: str
    effect_original: str
    exact_original: Optional[Dict[str, Any]]
    confidence: str
    suitable: str
    acquisition: str
    source: str


def horse_records():
    return [HorseRecord(**x) for x in CATALOG["horses"]]

def find_horse(name: str) -> HorseRecord:
    for h in horse_records():
        if h.name == name or h.horse_id == name:
            return h
    raise KeyError(name)

def equipped_horse(card: Card) -> Optional[Dict[str, Any]]:
    return _state(card).get("horse")

class HorseBattle(g4.TacticBattle):
    """Grid05 horse layer.

    Horse identity/evidence is data-driven. Unknown numeric curves stay in
    temporary_horse_params.json. Grid03 STEAL_HORSE/DESTROY_HORSE remain the generic
    mutation interface because runtime horse state lives in card.skill_state['horse'].
    """
    def __init__(self, *args, player_levels=(20,20), **kwargs):
        super().__init__(*args, **kwargs)
        self.player_levels = list(player_levels)
        self.horse_log = []
        self._damage_type = "PHYSICAL"

    def equip_horse(self, owner: int, target: Card, horse_name: str, *, level: int = 1, skill_level: Optional[int] = None) -> Dict[str, Any]:
        if self.player_levels[owner] < int(CATALOG["system_rules"]["unlock_level"]["original"]):
            raise PermissionError("horse system unlocks at player level 20")
        loc = self._find_card(target)
        if loc is None or loc[0] != owner:
            raise ValueError("target must be owner's board card")
        if target.kind not in set(hpv("eligible_target_kinds")):
            raise ValueError("target kind is not eligible for horse")
        if equipped_horse(target) is not None:
            raise ValueError("target already has a horse")
        h = find_horse(horse_name)
        cap = int(hpv("horse_level_cap"))
        if not 1 <= int(level) <= cap:
            raise ValueError("horse level out of reconstructed range")
        sl = int(level) if skill_level is None and bool(hpv("default_skill_level_equals_horse_level")) else int(skill_level or 1)
        data = {
            "horse_id": h.horse_id, "name": h.name, "quality": h.quality,
            "level": int(level), "skill_name": h.skill_name, "skill_level": sl,
            "binding": h.binding, "effect_original": h.effect_original,
            "exact_original": deepcopy(h.exact_original), "confidence": h.confidence,
            "can_be_stolen": bool(hpv("horse_can_be_stolen_default")),
            "can_be_destroyed": bool(hpv("horse_can_be_destroyed_default")),
            "source": h.source,
        }
        _state(target)["horse"] = data
        result = {"action":"EQUIP","target":target.name,"horse":h.name,"level":int(level),"skill_level":sl}
        self.horse_log.append(result); self.log.append(f"GRID05 HORSE {result}")
        return result

    def unequip_horse(self, target: Card) -> Optional[Dict[str, Any]]:
        old = equipped_horse(target)
        _state(target)["horse"] = None
        if old:
            self.horse_log.append({"action":"UNEQUIP","target":target.name,"horse":old["name"]})
        return old

    def strengthen_horse(self, target: Card, levels: int = 1) -> Dict[str, Any]:
        hs = equipped_horse(target)
        if hs is None: raise ValueError("target has no horse")
        cap = int(hpv("horse_level_cap")); old = int(hs["level"])
        hs["level"] = min(cap, old + max(0, int(levels)))
        if bool(hpv("default_skill_level_equals_horse_level")):
            hs["skill_level"] = hs["level"]
        result={"action":"STRENGTHEN","horse":hs["name"],"old_level":old,"new_level":hs["level"],"skill_level":hs["skill_level"]}
        self.horse_log.append(result); return result

    def apply_effect(self, owner: int, source: Optional[Card], effect: Dict[str, Any], **kwargs):
        et = str(effect.get("type","")).upper()
        if et in {"STEAL_HORSE","DESTROY_HORSE"}:
            target = kwargs.get("target")
            if target is None:
                return EffectResult(et, False, {"reason":"NO_TARGET"})
            hs = equipped_horse(target)
            if hs is None:
                return EffectResult(et, False, {"reason":"NO_HORSE"})
            if et == "STEAL_HORSE" and not bool(hs.get("can_be_stolen", True)):
                return EffectResult(et, False, {"reason":"HORSE_NOT_STEALABLE"})
            if et == "DESTROY_HORSE" and not bool(hs.get("can_be_destroyed", True)):
                return EffectResult(et, False, {"reason":"HORSE_NOT_DESTROYABLE"})
        old_type = self._damage_type
        if et == "DAMAGE": self._damage_type = "SPELL"
        try:
            return super().apply_effect(owner, source, effect, **kwargs)
        finally:
            self._damage_type = old_type

    def _horse_binding(self, card: Optional[Card]) -> Optional[str]:
        hs = equipped_horse(card) if card is not None else None
        return hs.get("binding") if hs else None

    def _dodge(self, dst: Card, damage_type: str) -> bool:
        b = self._horse_binding(dst)
        rate = 0.0
        if b == "DODGE_ALL": rate = float(hpv("gray_shadow_dodge_rate"))
        elif b == "DODGE_PHYSICAL" and damage_type == "PHYSICAL": rate = float(hpv("quick_sail_dodge_rate"))
        if rate > 0 and self.rng.random() < rate:
            self.log.append(f"GRID05 HORSE DODGE target={dst.name} type={damage_type}")
            return True
        return False

    def damage_card(self, src_owner: int, src: Card, dst_owner: int, dst: Card, amount: int):
        damage_type = self._damage_type
        if self._dodge(dst, damage_type):
            return
        amount = max(0, int(amount))
        hs = equipped_horse(dst)
        if hs and hs.get("binding") == "PHYSICAL_DAMAGE_CAP" and damage_type == "PHYSICAL":
            cap = int(hs.get("exact_original",{}).get("physical_damage_cap",350))
            amount = min(amount, cap)
            self.log.append(f"GRID05 HORSE DAMAGE_CAP target={dst.name} cap={cap}")
        old_hp = dst.hp
        super().damage_card(src_owner, src, dst_owner, dst, amount)
        actual = max(0, old_hp - max(0,dst.hp))
        # Reflect is only defined against physical damage in current evidence.
        hs = equipped_horse(dst)
        if actual > 0 and hs and hs.get("binding") == "REFLECT_ADJACENT" and damage_type == "PHYSICAL":
            reflect = int(hpv("jingfan_reflect_damage"))
            loc = self._find_card(src)
            if loc is not None:
                owner, slot = loc
                for s in (slot-1, slot, slot+1):
                    if 0 <= s < len(self.players[owner].board):
                        c=self.players[owner].board[s]
                        if c is not None:
                            c.hp -= reflect
                            self.log.append(f"GRID05 HORSE REFLECT source={dst.name} target={c.name} amount={reflect}")
                self.state_based_defeat(); self.check_victory()

    def _attack_damage(self, attacker: Card, defender: Card) -> int:
        amount = int(attacker.attack)
        hs = equipped_horse(attacker)
        if hs and hs.get("binding") == "ATTACK_CARD_BONUS":
            amount += int(hpv("xinan_attack_bonus"))
        return max(0, amount)

    def _after_card_attack(self, attacker: Card, defender: Card, damage_done: int):
        hs = equipped_horse(attacker)
        if not hs: return
        b=hs.get("binding")
        if b == "LIFESTEAL" and damage_done > 0:
            heal=int(round(damage_done * float(hpv("wusun_lifesteal_ratio"))))
            attacker.hp=min(attacker.max_hp, attacker.hp+heal)
            self.log.append(f"GRID05 HORSE LIFESTEAL card={attacker.name} heal={heal}")
        elif b in {"ATTACK_GROWTH","BLOOD_BATTLE"}:
            gain=int(hpv("liaoyuan_attack_gain" if b=="ATTACK_GROWTH" else "blood_battle_attack_gain"))
            attacker.attack += gain
            self.log.append(f"GRID05 HORSE ATTACK_GROWTH card={attacker.name} gain={gain}")
        elif b == "EXECUTE" and defender.hp > 0 and defender.hp / max(1,defender.max_hp) <= float(hpv("execute_hp_ratio")):
            defender.hp=0; self.log.append(f"GRID05 HORSE EXECUTE source={attacker.name} target={defender.name}"); self.state_based_defeat(); self.check_victory()
        elif b == "MULTI_HIT_SUPPORT" and defender.hp > 0:
            extra=max(1,int(round(attacker.attack * float(hpv("wushuang_extra_hit_ratio")))))
            self.damage_card(self._find_card(attacker)[0], attacker, self._find_card(defender)[0], defender, extra)

    def _gate_attack_amount(self, attacker: Card) -> int:
        amount=int(attacker.attack); hs=equipped_horse(attacker)
        if hs and hs.get("binding") == "GATE_DAMAGE_BONUS":
            exact = hs.get("exact_original") or {}
            # 2050 is confirmed only for full-level White Dove; the level cap itself is C-level.
            if int(hs.get("level",1)) >= int(hpv("horse_level_cap")):
                amount += int(exact.get("full_level_gate_bonus",0))
        return max(0,amount)

    def _horse_turn_end(self, owner: int):
        for _,_,card in list(self._iter_board(owner)):
            hs=equipped_horse(card)
            if hs and hs.get("binding") == "SELF_HEAL":
                heal=int(hpv("dilu_turn_heal")); old=card.hp; card.hp=min(card.max_hp,card.hp+heal)
                self.log.append(f"GRID05 HORSE SELF_HEAL card={card.name} amount={card.hp-old}")

    def combat(self):
        if self.winner is not None: return
        atk_idx=self.active; def_idx=1-atk_idx; self.emit("COMBAT_START",player=self.players[atk_idx].name)
        for slot in range(int(pv("board_slots"))):
            if self.winner is not None: break
            attacker=self.players[atk_idx].board[slot]
            if attacker is None or attacker.hp<=0 or has_status(attacker,"PETRIFY") or has_status(attacker,"ACTION_LOCK"): continue
            self.emit("BEFORE_ATTACK",player=self.players[atk_idx].name,card=attacker.name,slot=slot)
            defender=self._combat_target(def_idx,slot)
            if defender is not None:
                self.emit("ON_ATTACK",source=attacker.name,target=defender.name,slot=slot)
                old=defender.hp; self._damage_type="PHYSICAL"
                self.damage_card(atk_idx,attacker,def_idx,defender,self._attack_damage(attacker,defender))
                done=max(0,old-max(0,defender.hp)); self._after_card_attack(attacker,defender,done)
            elif bool(pv("empty_opposite_attacks_gate")):
                self.emit("ON_ATTACK",source=attacker.name,target="GATE",slot=slot); self.damage_gate(atk_idx,self._gate_attack_amount(attacker))
        self._horse_turn_end(atk_idx)
        self.emit("TURN_END",player=self.players[atk_idx].name)
        self._resolve_death_will(atk_idx); self._expire_ephemeral(atk_idx); self._restore_borrowed(atk_idx)
        self.tick_statuses(atk_idx)
        for _,_,c in list(self._iter_board(def_idx)):
            for s in ("ACTION_LOCK","FOCUS_FIRE"):
                d=_state(c)["statuses"].get(s)
                if d is not None:
                    d["duration"] = int(d.get("duration",1))-1
                    if d["duration"] <= 0: _state(c)["statuses"].pop(s,None)
        if self.focus_target is not None and not has_status(self.focus_target,"FOCUS_FIRE"): self.focus_target=None
        self.check_victory()
        if self.winner is None: self.active=def_idx
