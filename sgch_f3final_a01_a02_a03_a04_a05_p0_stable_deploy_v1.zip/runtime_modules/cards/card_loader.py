from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional
import importlib.util
import json
import sys

BASE = Path(__file__).resolve().parent
SUPPORTED_TYPES = {"GENERAL", "SOLDIER", "BOOK", "ORDER", "HORSE", "EQUIPMENT"}
CONFIDENCE = {"A", "A/B", "B+", "B", "B/C", "C", "UNCONFIRMED"}
REQUIRED_FIELDS = {
    "card_id", "name", "faction", "quality", "card_type", "attack", "hp",
    "cost_fame", "star", "skills", "horse", "equipment", "bonds", "acquisition",
    "source", "confidence", "is_temporary", "progression", "placement", "relationships",
    "acquisition_detail", "evidence"
}

@dataclass(frozen=True)
class CardRecord:
    raw: Dict[str, Any]

    @property
    def card_id(self) -> str:
        return self.raw["card_id"]

    @property
    def name(self) -> str:
        return self.raw["name"]

    @property
    def card_type(self) -> str:
        return self.raw["card_type"]

    def effective_number(self, field: str) -> Optional[int]:
        value = self.raw[field]["effective"]
        if value is None:
            return None
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"{self.card_id}.{field}.effective must be numeric or null")
        return int(value)


def _validate_value_field(card_id: str, field_name: str, value: Any) -> None:
    if not isinstance(value, dict):
        raise ValueError(f"{card_id}.{field_name} must be an object")
    for key in ("original", "temporary", "effective", "confidence"):
        if key not in value:
            raise ValueError(f"{card_id}.{field_name} missing {key}")
    if value["confidence"] not in CONFIDENCE:
        raise ValueError(f"{card_id}.{field_name} invalid confidence")
    # Critical anti-contamination rule: C effective values must not silently occupy original.
    if value["confidence"] == "C" and value["effective"] is not None and value["temporary"] is None:
        raise ValueError(f"{card_id}.{field_name}: C effective value requires temporary value")


def validate_card(card: Dict[str, Any]) -> None:
    missing = REQUIRED_FIELDS - set(card)
    if missing:
        raise ValueError(f"card missing fields: {sorted(missing)}")
    if not isinstance(card["card_id"], str) or not card["card_id"].strip():
        raise ValueError("card_id must be non-empty string")
    if not isinstance(card["name"], str) or not card["name"].strip():
        raise ValueError(f"{card['card_id']}: name must be non-empty string")
    if card["card_type"] not in SUPPORTED_TYPES:
        raise ValueError(f"{card['card_id']}: unsupported card_type {card['card_type']}")
    if card["confidence"] not in CONFIDENCE:
        raise ValueError(f"{card['card_id']}: invalid confidence")
    if not isinstance(card["is_temporary"], bool):
        raise ValueError(f"{card['card_id']}: is_temporary must be bool")
    if not isinstance(card["source"], list) or not card["source"]:
        raise ValueError(f"{card['card_id']}: source must contain at least one record")
    for s in card["source"]:
        if not isinstance(s, dict) or s.get("confidence") not in CONFIDENCE:
            raise ValueError(f"{card['card_id']}: source confidence invalid")
    for vf in ("attack", "hp", "cost_fame"):
        _validate_value_field(card["card_id"], vf, card[vf])
    if card["star"] is not None and (not isinstance(card["star"], int) or not 1 <= card["star"] <= 5):
        raise ValueError(f"{card['card_id']}: star must be null or 1..5")
    if not isinstance(card["skills"], list) or len(card["skills"]) > 3:
        raise ValueError(f"{card['card_id']}: skills must be list with <=3 entries")
    seen_slots = set()
    for skill in card["skills"]:
        slot = skill.get("slot")
        if slot not in (1, 2, 3) or slot in seen_slots:
            raise ValueError(f"{card['card_id']}: invalid/duplicate skill slot")
        seen_slots.add(slot)
        if skill.get("confidence") not in CONFIDENCE or not isinstance(skill.get("is_temporary"), bool):
            raise ValueError(f"{card['card_id']}: skill evidence metadata invalid")
    if not isinstance(card["equipment"], list) or not isinstance(card["bonds"], list):
        raise ValueError(f"{card['card_id']}: equipment/bonds must be arrays")
    for rich in ("progression", "placement", "relationships", "acquisition_detail", "evidence"):
        if not isinstance(card.get(rich), dict):
            raise ValueError(f"{card['card_id']}: {rich} must be object")


def load_catalog(path: Path | str = BASE / "card_catalog_v0.3.json") -> List[CardRecord]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    cards = payload.get("cards")
    if not isinstance(cards, list):
        raise ValueError("catalog.cards must be a list")
    seen = set()
    out: List[CardRecord] = []
    for card in cards:
        validate_card(card)
        if card["card_id"] in seen:
            raise ValueError(f"duplicate card_id: {card['card_id']}")
        seen.add(card["card_id"])
        out.append(CardRecord(card))
    return out


def find_card(card_id: str, catalog: Optional[List[CardRecord]] = None) -> CardRecord:
    catalog = catalog if catalog is not None else load_catalog()
    for c in catalog:
        if c.card_id == card_id:
            return c
    raise KeyError(card_id)


def _load_grid01_module():
    grid01_path = BASE.parent / "battle" / "grid01_engine.py"
    spec = importlib.util.spec_from_file_location("grid01_engine", grid01_path)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load grid01_engine")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def to_grid01_card(record: CardRecord):
    if record.card_type not in {"GENERAL", "SOLDIER"}:
        raise ValueError(f"{record.card_type} is not a board unit in Grid01")
    attack = record.effective_number("attack")
    hp = record.effective_number("hp")
    if attack is None or hp is None:
        raise ValueError(f"{record.card_id} lacks effective attack/hp")
    engine = _load_grid01_module()
    # Grid02 intentionally does NOT translate skills to effects; that belongs to Grid03.
    return engine.Card(record.card_id, record.name, record.card_type, attack=attack, max_hp=hp, effects=[])


def build_grid01_deck(card_ids: List[str], repeat: int = 1):
    catalog = load_catalog()
    deck = []
    for _ in range(repeat):
        for cid in card_ids:
            deck.append(to_grid01_card(find_card(cid, catalog)))
    return deck


if __name__ == "__main__":
    cards = load_catalog()
    print(f"loaded={len(cards)} types={sorted({c.card_type for c in cards})}")
    demo = build_grid01_deck(["GENERAL_XUHuang_001", "SOLDIER_ARCHER_001"], repeat=2)
    print([(c.card_id, c.name, c.kind, c.attack, c.max_hp) for c in demo])
