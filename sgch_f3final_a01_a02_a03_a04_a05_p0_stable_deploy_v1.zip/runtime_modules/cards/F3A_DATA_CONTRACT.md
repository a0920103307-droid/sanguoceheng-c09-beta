# F3-A｜卡牌資料結構重整

本階段只統一資料結構，不把未確認數值冒充原版真值。

## 六類卡牌
- GENERAL 武將：場上單位；等級、1~5星、最多三技能、情緣、專屬裝備接口。
- SOLDIER 士兵：場上單位；等級、核心單技能、兵符+銀幣養成。
- HORSE 戰馬：掛載武將；不占戰場格；20級解鎖；品質/等級/技能。
- BOOK 兵書：牌組戰術卡；不占戰場格；32級解鎖；品質/等級/技能。
- ORDER 軍令：戰術卡；不占戰場格。
- EQUIPMENT 裝備：武將養成；不進牌組；武器/盔甲；五星技能+1、淬鍊、專屬緣分接口。

## 統一欄位
identity / progression / placement / relationships / acquisition_detail / evidence。
每張卡仍保留舊版 attack/hp/cost_fame/skills 等欄位，確保目前戰鬥原型兼容。

## 證據邊界
- 已確認資料直接保留。
- 未確認數值使用 null 或 C 級 temporary，不得寫入 original。
- 刀/盾/鼓/輔/奶等只有兵種分類線索者保留於 soldier_role_definitions，不偽造實際卡名。
