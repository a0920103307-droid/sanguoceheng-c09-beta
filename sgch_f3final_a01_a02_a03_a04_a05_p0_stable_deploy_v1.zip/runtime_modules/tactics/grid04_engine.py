from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional
from copy import deepcopy
import importlib.util, json, sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
CATALOG = json.loads((BASE / "tactic_catalog_v0.4.json").read_text(encoding="utf-8"))
TEMP = json.loads((BASE / "temporary_tactic_params.json").read_text(encoding="utf-8"))["parameters"]

def tp(name: str):
    return TEMP[name]["value"]

def _load_grid03():
    path = ROOT / "skills" / "skill_engine.py"
    spec = importlib.util.spec_from_file_location("skill_engine_for_grid04", path)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load grid03 skill engine")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod

skill = _load_grid03()
Card = skill.Card
PlayerState = skill.PlayerState
pv = skill.pv
_state = skill._state
has_status = skill.has_status
EffectResult = skill.EffectResult

NEGATIVE_STATUSES = {"SILENCE", "SEAL", "PETRIFY", "CONFUSION", "ACTION_LOCK", "FOCUS_FIRE", "DEATH_WILL"}
COMMAND_NAMES = [c["name"] for c in CATALOG["commands"]]

@dataclass
class TacticCard:
    card_id: str
    name: str
    card_type: str  # BOOK / COMMAND
    level: int
    binding: str
    confidence: str
    source: str


def _find_entry(section: str, name: str) -> Dict[str, Any]:
    for row in CATALOG[section]:
        if row["name"] == name:
            return row
    raise KeyError(name)


def make_book(name: str) -> TacticCard:
    e = _find_entry("books", name)
    return TacticCard(e["id"], e["name"], "BOOK", int(e["max_level"]), e["binding"], e["confidence"], e["source"])


def make_command(name: str) -> TacticCard:
    e = _find_entry("commands", name)
    return TacticCard(e["id"], e["name"], "COMMAND", int(e["level"]), e["binding"], e["confidence"], e["source"])


class TacticBattle(skill.SkillBattle):
    """Grid04: 15 confirmed books + 6 confirmed military orders.

    Original effect text/source/confidence lives in tactic_catalog_v0.4.json.
    Unknown numeric values and ambiguous timing live in temporary_tactic_params.json.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.exiled: List[List[Card]] = [[], []]
        self.borrowed: List[Dict[str, Any]] = []
        self.ephemeral: List[Dict[str, Any]] = []
        self.focus_target: Optional[Card] = None
        self.position_locked: List[bool] = [False, False]
        self.tactic_log: List[Dict[str, Any]] = []

    def play(self, hand_index: int, slot: int):
        super().play(hand_index, slot)
        c = self.players[self.active].board[slot]
        if c is not None:
            _state(c)  # capture runtime initial stats on deployment for rebirth/reset semantics

    def _board_cards(self, owner: int) -> List[Card]:
        return [c for c in self.players[owner].board if c is not None]

    def _empty_slots(self, owner: int) -> List[int]:
        return [i for i, c in enumerate(self.players[owner].board) if c is None]

    def _runtime_status(self, card: Card, name: str, duration: int = 1, **data):
        payload = {"duration": int(duration), **data}
        _state(card)["statuses"][name] = payload
        self.log.append(f"GRID04 STATUS {name} target={card.name} duration={duration}")

    def _sample_cards(self, owner: int, count: int) -> List[Card]:
        cards = self._board_cards(owner)
        if not cards:
            return []
        return self.rng.sample(cards, min(int(count), len(cards)))

    def _require_max_level(self, entry: Dict[str, Any], level: Optional[int]):
        max_level = int(entry["max_level"])
        if level is not None and int(level) != max_level:
            raise NotImplementedError(f"{entry['name']} only has confirmed max-level effect; level curve is not reconstructed")

    def use_book(self, owner: int, name: str, *, level: Optional[int] = None) -> Dict[str, Any]:
        e = _find_entry("books", name)
        self._require_max_level(e, level)
        b = e["binding"]
        result: Dict[str, Any] = {"name": name, "binding": b, "applied": False}
        enemy = 1 - owner

        if b == "SUNZI_ASSIST_OR_LOCK":
            empties = self._empty_slots(owner)
            enemy_cards = self._board_cards(enemy)
            if empties and enemy_cards:
                selected = self.rng.sample(enemy_cards, min(4, len(empties), len(enemy_cards)))
                moved = []
                for c, new_slot in zip(selected, empties):
                    old_slot = self.players[enemy].board.index(c)
                    self.players[enemy].board[old_slot] = None
                    self.players[owner].board[new_slot] = c
                    self.borrowed.append({"card": c, "true_owner": enemy, "old_slot": old_slot, "borrower": owner})
                    moved.append(c.name)
                result.update(applied=bool(moved), mode="ASSIST", cards=moved)
            else:
                selected = self._sample_cards(enemy, 4)
                for c in selected:
                    self._runtime_status(c, "ACTION_LOCK", 1, source="孫子兵法")
                result.update(applied=bool(selected), mode="LOCK", cards=[c.name for c in selected])

        elif b == "REVIVE_LAST":
            p = self.players[owner]
            idx = next((i for i in range(len(p.retreat)-1, -1, -1) if getattr(p.retreat[i], "kind", "") not in {"BOOK", "HORSE"}), None)
            slot = next(iter(self._empty_slots(owner)), None)
            if idx is not None and slot is not None:
                c = p.retreat.pop(idx); c.hp = c.max_hp; p.board[slot] = c
                result.update(applied=True, card=c.name, slot=slot)

        elif b == "ADD_3_COMMANDS":
            p = self.players[owner]
            if len(p.hand) < int(pv("hand_limit")):
                picks = self.rng.sample(COMMAND_NAMES, 3) if tp("orders24_random_without_replacement") else [self.rng.choice(COMMAND_NAMES) for _ in range(3)]
                added = []
                for cmd in picks:
                    if len(p.hand) >= int(pv("hand_limit")): break
                    p.hand.append(make_command(cmd)); added.append(cmd)
                result.update(applied=bool(added), added=added)

        elif b == "SILENCE_AND_ACTION_LOCK_4":
            selected = self._sample_cards(enemy, 4)
            for c in selected:
                self.apply_effect(owner, None, {"type": "SILENCE", "duration": 1}, target=c)
                self._runtime_status(c, "ACTION_LOCK", 1, source="太平要術")
            result.update(applied=bool(selected), cards=[c.name for c in selected])

        elif b == "DAMAGE_ALL_ENEMY_880":
            hits = []
            for c in list(self._board_cards(enemy)):
                if self._find_card(c) is not None:
                    self.apply_effect(owner, None, {"type":"DAMAGE","amount":880,"reveals":True}, target=c); hits.append(c.name)
            result.update(applied=bool(hits), cards=hits, amount=880)

        elif b == "HP_ALL_ALLY_1000":
            hits=[]
            for c in self._board_cards(owner):
                self.apply_effect(owner, None, {"type":"MOD_HP","amount":1000}, target=c); hits.append(c.name)
            result.update(applied=bool(hits), cards=hits, amount=1000)

        elif b == "GATE_HP_6740":
            self.players[owner].gate_hp += 6740
            result.update(applied=True, amount=6740, gate_hp=self.players[owner].gate_hp)

        elif b == "ATK_ALL_ENEMY_MINUS_670":
            hits=[]
            for c in self._board_cards(enemy):
                self.apply_effect(owner, None, {"type":"MOD_ATTACK","amount":-670}, target=c); hits.append(c.name)
            result.update(applied=bool(hits), cards=hits, amount=-670)

        elif b == "SKILL_LEVEL_ALL_ALLY_PLUS_1":
            hits=[]
            for c in self._board_cards(owner):
                st=_state(c); st["skill_level_bonus"] = min(20, int(st.get("skill_level_bonus",0)) + 1); hits.append(c.name)
            result.update(applied=bool(hits), cards=hits, delta=1, cap=20)

        elif b == "CLEAR_NEGATIVE_ALL_ALLY":
            total=0
            for c in self._board_cards(owner):
                statuses=_state(c)["statuses"]
                for s in list(statuses):
                    if s in NEGATIVE_STATUSES:
                        statuses.pop(s, None); total += 1
            result.update(applied=total>0, cleared=total)

        elif b == "ATK_ALL_ALLY_770":
            hits=[]
            for c in self._board_cards(owner):
                self.apply_effect(owner, None, {"type":"MOD_ATTACK","amount":770}, target=c); hits.append(c.name)
            result.update(applied=bool(hits), cards=hits, amount=770)

        elif b == "DRAW_6_ADD_FIRE_1":
            p=self.players[owner]
            if len(p.hand) < int(pv("hand_limit")):
                drawn=self.draw(p,6); old=p.fire; self.add_fire(owner,1)
                result.update(applied=(drawn>0 or p.fire!=old), drawn=drawn, fire_old=old, fire_new=p.fire)

        elif b == "EXILE_ENEMY_RETREAT_4":
            p=self.players[enemy]; n=min(4,len(p.retreat)); cards=p.retreat[:n]; del p.retreat[:n]; self.exiled[enemy].extend(cards)
            result.update(applied=n>0, cards=[c.name for c in cards])

        elif b in {"SUMMON_ENEMY_EPHEMERAL_4", "SUMMON_ALLY_EPHEMERAL_4"}:
            target_owner = enemy if b == "SUMMON_ENEMY_EPHEMERAL_4" else owner
            created=[]
            for slot in self._empty_slots(target_owner)[:4]:
                c=Card(f"TOKEN_SOUL_{len(self.ephemeral)+1}","消亡兵魄","SOLDIER",attack=1,max_hp=1)
                self.players[target_owner].board[slot]=c
                self.ephemeral.append({"card":c,"owner":target_owner,"expires_after_attacker":owner})
                created.append(c.name)
            result.update(applied=bool(created), count=len(created))

        else:
            raise ValueError(f"unsupported book binding {b}")

        self.tactic_log.append(result)
        self.log.append(f"GRID04 BOOK {name} {result}")
        return result

    def use_command(self, owner: int, name: str, *, target: Optional[Card] = None) -> Dict[str, Any]:
        e = _find_entry("commands", name); b=e["binding"]
        result={"name":name,"binding":b,"applied":False}
        if b == "WAR_INTENT" and target is not None:
            a=int(tp("command_war_intent_attack")); h=int(tp("command_war_intent_hp"))
            self.apply_effect(owner,None,{"type":"MOD_ATTACK","amount":a},target=target)
            self.apply_effect(owner,None,{"type":"MOD_HP","amount":h},target=target)
            old=self.players[owner].fire; self.add_fire(owner,1)
            result.update(applied=True, attack=a, hp=h, fire_old=old, fire_new=self.players[owner].fire)
        elif b == "FOCUS_FIRE" and target is not None and self._find_card(target) is not None:
            self.focus_target=target; self._runtime_status(target,"FOCUS_FIRE",int(tp("focus_fire_duration")),reveals=True)
            result.update(applied=True,target=target.name)
        elif b == "DEATH_WILL" and target is not None and self._find_card(target) is not None:
            a=int(tp("command_death_will_attack")); self.apply_effect(owner,None,{"type":"MOD_ATTACK","amount":a},target=target)
            loc=self._find_card(target); self._runtime_status(target,"DEATH_WILL",99,owner=loc[0],attack_bonus=a)
            result.update(applied=True,target=target.name,attack=a)
        elif b == "REBIRTH" and target is not None:
            st=_state(target); target.attack=int(st.get("base_attack",target.attack)); target.max_hp=int(st.get("base_max_hp",target.max_hp)); target.hp=target.max_hp
            st["statuses"].clear(); st["skill_level_bonus"]=0
            result.update(applied=True,target=target.name,hp=target.hp,attack=target.attack)
        elif b == "FORTIFY":
            slots=self._empty_slots(owner)
            if slots:
                c=Card("TOKEN_FORTIFY_DUMMY","固守草人","SOLDIER",attack=int(tp("fortify_dummy_attack")),max_hp=int(tp("fortify_dummy_hp")))
                self.players[owner].board[slots[0]]=c; self.position_locked[1-owner]=True
                result.update(applied=True,slot=slots[0],position_locked_owner=1-owner)
        elif b == "IMPACT" and target is not None:
            amount=int(tp("command_impact_damage")); r=self.apply_effect(owner,None,{"type":"DAMAGE","amount":amount,"reveals":True},target=target)
            result.update(applied=r.applied,amount=amount,target=target.name)
        self.tactic_log.append(result); self.log.append(f"GRID04 COMMAND {name} {result}")
        return result

    def use_tactic_from_hand(self, owner: int, hand_index: int, *, target: Optional[Card]=None) -> Dict[str, Any]:
        p=self.players[owner]
        if not (0 <= hand_index < len(p.hand)): raise ValueError("invalid hand index")
        card=p.hand[hand_index]
        if not isinstance(card,TacticCard): raise ValueError("hand card is not a tactic card")
        if card.card_type == "BOOK": result=self.use_book(owner,card.name,level=card.level)
        elif card.card_type == "COMMAND": result=self.use_command(owner,card.name,target=target)
        else: raise ValueError("unsupported tactic type")
        if result.get("applied"): p.hand.pop(hand_index)
        return result

    def _combat_target(self, def_idx: int, slot: int) -> Optional[Card]:
        if self.focus_target is not None:
            loc=self._find_card(self.focus_target)
            if loc is not None and loc[0] == def_idx:
                return self.focus_target  # original A-level text says ignore taunt/stealth
        return super()._combat_target(def_idx,slot)

    def state_based_defeat(self):
        # Borrowed enemy cards that die while assisting must enter their true owner's retreat.
        for oi,p in enumerate(self.players):
            for slot,c in enumerate(list(p.board)):
                if c is None or c.hp > 0: continue
                borrowed=next((x for x in self.borrowed if x["card"] is c),None)
                if borrowed is not None:
                    p.board[slot]=None; self.players[borrowed["true_owner"]].retreat.append(c); self.borrowed.remove(borrowed)
                    self.emit("ON_DEFEAT",player=self.players[borrowed["true_owner"]].name,card=c.name,slot=borrowed["old_slot"])
        super().state_based_defeat()

    def _restore_borrowed(self, borrower: int):
        for item in list(self.borrowed):
            if item["borrower"] != borrower: continue
            c=item["card"]; loc=self._find_card(c)
            if loc is not None:
                self.players[loc[0]].board[loc[1]]=None
                dest=item["old_slot"] if self.players[item["true_owner"]].board[item["old_slot"]] is None else next(iter(self._empty_slots(item["true_owner"])),None)
                if dest is not None: self.players[item["true_owner"]].board[dest]=c
            self.borrowed.remove(item)

    def _expire_ephemeral(self, attacker: int):
        for item in list(self.ephemeral):
            if item["expires_after_attacker"] != attacker: continue
            c=item["card"]; loc=self._find_card(c)
            if loc is not None:
                self.players[loc[0]].board[loc[1]]=None; c.hp=0; self.players[item["owner"]].retreat.append(c)
            self.ephemeral.remove(item)

    def _resolve_death_will(self, owner: int):
        for _,_,c in list(self._iter_board(owner)):
            st=_state(c)["statuses"].get("DEATH_WILL")
            if st is not None and int(st.get("owner",owner)) == owner:
                c.hp=0
        self.state_based_defeat()

    def combat(self):
        if self.winner is not None: return
        atk_idx=self.active; def_idx=1-atk_idx; self.emit("COMBAT_START",player=self.players[atk_idx].name)
        for slot in range(int(pv("board_slots"))):
            if self.winner is not None: break
            attacker=self.players[atk_idx].board[slot]
            if attacker is None or attacker.hp<=0 or has_status(attacker,"PETRIFY") or has_status(attacker,"ACTION_LOCK"): continue
            self.emit("BEFORE_ATTACK",player=self.players[atk_idx].name,card=attacker.name,slot=slot)
            defender=self._combat_target(def_idx,slot)
            if defender is not None:
                self.emit("ON_ATTACK",source=attacker.name,target=defender.name,slot=slot,target_card=defender,target_slot=self.players[def_idx].board.index(defender))
                self.damage_card(atk_idx,attacker,def_idx,defender,attacker.attack)
            elif bool(pv("empty_opposite_attacks_gate")):
                self.emit("ON_ATTACK",source=attacker.name,target="GATE",slot=slot,target_slot=slot); self.emit("F3E_GATE_STRIKE",source=attacker.name,slot=slot,amount=attacker.attack); self.damage_gate(atk_idx,attacker.attack)
        self.emit("TURN_END",player=self.players[atk_idx].name)
        self._resolve_death_will(atk_idx)
        self._expire_ephemeral(atk_idx)
        self._restore_borrowed(atk_idx)
        if self.focus_target is not None and has_status(self.focus_target,"FOCUS_FIRE"):
            pass
        self.tick_statuses(atk_idx)
        # ACTION_LOCK and FOCUS_FIRE can sit on opponent and need to expire after the active combat when created for this turn.
        for _,_,c in list(self._iter_board(def_idx)):
            for s in ("ACTION_LOCK","FOCUS_FIRE"):
                d=_state(c)["statuses"].get(s)
                if d is not None:
                    d["duration"] = int(d.get("duration",1)) - 1
                    if d["duration"] <= 0: _state(c)["statuses"].pop(s,None)
        if self.focus_target is not None and not has_status(self.focus_target,"FOCUS_FIRE"): self.focus_target=None
        # F3-E: casualties leave holes for the remainder of the current action turn;
        # both sides close gaps only after every left-to-right attack/effect resolves.
        self.compact_boards()
        self.check_victory()
        if self.winner is None: self.active=def_idx
