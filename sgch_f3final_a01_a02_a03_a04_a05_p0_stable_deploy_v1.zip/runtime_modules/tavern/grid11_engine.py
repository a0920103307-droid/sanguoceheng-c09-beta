from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Iterable
import json, random

BASE=Path(__file__).resolve().parent
CATALOG=json.loads((BASE/'tavern_catalog_v1.1.json').read_text(encoding='utf-8'))
TEMP=json.loads((BASE/'temporary_tavern_params.json').read_text(encoding='utf-8'))['parameters']
def tp(k): return TEMP[k]['value']

@dataclass(frozen=True)
class RecruitCard:
    card_id: str
    name: str
    faction: str
    quality: str

@dataclass
class TavernState:
    version: str='HAOLING_2016'
    yuanbao: int=0
    owned: Dict[str,int]=field(default_factory=dict)
    fragments: Dict[str,int]=field(default_factory=dict)
    soul_qi: int=0
    first_tavern_draw_done: bool=False
    draw_count: int=0

class TavernEngine:
    def __init__(self,state:Optional[TavernState]=None,*,seed:int=1,pool:Optional[Iterable[RecruitCard]]=None):
        self.state=state or TavernState()
        self.rng=random.Random(seed)
        self.pool=list(pool) if pool is not None else [RecruitCard(**x) for x in CATALOG['sample_pool']]
        self.log:List[Dict[str,Any]]=[]
        if not self.pool: raise ValueError('pool cannot be empty')

    @staticmethod
    def price_snapshot_2015()->Dict[str,int]:
        s=CATALOG['version_snapshots']['LIEKU_2015']
        return {k:int(s[k]) for k in ('medium_single_price','high_single_price','medium_ten_price','high_ten_price')}

    def price(self,tier:str,count:int=1)->Optional[int]:
        if self.state.version=='LIEKU_2015':
            p=self.price_snapshot_2015()
            if tier=='MEDIUM': return p['medium_single_price'] if count==1 else p['medium_ten_price'] if count==10 else p['medium_single_price']*count
            if tier=='HIGH': return p['high_single_price'] if count==1 else p['high_ten_price'] if count==10 else p['high_single_price']*count
        if self.state.version=='HAOLING_2016':
            key='haoling_2016_medium_price' if tier=='MEDIUM' else 'haoling_2016_high_price' if tier=='HIGH' else None
            v=tp(key) if key else None
            return None if v is None else int(v)*count
        return None

    def _charge(self,tier:str,count:int,charge:bool):
        if not charge: return 0
        cost=self.price(tier,count)
        if cost is None: raise ValueError('price unknown for this version; cannot charge without explicit parameter')
        if self.state.yuanbao<cost: raise ValueError('insufficient yuanbao')
        self.state.yuanbao-=cost
        return cost

    def _weights(self,tier:str)->Dict[str,int]:
        return dict(tp('medium_quality_weights' if tier=='MEDIUM' else 'high_quality_weights'))

    def _eligible(self,*,faction:Optional[str]=None,allowed_ids:Optional[set[str]]=None,quality:Optional[str]=None)->List[RecruitCard]:
        xs=self.pool
        if faction is not None: xs=[c for c in xs if c.faction==faction]
        if allowed_ids is not None: xs=[c for c in xs if c.card_id in allowed_ids]
        if quality is not None: xs=[c for c in xs if c.quality==quality]
        return xs

    def _sample_card(self,tier:str,*,faction:Optional[str]=None,allowed_ids:Optional[set[str]]=None,force_quality:Optional[str]=None)->RecruitCard:
        if force_quality:
            xs=self._eligible(faction=faction,allowed_ids=allowed_ids,quality=force_quality)
            if not xs: raise ValueError(f'no eligible {force_quality} card')
            return self.rng.choice(xs)
        xs=self._eligible(faction=faction,allowed_ids=allowed_ids)
        if not xs: raise ValueError('no eligible card')
        weights=self._weights(tier)
        qualities=[]; qweights=[]
        for q,w in weights.items():
            if any(c.quality==q for c in xs): qualities.append(q); qweights.append(w)
        if not qualities: return self.rng.choice(xs)
        q=self.rng.choices(qualities,weights=qweights,k=1)[0]
        return self.rng.choice([c for c in xs if c.quality==q])

    def _grant(self,c:RecruitCard)->Dict[str,Any]:
        duplicate=self.state.owned.get(c.card_id,0)>0
        if duplicate:
            qty=int(tp('duplicate_fragment_qty'))
            self.state.fragments[c.card_id]=self.state.fragments.get(c.card_id,0)+qty
            grant={'kind':'FRAGMENTS','card_id':c.card_id,'name':c.name,'qty':qty,'qty_confidence':'C'}
        else:
            self.state.owned[c.card_id]=1
            grant={'kind':'CARD','card_id':c.card_id,'name':c.name,'qty':1}
        return {'card':c,'duplicate':duplicate,'grant':grant}

    def recruit(self,tier:str='HIGH',count:int=1,*,charge:bool=False,faction:Optional[str]=None,event_allowed_ids:Optional[Iterable[str]]=None,activity_soul_qi:bool=False)->Dict[str,Any]:
        if tier not in ('MEDIUM','HIGH'): raise ValueError('tier must be MEDIUM or HIGH')
        if count not in (1,10): raise ValueError('first version supports single or ten pull')
        if faction is not None and not (tier=='HIGH' and count==10): raise ValueError('nation recruitment confirmed only as high ten-pull interface')
        allowed=set(event_allowed_ids) if event_allowed_ids is not None else None
        cost=self._charge(tier,count,charge)
        results=[]
        for i in range(count):
            force=None
            if self.state.version=='HAOLING_2016' and not self.state.first_tavern_draw_done and i==0:
                force='橙'
            c=self._sample_card(tier,faction=faction,allowed_ids=allowed,force_quality=force)
            results.append(self._grant(c))
            self.state.first_tavern_draw_done=True
            self.state.draw_count+=1
        soul=0
        if activity_soul_qi:
            mod=CATALOG['activity_modifiers']['SOUL_QI']
            soul=(int(mod['medium_per_pull']) if tier=='MEDIUM' else int(mod['high_per_pull']))*count
            self.state.soul_qi+=soul
        r={'action':'RECRUIT','tier':tier,'count':count,'cost':cost,'version':self.state.version,'faction':faction,'event_pool':allowed is not None,'activity_soul_qi_added':soul,'results':results,'pity_applied':False,'pity_confidence':'UNCONFIRMED'}
        self.log.append(r); return r

    def high_ten(self,**kwargs): return self.recruit('HIGH',10,**kwargs)
    def nation_high_ten(self,faction:str,**kwargs): return self.recruit('HIGH',10,faction=faction,**kwargs)
    def event_recruit(self,tier:str,count:int,allowed_ids:Iterable[str],**kwargs): return self.recruit(tier,count,event_allowed_ids=allowed_ids,**kwargs)
