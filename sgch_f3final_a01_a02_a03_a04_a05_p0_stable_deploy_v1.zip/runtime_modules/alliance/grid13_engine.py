from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional
import json

BASE = Path(__file__).resolve().parent
CATALOG = json.loads((BASE/'alliance_catalog_v1.3.json').read_text(encoding='utf-8'))
TEMP = json.loads((BASE/'temporary_alliance_params.json').read_text(encoding='utf-8'))['parameters']
def tp(k): return TEMP[k]['value']

ROLE_LEADER='盟主'; ROLE_DEPUTY='副盟主'; ROLE_MEMBER='成員'

@dataclass
class AlliancePlayer:
    player_id: str
    level: int = 1
    silver: int = 0
    alliance_id: Optional[str] = None
    role: Optional[str] = None
    resources: Dict[str,int] = field(default_factory=dict)
    hire_runs_today: int = 0
    boss_runs_today: int = 0
    boss_score: int = 0

@dataclass
class HireListing:
    listing_id: str
    owner_id: str
    card_id: str
    card_name: str
    hired_by: Optional[str] = None

@dataclass
class Alliance:
    alliance_id: str
    name: str
    leader_id: str
    level: int = 1
    members: Dict[str,str] = field(default_factory=dict)
    construction_points: int = 0
    tech_levels: Dict[str,int] = field(default_factory=dict)
    mail_log: List[Dict[str,str]] = field(default_factory=list)
    hire_listings: Dict[str,HireListing] = field(default_factory=dict)
    battle_score: int = 0
    occupied_cities: List[str] = field(default_factory=list)
    boss_index: int = 1
    boss_hp: int = field(default_factory=lambda:int(tp('alliance_boss_hp')))
    boss_killed: bool = False
    boss_clear_claimed_by: set[str] = field(default_factory=set)
    boss_last_hit_player: Optional[str] = None

    def __post_init__(self):
        if not self.members:
            self.members[self.leader_id]=ROLE_LEADER

class AllianceEngine:
    def __init__(self):
        self.alliances: Dict[str,Alliance] = {}
        self.players: Dict[str,AlliancePlayer] = {}
        self.log: List[Dict[str,Any]] = []

    def add_player(self,p:AlliancePlayer):
        self.players[p.player_id]=p; return p

    def _player(self,pid:str)->AlliancePlayer:
        if pid not in self.players: raise ValueError('player not found')
        return self.players[pid]

    def _alliance(self,aid:str)->Alliance:
        if aid not in self.alliances: raise ValueError('alliance not found')
        return self.alliances[aid]

    def can_join(self,pid:str)->bool:
        p=self._player(pid)
        return p.level>=32 and p.alliance_id is None

    def create_alliance(self,pid:str,alliance_id:str,name:str)->Alliance:
        p=self._player(pid)
        if p.alliance_id is not None: raise ValueError('already in alliance')
        if p.level<int(tp('create_alliance_level')): raise ValueError('level too low to create alliance')
        if alliance_id in self.alliances: raise ValueError('alliance id exists')
        cost=int(tp('alliance_create_silver_cost'))
        if p.silver<cost: raise ValueError('not enough silver')
        p.silver-=cost
        a=Alliance(alliance_id,name,pid)
        self.alliances[alliance_id]=a
        p.alliance_id=alliance_id; p.role=ROLE_LEADER
        self.log.append({'action':'ALLIANCE_CREATE','alliance_id':alliance_id,'leader':pid,'create_level_confidence':'C_BOUNDARY'})
        return a

    def join_alliance(self,pid:str,aid:str)->Dict[str,Any]:
        p=self._player(pid); a=self._alliance(aid)
        if p.alliance_id is not None: raise ValueError('already in alliance')
        if p.level<32: raise ValueError('alliance unlock level is 32')
        if len(a.members)>=int(tp('member_cap')): raise ValueError('alliance member cap reached')
        a.members[pid]=ROLE_MEMBER; p.alliance_id=aid; p.role=ROLE_MEMBER
        r={'action':'ALLIANCE_JOIN','player_id':pid,'alliance_id':aid,'unlock_level':32,'confidence':'A'}; self.log.append(r); return r

    def leave_alliance(self,pid:str)->None:
        p=self._player(pid)
        if not p.alliance_id: raise ValueError('not in alliance')
        a=self._alliance(p.alliance_id)
        if p.role==ROLE_LEADER: raise ValueError('leader cannot leave before leadership transfer')
        a.members.pop(pid,None); p.alliance_id=None; p.role=None

    def appoint_deputy(self,leader_id:str,target_id:str)->Dict[str,Any]:
        leader=self._player(leader_id); target=self._player(target_id)
        if leader.role!=ROLE_LEADER or not leader.alliance_id: raise ValueError('leader permission required')
        if target.alliance_id!=leader.alliance_id: raise ValueError('target not in alliance')
        target.role=ROLE_DEPUTY; self._alliance(leader.alliance_id).members[target_id]=ROLE_DEPUTY
        return {'action':'APPOINT_DEPUTY','target':target_id}

    def transfer_leader(self,leader_id:str,target_id:str)->Dict[str,Any]:
        leader=self._player(leader_id); target=self._player(target_id)
        if leader.role!=ROLE_LEADER or not leader.alliance_id: raise ValueError('leader permission required')
        if target.alliance_id!=leader.alliance_id: raise ValueError('target not in alliance')
        a=self._alliance(leader.alliance_id)
        leader.role=ROLE_MEMBER; a.members[leader_id]=ROLE_MEMBER
        target.role=ROLE_LEADER; a.members[target_id]=ROLE_LEADER; a.leader_id=target_id
        return {'action':'TRANSFER_LEADER','from':leader_id,'to':target_id}

    def contribute_silver(self,pid:str,amount:int)->Dict[str,Any]:
        p=self._player(pid)
        if not p.alliance_id: raise ValueError('not in alliance')
        if amount<=0: raise ValueError('contribution must be positive')
        if p.silver<amount: raise ValueError('not enough silver')
        p.silver-=amount; a=self._alliance(p.alliance_id)
        points=amount*int(tp('construction_points_per_silver_contribution'))
        a.construction_points+=points
        return {'action':'CONTRIBUTE_SILVER','silver':amount,'construction_points':points,'evidence':'B existence/C formula'}

    def alliance_upgrade_requirement(self,a:Alliance)->int:
        return int(tp('alliance_upgrade_base_requirement'))*a.level

    def upgrade_alliance(self,actor_id:str)->Dict[str,Any]:
        p=self._player(actor_id)
        if p.role not in (ROLE_LEADER,ROLE_DEPUTY) or not p.alliance_id: raise ValueError('leader/deputy permission required')
        a=self._alliance(p.alliance_id); req=self.alliance_upgrade_requirement(a)
        if a.construction_points<req: raise ValueError('not enough construction points')
        a.construction_points-=req; a.level+=1
        return {'action':'ALLIANCE_UPGRADE','level':a.level,'spent':req,'requirement_confidence':'C'}

    def send_all_mail(self,actor_id:str,subject:str,body:str)->Dict[str,Any]:
        p=self._player(actor_id)
        if p.role not in (ROLE_LEADER,ROLE_DEPUTY) or not p.alliance_id: raise ValueError('leader/deputy permission required')
        a=self._alliance(p.alliance_id); msg={'from':actor_id,'subject':subject,'body':body}; a.mail_log.append(msg)
        return {'action':'ALLIANCE_MAIL','recipients':len(a.members),'message':msg}

    def tech_upgrade_requirement(self,a:Alliance,tech:str)->int:
        next_level=a.tech_levels.get(tech,0)+1
        return int(tp('tech_upgrade_base_requirement'))*next_level

    def upgrade_tech(self,actor_id:str,tech:str)->Dict[str,Any]:
        p=self._player(actor_id)
        if p.role not in (ROLE_LEADER,ROLE_DEPUTY) or not p.alliance_id: raise ValueError('leader/deputy permission required')
        a=self._alliance(p.alliance_id); req=self.tech_upgrade_requirement(a,tech)
        if a.construction_points<req: raise ValueError('not enough construction points')
        a.construction_points-=req; a.tech_levels[tech]=a.tech_levels.get(tech,0)+1
        return {'action':'TECH_UPGRADE','tech':tech,'level':a.tech_levels[tech],'bonus_percent':a.tech_levels[tech]*int(tp('tech_bonus_per_level_percent')),'bonus_confidence':'C'}

    def tech_bonus_percent(self,pid:str,tech:str)->int:
        p=self._player(pid)
        if not p.alliance_id: return 0
        a=self._alliance(p.alliance_id)
        return a.tech_levels.get(tech,0)*int(tp('tech_bonus_per_level_percent'))

    def list_hire_card(self,owner_id:str,listing_id:str,card_id:str,card_name:str)->HireListing:
        p=self._player(owner_id)
        if not p.alliance_id: raise ValueError('not in alliance')
        a=self._alliance(p.alliance_id)
        if listing_id in a.hire_listings: raise ValueError('listing id exists')
        listing=HireListing(listing_id,owner_id,card_id,card_name); a.hire_listings[listing_id]=listing; return listing

    def hire_card(self,hirer_id:str,listing_id:str)->Dict[str,Any]:
        h=self._player(hirer_id)
        if not h.alliance_id: raise ValueError('not in alliance')
        a=self._alliance(h.alliance_id)
        if listing_id not in a.hire_listings: raise ValueError('listing not found in alliance')
        listing=a.hire_listings[listing_id]
        if listing.owner_id==hirer_id: raise ValueError('cannot hire own card')
        if listing.hired_by is not None: raise ValueError('listing already hired')
        if h.hire_runs_today>=int(tp('hire_daily_limit')): raise ValueError('daily hire limit reached')
        fee=int(tp('hire_fee')); income=int(tp('hire_owner_income'))
        if h.silver<fee: raise ValueError('not enough silver for hire')
        h.silver-=fee; owner=self._player(listing.owner_id); owner.silver+=income
        h.hire_runs_today+=1; listing.hired_by=hirer_id
        return {'action':'HIRE_CARD','card_id':listing.card_id,'fee':fee,'owner_income':income,'economy_confidence':'C'}

    def hit_boss(self,pid:str,damage:int)->Dict[str,Any]:
        p=self._player(pid)
        if not p.alliance_id: raise ValueError('not in alliance')
        if damage<0: raise ValueError('damage must be nonnegative')
        a=self._alliance(p.alliance_id)
        if a.boss_killed: raise ValueError('current boss already defeated')
        if p.boss_runs_today>=int(tp('alliance_boss_daily_limit')): raise ValueError('daily boss limit reached')
        p.boss_runs_today+=1
        actual=min(damage,a.boss_hp); a.boss_hp-=actual
        score=actual*int(tp('alliance_boss_score_per_damage')); p.boss_score+=score
        killed=a.boss_hp<=0
        if killed:
            a.boss_killed=True; a.boss_last_hit_player=pid; p.resources['殺擊獎勵']=p.resources.get('殺擊獎勵',0)+1
        return {'action':'ALLIANCE_BOSS_HIT','boss_index':a.boss_index,'damage':actual,'score_added':score,'boss_hp_after':a.boss_hp,'killed':killed,'last_hit_reward':killed}

    def boss_score_ranking(self,aid:str)->List[Dict[str,Any]]:
        a=self._alliance(aid)
        members=[self._player(pid) for pid in a.members]
        members.sort(key=lambda p:(-p.boss_score,p.player_id))
        return [{'player_id':p.player_id,'score':p.boss_score} for p in members]

    def claim_boss_clear(self,pid:str)->Dict[str,Any]:
        p=self._player(pid)
        if not p.alliance_id: raise ValueError('not in alliance')
        a=self._alliance(p.alliance_id)
        if not a.boss_killed: raise ValueError('boss not defeated')
        if pid in a.boss_clear_claimed_by: raise ValueError('clear reward already claimed')
        a.boss_clear_claimed_by.add(pid); p.resources['聯盟BOSS通關獎勵']=p.resources.get('聯盟BOSS通關獎勵',0)+1
        return {'action':'BOSS_CLEAR_REWARD','player_id':pid,'reward_semantic_confidence':'A','reward_qty_confidence':'C'}

    def advance_boss(self,actor_id:str)->Dict[str,Any]:
        p=self._player(actor_id)
        if not p.alliance_id: raise ValueError('not in alliance')
        a=self._alliance(p.alliance_id)
        if not a.boss_killed: raise ValueError('current boss not defeated')
        if a.boss_index>=int(CATALOG['boss_snapshot_count']): raise ValueError('only 3 live bosses confirmed for snapshot')
        a.boss_index+=1; a.boss_hp=int(tp('alliance_boss_hp')); a.boss_killed=False; a.boss_clear_claimed_by.clear(); a.boss_last_hit_player=None
        for mid in a.members: self._player(mid).boss_score=0
        return {'action':'BOSS_ADVANCE','boss_index':a.boss_index,'boss_hp_confidence':'C'}

    def alliance_ranking(self)->List[Dict[str,Any]]:
        # Ranking existence is A; score formula is reconstruction C.
        arr=sorted(self.alliances.values(),key=lambda a:(-(a.level*1000+a.construction_points+a.battle_score),a.alliance_id))
        return [{'alliance_id':a.alliance_id,'score':a.level*1000+a.construction_points+a.battle_score,'score_formula_confidence':'C'} for a in arr]

    def resolve_alliance_battle(self,aid1:str,aid2:str,winner_id:str)->Dict[str,Any]:
        a1=self._alliance(aid1); a2=self._alliance(aid2)
        if aid1==aid2: raise ValueError('cannot battle self')
        if winner_id not in (aid1,aid2): raise ValueError('winner must be participant')
        loser_id=aid2 if winner_id==aid1 else aid1
        self._alliance(winner_id).battle_score+=int(tp('alliance_battle_win_score'))
        self._alliance(loser_id).battle_score+=int(tp('alliance_battle_loss_score'))
        return {'action':'ALLIANCE_BATTLE','winner':winner_id,'loser':loser_id,'score_confidence':'C'}

    def occupy_alliance_city(self,aid:str,city_id:str)->Dict[str,Any]:
        a=self._alliance(aid)
        cap=int(tp('alliance_city_cap'))
        if cap<=0:
            raise ValueError('alliance-city occupation rules not confirmed; interface disabled')
        if city_id not in a.occupied_cities:
            if len(a.occupied_cities)>=cap: raise ValueError('alliance city cap reached')
            a.occupied_cities.append(city_id)
        return {'action':'ALLIANCE_CITY_OCCUPY','city_id':city_id,'rule_confidence':'C'}

    def reset_daily(self):
        for p in self.players.values():
            p.hire_runs_today=0; p.boss_runs_today=0
