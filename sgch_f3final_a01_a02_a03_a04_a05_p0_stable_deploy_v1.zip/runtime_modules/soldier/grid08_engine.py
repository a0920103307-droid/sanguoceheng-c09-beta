from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Optional
import importlib.util, json, sys

BASE=Path(__file__).resolve().parent
CATALOG=json.loads((BASE/'soldier_catalog_v0.9.json').read_text(encoding='utf-8'))
TEMP=json.loads((BASE/'temporary_soldier_f3c_params.json').read_text(encoding='utf-8'))['parameters']
CARD_MAP={x['name']:x for x in CATALOG['cards']}; ROLE_MAP={x['role_code']:x for x in CATALOG['cards']}
def tp(k): return TEMP[k]['value']

def _load_grid07():
    path=BASE.parent/'progression'/'grid07_engine.py'; spec=importlib.util.spec_from_file_location('grid07_engine_for_grid08',path)
    if spec is None or spec.loader is None: raise ImportError('cannot load grid07 engine')
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod); return mod

g7=_load_grid07(); Card=g7.Card; PlayerState=g7.PlayerState; _state=g7._state

def soldier_definition(key:str)->Dict[str,Any]:
    if key in CARD_MAP:return CARD_MAP[key]
    k=str(key).upper()
    if k in ROLE_MAP:return ROLE_MAP[k]
    raise KeyError(f'unknown soldier {key}')

def soldier_state(card:Card)->Dict[str,Any]:
    if card.kind!='SOLDIER':raise ValueError('not a SOLDIER card')
    st=_state(card); s=st.setdefault('soldier',{}); d=soldier_definition(card.name)
    s.setdefault('level',int(getattr(card,'soldier_level',1))); s.setdefault('skill_level',int(s['level']))
    s.setdefault('cost_fame',9); s.setdefault('role_code',d['role_code']); s.setdefault('official_card_name',d['name'] if d.get('official_name_confirmed') else None)
    s.setdefault('source_layer',d['source_layer']); return s

def make_soldier(key:str,*,card_id:Optional[str]=None,level:int=1)->Card:
    d=soldier_definition(key); lv=max(1,int(level)); atk=int(d['attack'])+(lv-1)//int(tp('attack_growth_every_levels')); hp=int(d['hp'])+(lv-1)//int(tp('hp_growth_every_levels'))
    c=Card(card_id or d['card_id'],d['name'],'SOLDIER',attack=atk,max_hp=hp,effects=[])
    c.soldier_role_code=d['role_code']; c.official_card_name=d['name'] if d.get('official_name_confirmed') else None; c.cost_fame=9; c.soldier_level=lv; c.soldier_core_skill=dict(d['core_skill']); c.soldier_meta=dict(d); soldier_state(c); return c

class SoldierBattle(g7.ProgressionBattle):
    def __init__(self,*args,**kwargs): super().__init__(*args,**kwargs); self.soldier_log=[]; self._f3c_guard=set()
    def upgrade_soldier(self,card:Card,inventory:Dict[str,int])->Dict[str,Any]:
        s=soldier_state(card); lv=int(s['level']); cap=int(tp('max_soldier_level'))
        if lv>=cap:raise ValueError('soldier level cap reached (temporary cap)')
        mult=1+(lv//5)*int(tp('cost_growth_every_5_levels')); needs={'兵符':int(tp('soldier_symbol_base_cost'))*mult,'銀幣':int(tp('silver_base_cost'))*mult}
        for k,v in needs.items():
            if int(inventory.get(k,0))<v:raise ValueError(f'insufficient {k}')
        for k,v in needs.items():inventory[k]=int(inventory.get(k,0))-v
        old_atk,old_hp=card.attack,card.max_hp; lv2=lv+1; s['level']=lv2;s['skill_level']=lv2;card.soldier_level=lv2
        d=soldier_definition(card.name); card.attack=int(d['attack'])+(lv2-1)//int(tp('attack_growth_every_levels')); newhp=int(d['hp'])+(lv2-1)//int(tp('hp_growth_every_levels')); delta=newhp-card.max_hp; card.max_hp=newhp;card.hp=max(1,card.hp+delta)
        r={'action':'SOLDIER_UPGRADE','card':card.name,'from_level':lv,'to_level':lv2,'attack':{'from':old_atk,'to':card.attack},'hp':{'from':old_hp,'to':card.max_hp},'consumed':needs,'layer':'BETA_BALANCE'};self.soldier_log.append(r);return r
    def _owner_card(self,name):
        for oi,p in enumerate(self.players):
            for c in p.board:
                if c and c.name==name:return oi,c
        return None,None
    def emit(self,event:str,**ctx):
        super().emit(event,**ctx)
        # F3-C beta abilities. Numeric values are explicitly beta-only; F3-E will unify targeting/effects.
        if event=='ON_DEPLOY':
            card=ctx.get('card')
            if getattr(card,'kind',None)=='SOLDIER':
                owner,_=self._owner_card(card.name); d=soldier_definition(card.name); rc=d['role_code']; val=int(d['core_skill']['value'])
                if owner is None:return
                if rc=='SHIELD':card.max_hp+=val;card.hp+=val
                elif rc=='DRUM':
                    for c in self.players[owner].board:
                        if c and c is not card:c.attack+=val
                elif rc=='SUPPORT':
                    idx=self.players[owner].board.index(card)
                    for j in (idx-1,idx+1):
                        if 0<=j<len(self.players[owner].board):
                            c=self.players[owner].board[j]
                            if c:c.hp=min(c.max_hp,c.hp+val)
                self.soldier_log.append({'event':'ON_DEPLOY','card':card.name,'role':rc,'layer':'BETA_BALANCE'})
        elif event=='TURN_START':
            owner=self.active
            for c in [x for x in self.players[owner].board if x and x.kind=='SOLDIER']:
                d=soldier_definition(c.name)
                if d['role_code']=='HEALER':
                    injured=[x for x in self.players[owner].board if x and x.hp<x.max_hp]
                    if injured:
                        t=min(injured,key=lambda x:x.hp/x.max_hp); old=t.hp; t.hp=min(t.max_hp,t.hp+int(d['core_skill']['value'])); actual=t.hp-old
                        if actual>0: self.emit('HEAL_APPLIED',source=c.name,target=t.name,amount=actual)
                        self.soldier_log.append({'event':'HEAL','card':c.name,'target':t.name,'amount':actual,'layer':'BETA_BALANCE'})
        elif event=='ON_ATTACK':
            source=ctx.get('source'); owner,c=self._owner_card(source)
            if not c or c.kind!='SOLDIER':return
            d=soldier_definition(c.name);rc=d['role_code'];val=int(d['core_skill']['value']);target=ctx.get('target');guard=(id(c),event,str(target),self.turn)
            if guard in self._f3c_guard:return
            self._f3c_guard.add(guard)
            try:
                if rc in ('BLADE','ARCHER') and target!='GATE':
                    for t in self.players[1-owner].board:
                        if t and t.name==target:self.damage_card(owner,c,1-owner,t,val);break
                elif rc=='SIEGE' and target=='GATE': self.emit('F3E_GATE_STRIKE',source=c.name,amount=val,soldier_skill=True); self.damage_gate(owner,val)
            finally:self._f3c_guard.discard(guard)
