from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional
import importlib.util, json, sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
CATALOG = json.loads((BASE / "progression_catalog_v0.7.json").read_text(encoding="utf-8"))
TEMP = json.loads((BASE / "temporary_progression_params.json").read_text(encoding="utf-8"))["parameters"]

def ppv(name: str): return TEMP[name]["value"]

def _load_grid06():
    path = ROOT / "equipment" / "grid06_engine.py"
    spec = importlib.util.spec_from_file_location("grid06_engine_for_grid07", path)
    if spec is None or spec.loader is None: raise ImportError("cannot load grid06 engine")
    mod = importlib.util.module_from_spec(spec); sys.modules[spec.name] = mod; spec.loader.exec_module(mod); return mod

g6 = _load_grid06()
Card = g6.Card
PlayerState = g6.PlayerState
_state = g6._state

QUALITY_ALIASES = {"BLUE":"藍","PURPLE":"紫","ORANGE":"橙","藍":"藍","紫":"紫","橙":"橙"}

def normalize_quality(q: Optional[str]) -> Optional[str]:
    if q is None: return None
    return QUALITY_ALIASES.get(str(q).upper(), QUALITY_ALIASES.get(str(q), str(q)))

def progression_state(card: Card) -> Dict[str, Any]:
    st = _state(card)
    p = st.setdefault("progression", {})
    p.setdefault("star", 1)
    p.setdefault("evolution_count", max(0, int(p["star"])-1))
    p.setdefault("quality", normalize_quality(getattr(card, "quality", None)))
    p.setdefault("skill_unlock_count", CATALOG["star_to_unlocked_skill_count"][str(int(p["star"]))])
    p.setdefault("history", [])
    return p

def set_progression(card: Card, *, star: int=1, quality: Optional[str]=None):
    if not 1 <= int(star) <= 5: raise ValueError("star out of range")
    p = progression_state(card)
    p["star"] = int(star); p["evolution_count"] = int(star)-1
    p["quality"] = normalize_quality(quality if quality is not None else p.get("quality"))
    p["skill_unlock_count"] = CATALOG["star_to_unlocked_skill_count"][str(int(star))]
    return p

def unlocked_skill_count(card: Card) -> int: return int(progression_state(card)["skill_unlock_count"])
def is_skill_slot_unlocked(card: Card, slot: int) -> bool:
    if int(slot) < 1 or int(slot) > 3: raise ValueError("skill slot must be 1..3")
    return int(slot) <= unlocked_skill_count(card)

def evolution_requirements(card: Card, *, use_fragments: bool=False) -> Dict[str, Any]:
    p = progression_state(card); star=int(p["star"])
    if star >= 5: return {"at_cap": True, "from_star": star, "to_star": star}
    step=star # star1->2 is step index 0 but human step 1
    idx=step-1
    q=normalize_quality(p.get("quality"))
    pills=int(ppv("evolution_pills_by_step")[idx]); silver=int(ppv("silver_by_step")[idx]); level_req=int(ppv("level_requirement_by_step")[idx])
    same=int(ppv("same_name_cards_by_step")[idx]); fragments=int(ppv("fragments_by_step")[idx])
    confidence="C"
    if q=="藍" and star==3: # 3-star -> 4-star
        same=int(ppv("blue_four_star_same_name_cards")); confidence="B"
    if q=="藍" and bool(use_fragments):
        raise ValueError("B-grade evidence says blue cards have no fragments")
    return {"at_cap":False,"from_star":star,"to_star":star+1,"evolution_pills":pills,"silver":silver,"level_requirement":level_req,"same_name_cards":0 if use_fragments else same,"fragments":fragments if use_fragments else 0,"material_mode":"FRAGMENTS" if use_fragments else "SAME_NAME_CARD","numeric_confidence":confidence}

class ProgressionBattle(g6.EquipmentBattle):
    """Grid07 evolution/star progression layer over Grid06.

    A rules: 1->5 stars via four evolutions; skill2 at first evolution, skill3 at third;
    core materials are evolution pills plus same-name card or fragments. Unknown quantities
    stay in external temporary params. Blue-card 4-star exception is preserved as B evidence.
    """
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.progression_log=[]

    def evolve_general(self, card: Card, inventory: Dict[str,int], *, use_fragments: bool=False, general_level: int=0) -> Dict[str,Any]:
        if card.kind != "GENERAL": raise ValueError("only GENERAL can evolve in Grid07")
        req=evolution_requirements(card,use_fragments=use_fragments)
        if req.get("at_cap"): raise ValueError("already at 5-star cap")
        if int(general_level) < int(req["level_requirement"]): raise ValueError("level requirement not met")
        needs={"evolution_pills":int(req["evolution_pills"]),"silver":int(req["silver"])}
        if req["material_mode"]=="FRAGMENTS": needs["same_name_fragments"]=int(req["fragments"])
        else: needs["same_name_cards"]=int(req["same_name_cards"])
        for k,v in needs.items():
            if int(inventory.get(k,0)) < v: raise ValueError(f"insufficient {k}")
        for k,v in needs.items(): inventory[k]=int(inventory.get(k,0))-v
        p=progression_state(card); old=int(p["star"]); p["star"]=old+1; p["evolution_count"]=int(p["star"])-1
        p["skill_unlock_count"]=CATALOG["star_to_unlocked_skill_count"][str(p["star"])]
        pct=float(ppv("stat_growth_per_evolution_pct"))
        if pct:
            card.attack=int(round(card.attack*(1+pct))); card.max_hp=int(round(card.max_hp*(1+pct))); card.hp=min(card.max_hp,int(round(card.hp*(1+pct))))
        r={"action":"EVOLVE","card":card.name,"from_star":old,"to_star":p["star"],"evolution_count":p["evolution_count"],"skill_unlock_count":p["skill_unlock_count"],"consumed":needs,"numeric_confidence":req["numeric_confidence"]}
        p["history"].append(r); self.progression_log.append(r); self.log.append(f"GRID07 PROGRESSION {r}"); return r

    def can_transcend(self, card: Card, target_quality: str) -> bool:
        p=progression_state(card); src=normalize_quality(p.get("quality")); target=normalize_quality(target_quality)
        return target in CATALOG["quality_paths"].get(src,[])

    def transcend_general(self, card: Card, target_quality: str) -> Dict[str,Any]:
        if card.kind != "GENERAL": raise ValueError("only GENERAL can transcend")
        if not self.can_transcend(card,target_quality): raise ValueError("unsupported quality path")
        p=progression_state(card); old=normalize_quality(p.get("quality")); new=normalize_quality(target_quality)
        p["quality"]=new
        r={"action":"TRANSCEND","card":card.name,"from_quality":old,"to_quality":new,"material_status":"UNCONFIRMED_NOT_ENFORCED"}
        p["history"].append(r); self.progression_log.append(r); self.log.append(f"GRID07 PROGRESSION {r}"); return r
