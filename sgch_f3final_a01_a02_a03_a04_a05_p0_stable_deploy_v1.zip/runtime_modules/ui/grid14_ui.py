from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Iterable

QUALITY_LABELS = ("橙", "紫", "藍", "綠")
QUALITY_COLORS = {"橙":"#D97706", "紫":"#7C3AED", "藍":"#2563EB", "綠":"#16A34A", None:"#6B7280"}
RECONSTRUCTION_LABEL = "相似邏輯UI｜非100%原版像素復刻"

@dataclass
class CardView:
    card_id: str
    name: str
    quality: str | None = None
    attack: int | None = None
    hp: int | None = None
    faction: str | None = None
    skills: list[str] = field(default_factory=list)
    statuses: list[str] = field(default_factory=list)
    horse: str | None = None
    equipment: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "card_id": self.card_id,
            "name": self.name,
            "quality": self.quality,
            "quality_color": QUALITY_COLORS.get(self.quality, QUALITY_COLORS[None]),
            "attack": self.attack,
            "hp": self.hp,
            "faction": self.faction,
            "skills": list(self.skills),
            "statuses": list(self.statuses),
            "horse": self.horse,
            "equipment": list(self.equipment),
        }

@dataclass
class BattleUIState:
    player_slots: list[CardView | None] = field(default_factory=lambda: [None] * 6)
    enemy_slots: list[CardView | None] = field(default_factory=lambda: [None] * 6)
    hand: list[CardView] = field(default_factory=list)
    player_gate_hp: int = 20
    enemy_gate_hp: int = 20
    fire: int = 0
    turn: int = 1
    active_side: str = "player"

    def __post_init__(self) -> None:
        if len(self.player_slots) != 6 or len(self.enemy_slots) != 6:
            raise ValueError("battle UI requires exactly 6 slots per side")
        if len(self.hand) > 10:
            raise ValueError("hand UI cannot display more than the confirmed 10-card limit")

    def view_model(self) -> dict[str, Any]:
        return {
            "screen":"BATTLE",
            "reconstruction_label": RECONSTRUCTION_LABEL,
            "enemy_gate":{"hp":self.enemy_gate_hp},
            "enemy_slots":[c.as_dict() if c else None for c in self.enemy_slots],
            "player_slots":[c.as_dict() if c else None for c in self.player_slots],
            "player_gate":{"hp":self.player_gate_hp},
            "hand":[c.as_dict() for c in self.hand],
            "hand_count":len(self.hand),
            "hand_limit":10,
            "fire":self.fire,
            "turn":self.turn,
            "active_side":self.active_side,
            "interaction":{
                "card_detail":"tap/click card",
                "skill_tooltip":"tap/click skill badge",
                "horse_equipment":"shown as attached chips on card detail"
            }
        }


def card_detail_view(card: CardView, *, bonds: Iterable[str] = (), acquisition: str | None = None, confidence: str | None = None) -> dict[str, Any]:
    data = card.as_dict()
    data.update({
        "screen":"CARD_DETAIL",
        "reconstruction_label":RECONSTRUCTION_LABEL,
        "bonds":list(bonds),
        "acquisition":acquisition,
        "confidence":confidence,
        "skill_level_table_hint":"士兵／兵書／戰馬技能可於對應建築或卡牌詳情查看各級數值（A級系統線索）"
    })
    return data


def mainline_view(chapter: int, stage: int, mode: str = "普通", food: int | None = None) -> dict[str, Any]:
    if not (1 <= chapter <= 8): raise ValueError("chapter must be 1..8")
    if not (1 <= stage <= 40): raise ValueError("stage must be 1..40")
    if mode not in {"普通","反轉","逆天"}: raise ValueError("invalid mainline mode")
    return {
        "screen":"MAINLINE", "reconstruction_label":RECONSTRUCTION_LABEL,
        "chapter":chapter,"chapter_total":8,"stage":stage,"stage_total":40,
        "mode":mode,"mode_options":["普通","反轉","逆天"],
        "food": food if food is not None else (5 if mode == "普通" else None),
        "sweep":{"visible":True,"requires_cleared_stage":True,"exact_daily_limit":"未確認"},
        "drops":{"soldier_token":"all modes interface","general_fragment":"all modes interface"}
    }


def tavern_view(version: str = "current") -> dict[str, Any]:
    prices = {
        "baseline":{"medium_single":60,"medium_ten":600,"high_single":280,"high_ten":2800},
        "current":{"medium_single":None,"medium_ten":None,"high_single":None,"high_ten":None},
    }
    return {
        "screen":"TAVERN","reconstruction_label":RECONSTRUCTION_LABEL,"version":version,
        "recruit_types":["中級招募","高級招募","高級十連／國別招募","傳說招募（存在性）"],
        "prices":prices.get(version, prices["current"]),
        "first_pull":"新手首次將印校錄保底橙階" if version == "current" else "依版本資料",
        "probabilities":"未確認，不顯示假百分比"
    }


def alliance_view(player_level: int, role: str = "成員") -> dict[str, Any]:
    return {
        "screen":"ALLIANCE","reconstruction_label":RECONSTRUCTION_LABEL,
        "join_unlocked": player_level >= 32,
        "role":role,
        "sections":["成員","建設","科技工坊","僱傭","聯盟BOSS","排行","聯盟對戰"],
        "boss":{"daily_attempts":"固定次數但精確值未確認","snapshot_boss_count":3},
        "city_interface":{"enabled":False,"reason":"精確聯盟城池佔領規則未確認"}
    }


def validate_quality(quality: str | None) -> bool:
    return quality is None or quality in QUALITY_LABELS
