from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional
import importlib.util, json, random, sys

BASE=Path(__file__).resolve().parent; ROOT=BASE.parent
CATALOG=json.loads((BASE/'pve_catalog_v0.9.json').read_text(encoding='utf-8'))
TEMP=json.loads((BASE/'temporary_pve_params.json').read_text(encoding='utf-8'))['parameters']
def tp(k): return TEMP[k]['value']

def _load_grid08():
    p=ROOT/'soldier'/'grid08_engine.py'; spec=importlib.util.spec_from_file_location('grid08_engine_for_grid09',p)
    if spec is None or spec.loader is None: raise ImportError('cannot load grid08')
    m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m; spec.loader.exec_module(m); return m
g8=_load_grid08(); Card=g8.Card; PlayerState=g8.PlayerState

@dataclass(frozen=True)
class StageDef:
    stage_id:str
    mode:str
    stage_name:str
    food_cost:int
    direct_gate_allowed:bool=False
    fragment_drop:Optional[str]=None
    symbol_drop:bool=True
    source_confidence:str='C'
    enemy_gate_hp:Optional[int]=None
    notes:str=''

@dataclass
class CampaignState:
    food:int=100
    sweep_cards:int=10
    sweep_used_today:int=0
    cleared:set[str]=field(default_factory=set)
    inventory:Dict[str,int]=field(default_factory=dict)

MODE_FOOD={'普通':5,'反轉':int(tp('reverse_food_cost')),'逆天':int(tp('heaven_food_cost'))}

def demo_stages()->List[StageDef]:
    # Exactly three first-version demo nodes. Names are evidence-backed where possible;
    # chapter mapping and enemy rosters are deliberately not invented.
    return [
        StageDef('DEMO_NORMAL','普通','示範普通關',5,False,None,True,'A/C',notes='普通5糧草為A；關名/敵組為示範'),
        StageDef('DEMO_REVERSE_BEIHAI','反轉','北海',MODE_FOOD['反轉'],False,'張飛碎片',True,'B/C',notes='5反轉北海→張飛為B；糧草精確值C'),
        StageDef('DEMO_HEAVEN_YINGCHUAN','逆天','穎川',MODE_FOOD['逆天'],True,'陸遜碎片',True,'B/C',notes='1逆天穎川→陸遜為B；direct_gate僅代表部分關卡接口，不宣稱穎川原版必可直破')
    ]

class PVEEngine:
    def __init__(self,state:Optional[CampaignState]=None,seed:int=1):
        self.state=state or CampaignState(); self.rng=random.Random(seed); self.log=[]
    def validate_stage(self,s:StageDef):
        if s.mode not in ('普通','反轉','逆天'): raise ValueError('invalid mode')
        if s.food_cost < 0: raise ValueError('invalid food cost')
    def begin_stage(self,s:StageDef)->Dict[str,Any]:
        self.validate_stage(s)
        if self.state.food < s.food_cost: raise ValueError('insufficient food')
        self.state.food -= s.food_cost
        r={'action':'BEGIN_STAGE','stage_id':s.stage_id,'mode':s.mode,'food_cost':s.food_cost,'food_after':self.state.food}
        self.log.append(r); return r
    def finish_stage(self,s:StageDef,won:bool,*,victory_reason:Optional[str]=None,force_fragment_drop:bool=False)->Dict[str,Any]:
        refund=0
        if not won:
            refund=int(round(s.food_cost*float(tp('failure_refund_ratio')))); self.state.food += refund
            r={'action':'STAGE_LOSS','stage_id':s.stage_id,'refund':refund,'food_after':self.state.food,'refund_confidence':'C'}; self.log.append(r); return r
        if victory_reason=='GATE_DESTROYED' and not s.direct_gate_allowed:
            raise ValueError('direct gate victory not enabled for this stage definition')
        self.state.cleared.add(s.stage_id)
        drops=[]
        if s.symbol_drop:
            n=int(tp('demo_food_reward_symbol')); self.state.inventory['兵符']=self.state.inventory.get('兵符',0)+n; drops.append({'item':'兵符','qty':n,'qty_confidence':'C'})
        if s.fragment_drop and force_fragment_drop:
            self.state.inventory[s.fragment_drop]=self.state.inventory.get(s.fragment_drop,0)+1; drops.append({'item':s.fragment_drop,'qty':1,'qty_confidence':'C','drop_identity_confidence':'B'})
        r={'action':'STAGE_WIN','stage_id':s.stage_id,'victory_reason':victory_reason,'drops':drops,'sweep_unlocked':True}; self.log.append(r); return r
    def can_sweep(self,s:StageDef)->bool:
        return s.stage_id in self.state.cleared and self.state.sweep_used_today < int(tp('daily_sweep_limit')) and self.state.sweep_cards >= int(tp('sweep_card_cost')) and self.state.food >= s.food_cost
    def sweep(self,s:StageDef,*,force_fragment_drop:bool=False)->Dict[str,Any]:
        if s.stage_id not in self.state.cleared: raise ValueError('stage not cleared')
        if self.state.sweep_used_today >= int(tp('daily_sweep_limit')): raise ValueError('daily sweep limit reached')
        card_cost=int(tp('sweep_card_cost'))
        if self.state.sweep_cards < card_cost: raise ValueError('insufficient sweep cards')
        if self.state.food < s.food_cost: raise ValueError('insufficient food')
        self.state.sweep_cards -= card_cost; self.state.food -= s.food_cost; self.state.sweep_used_today += 1
        drops=[]
        if s.symbol_drop:
            n=int(tp('demo_food_reward_symbol')); self.state.inventory['兵符']=self.state.inventory.get('兵符',0)+n; drops.append({'item':'兵符','qty':n,'qty_confidence':'C'})
        if s.fragment_drop and force_fragment_drop:
            self.state.inventory[s.fragment_drop]=self.state.inventory.get(s.fragment_drop,0)+1; drops.append({'item':s.fragment_drop,'qty':1,'qty_confidence':'C','drop_identity_confidence':'B'})
        r={'action':'SWEEP','stage_id':s.stage_id,'food_cost':s.food_cost,'sweep_card_cost':card_cost,'sweep_used_today':self.state.sweep_used_today,'drops':drops}; self.log.append(r); return r
    def reset_daily(self): self.state.sweep_used_today=0


def campaign_template_8x40()->List[Dict[str,Any]]:
    # Structural slots only; no invented chapter/stage names.
    out=[]
    for chapter in range(1,9):
        for section in range(1,6):
            out.append({'chapter':chapter,'section':section,'official_name':None,'modes':['普通','反轉','逆天'],'evidence':'8章40節 A/B','status':'NAME_UNCONFIRMED'})
    return out
