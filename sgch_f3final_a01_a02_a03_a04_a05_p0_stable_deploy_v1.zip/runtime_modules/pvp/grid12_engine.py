from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Any, Optional, Iterable
from datetime import datetime, timedelta
import json, random

BASE=Path(__file__).resolve().parent
CATALOG=json.loads((BASE/'pvp_catalog_v1.2.json').read_text(encoding='utf-8'))
TEMP=json.loads((BASE/'temporary_pvp_params.json').read_text(encoding='utf-8'))['parameters']
def tp(k): return TEMP[k]['value']

@dataclass
class PVPPlayer:
    player_id: str
    level: int=1
    server: str='S1'
    micro_points: int=0
    daily_wins: int=0
    claimed_chests: set[int]=field(default_factory=set)
    resources: Dict[str,int]=field(default_factory=dict)
    dragon_seals: int=0
    occupied_cities: int=0

@dataclass(frozen=True)
class DraftCard:
    card_id: str
    quality: str
    level: int=1
    equipment_level: int=0

class PVPEngine:
    def __init__(self, *, seed:int=1):
        self.rng=random.Random(seed)
        self.protection_until:Dict[tuple[str,str],datetime]={}
        self.log:List[Dict[str,Any]]=[]

    @staticmethod
    def system_status(system_id:str)->Dict[str,Any]:
        for s in CATALOG['systems']:
            if s['id']==system_id: return dict(s)
        raise KeyError(system_id)

    def conquest_available(self,p:PVPPlayer)->bool:
        return p.level>=15

    def can_conquer(self,attacker:PVPPlayer,defender:PVPPlayer,*,now:Optional[datetime]=None)->bool:
        if not self.conquest_available(attacker): return False
        now=now or datetime.now()
        until=self.protection_until.get((attacker.player_id,defender.player_id))
        return until is None or now>=until

    def resolve_conquest(self,attacker:PVPPlayer,defender:PVPPlayer,*,attacker_won:bool,now:Optional[datetime]=None,occupy_city:bool=True)->Dict[str,Any]:
        now=now or datetime.now()
        if not self.conquest_available(attacker): raise ValueError('討伐需15級')
        if not self.can_conquer(attacker,defender,now=now): raise ValueError('same-attacker protection active')
        rewards={}
        if attacker_won:
            rewards=dict(tp('conquest_win_rewards'))
            for k,v in rewards.items(): attacker.resources[k]=attacker.resources.get(k,0)+int(v)
            if occupy_city and defender.occupied_cities<int(tp('conquest_max_occupied_cities')):
                defender.occupied_cities+=1
        else:
            mins=int(tp('conquest_protection_minutes'))
            self.protection_until[(attacker.player_id,defender.player_id)]=now+timedelta(minutes=mins)
        r={'mode':'CONQUEST','winner':'attacker' if attacker_won else 'defender','rewards':rewards,'defender_occupied_cities':defender.occupied_cities,'protection_minutes':int(tp('conquest_protection_minutes')) if not attacker_won else 0}
        self.log.append(r); return r

    def micro_rank(self,points:int)->str:
        thresholds=dict(tp('micro_rank_thresholds'))
        best=None; bestv=-10**9
        for name,val in thresholds.items():
            if points>=int(val) and int(val)>=bestv: best=name; bestv=int(val)
        return best or '未定'

    def resolve_micro_arena(self,p:PVPPlayer,*,won:bool)->Dict[str,Any]:
        delta=int(tp('micro_points_per_win') if won else tp('micro_points_per_loss'))
        p.micro_points=max(0,p.micro_points+delta)
        if won: p.daily_wins+=1
        r={'mode':'MICRO_ARENA','won':won,'points_delta':delta,'points':p.micro_points,'rank':self.micro_rank(p.micro_points),'daily_wins':p.daily_wins}
        self.log.append(r); return r

    def available_micro_chests(self,p:PVPPlayer)->List[int]:
        return [int(x) for x in tp('micro_chest_win_thresholds') if p.daily_wins>=int(x) and int(x) not in p.claimed_chests]

    def claim_micro_chest(self,p:PVPPlayer,threshold:int)->Dict[str,int]:
        threshold=int(threshold)
        if threshold not in [int(x) for x in tp('micro_chest_win_thresholds')]: raise ValueError('unknown chest threshold')
        if p.daily_wins<threshold: raise ValueError('insufficient wins')
        if threshold in p.claimed_chests: raise ValueError('already claimed')
        rewards=dict(tp('micro_chest_rewards')).get(str(threshold),{})
        p.claimed_chests.add(threshold)
        for k,v in rewards.items(): p.resources[k]=p.resources.get(k,0)+int(v)
        return dict(rewards)

    @staticmethod
    def glory_ranking(players:Iterable[PVPPlayer])->List[PVPPlayer]:
        return sorted(players,key=lambda p:(-p.micro_points,p.player_id))

    def resolve_heroes_contest(self,p:PVPPlayer,*,won:bool)->Dict[str,Any]:
        delta=int(tp('season_dragon_seal_win') if won else tp('season_dragon_seal_loss'))
        p.dragon_seals=max(0,p.dragon_seals+delta)
        return {'mode':'HEROES_CONTEST','won':won,'dragon_seal_delta':delta,'dragon_seals':p.dragon_seals}

    @staticmethod
    def season_ranking(players:Iterable[PVPPlayer])->List[Dict[str,Any]]:
        ordered=sorted(players,key=lambda p:(-p.dragon_seals,p.player_id))
        thrones=CATALOG['season_thrones']
        return [{'rank':i+1,'player_id':p.player_id,'dragon_seals':p.dragon_seals,'throne':thrones[i] if i<3 else None} for i,p in enumerate(ordered)]

    def hundred_generals_draft(self,cards:Iterable[DraftCard],*,refresh:bool=False,allow_planned:bool=False)->List[DraftCard]:
        status=self.system_status('HUNDRED_GENERALS')
        if not status['live'] and not allow_planned: raise ValueError('百將亂鬥在此版本快照尚未實裝')
        pool=list(cards)
        if not pool: raise ValueError('empty draft pool')
        qualities=set(CATALOG['hundred_generals_qualities'])
        pool=[c for c in pool if c.quality in qualities]
        n=min(int(tp('hundred_generals_deck_size')),len(pool))
        selected=self.rng.sample(pool,n)
        lv=int(tp('hundred_generals_fixed_level')); eq=int(tp('hundred_generals_fixed_equipment_level'))
        return [DraftCard(c.card_id,c.quality,lv,eq) for c in selected]

    def hundred_generals_cross_server_allowed(self,a:PVPPlayer,b:PVPPlayer)->bool:
        return True

    def realtime_match(self,*args,**kwargs):
        if not bool(tp('realtime_pvp_enabled')): raise ValueError('即時真人PVP在2016-09-10版本快照尚未實裝')
        return {'matched':True}
