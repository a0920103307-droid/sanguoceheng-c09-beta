from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

BASE = Path(__file__).resolve().parent
REGISTRY = json.loads((BASE / "calibration_registry_v1.5.json").read_text(encoding="utf-8"))
PARAMS: Dict[str, Dict[str, Any]] = REGISTRY["parameters"]

@dataclass(frozen=True)
class ParameterValue:
    key: str
    original: Any
    temporary: Any
    balance: Any
    confidence: str
    unit: str
    note: str


def get_parameter(key: str) -> ParameterValue:
    p = PARAMS[key]
    return ParameterValue(key, p.get("original"), p.get("temporary"), p.get("balance"), p.get("confidence", ""), p.get("unit", ""), p.get("note", ""))


def effective_value(key: str, mode: str = "RECONSTRUCTION") -> Any:
    """Resolve without mutating the three layers.

    RECONSTRUCTION: original > temporary > balance
    BALANCE_TEST: confirmed original is immutable; otherwise balance > temporary
    ORIGINAL_ONLY: returns original or None
    """
    p = PARAMS[key]
    if mode == "ORIGINAL_ONLY":
        return p.get("original")
    if mode == "BALANCE_TEST":
        return p.get("original") if p.get("original") is not None else p.get("balance", p.get("temporary"))
    if mode == "RECONSTRUCTION":
        return p.get("original") if p.get("original") is not None else p.get("temporary", p.get("balance"))
    raise ValueError(f"unknown mode: {mode}")


def validate_three_layers() -> List[str]:
    errors=[]
    for key,p in PARAMS.items():
        for layer in ("original","temporary","balance"):
            if layer not in p:
                errors.append(f"{key}: missing {layer}")
        if p.get("original") is not None and effective_value(key,"BALANCE_TEST") != p.get("original"):
            errors.append(f"{key}: balance mode overwrote original")
    return errors


def scale_ratio(effect_key: str, base_key: str, mode: str = "BALANCE_TEST") -> float:
    base = float(effective_value(base_key, mode))
    return float(effective_value(effect_key, mode)) / base if base else float("inf")


def break_state_checks() -> Dict[str, Dict[str, Any]]:
    """Static/deterministic checks for known reconstruction failure modes."""
    r: Dict[str, Dict[str, Any]] = {}

    fire_gain = float(effective_value("battle.fire_per_turn","BALANCE_TEST"))
    fire_cap = float(effective_value("battle.fire_cap","BALANCE_TEST"))
    play_cost = float(effective_value("battle.play_fire_cost","BALANCE_TEST"))
    r["infinite_resource_loop"] = {
        "pass": fire_gain >= 0 and fire_cap > 0 and play_cost > 0,
        "detail": f"fire_gain={fire_gain}, fire_cap={fire_cap}, play_cost={play_cost}; finite cap/cost prevents unbounded stored fire"
    }

    general_hp = float(effective_value("card.general_hp","BALANCE_TEST"))
    impact = float(effective_value("command.impact_damage","BALANCE_TEST"))
    r["unsolvable_board"] = {
        "pass": general_hp > 0 and impact > 0,
        "detail": f"baseline_hp={general_hp}, direct_removal_proxy={impact}; removal exists and is not zero"
    }

    gate_hp = float(effective_value("battle.gate_hp","BALANCE_TEST"))
    baseline_atk = float(effective_value("card.general_attack","BALANCE_TEST"))
    single_unit_gate_hits = gate_hp / max(1.0, baseline_atk)
    r["too_fast_gate"] = {
        "pass": single_unit_gate_hits >= 8,
        "detail": f"single baseline attacker needs ~{single_unit_gate_hits:.1f} unblocked hits to break gate"
    }

    opening = float(effective_value("battle.opening_hand","BALANCE_TEST"))
    draw = float(effective_value("battle.draw_per_turn","BALANCE_TEST"))
    deck = float(effective_value("battle.deck_size_target","BALANCE_TEST"))
    hand_limit = float(effective_value("battle.hand_limit","BALANCE_TEST"))
    r["resource_imbalance"] = {
        "pass": 0 < opening <= hand_limit and 0 <= draw <= 3 and deck >= hand_limit,
        "detail": f"opening={opening}, draw={draw}, deck={deck}, hand_limit={hand_limit}"
    }

    strongest_ratios = {
        "war_intent_atk/base_atk": scale_ratio("command.war_intent_attack","card.general_attack"),
        "weapon_atk/base_atk": scale_ratio("equipment.weapon_attack_bonus","card.general_attack"),
        "xinan_atk/base_atk": scale_ratio("horse.xinan_attack_bonus","card.general_attack"),
        "impact/base_hp": scale_ratio("command.impact_damage","card.general_hp"),
    }
    max_ratio=max(strongest_ratios.values())
    r["single_card_dominance"] = {
        "pass": max_ratio <= 1.0,
        "detail": strongest_ratios
    }
    return r


def calibration_summary() -> Dict[str, Any]:
    known=sum(1 for p in PARAMS.values() if p.get("original") is not None)
    unknown=len(PARAMS)-known
    checks=break_state_checks()
    return {
        "parameter_count": len(PARAMS),
        "original_known": known,
        "original_unknown": unknown,
        "three_layer_errors": validate_three_layers(),
        "break_checks_passed": sum(1 for x in checks.values() if x["pass"]),
        "break_checks_total": len(checks),
        "break_checks": checks,
    }

if __name__ == "__main__":
    print(json.dumps(calibration_summary(), ensure_ascii=False, indent=2))
