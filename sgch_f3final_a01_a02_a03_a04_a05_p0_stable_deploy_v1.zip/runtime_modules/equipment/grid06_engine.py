from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional
from copy import deepcopy
import importlib.util, json, sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
CATALOG = json.loads((BASE / "equipment_catalog_v0.6.json").read_text(encoding="utf-8"))
TEMP = json.loads((BASE / "temporary_equipment_params.json").read_text(encoding="utf-8"))["parameters"]

def epv(name: str): return TEMP[name]["value"]

def _load_grid05():
    path = ROOT / "horse" / "grid05_engine.py"
    spec = importlib.util.spec_from_file_location("grid05_engine_for_grid06", path)
    if spec is None or spec.loader is None: raise ImportError("cannot load grid05 engine")
    mod = importlib.util.module_from_spec(spec); sys.modules[spec.name] = mod; spec.loader.exec_module(mod); return mod

g5 = _load_grid05()
Card = g5.Card
PlayerState = g5.PlayerState
_state = g5._state

@dataclass(frozen=True)
class EquipmentRecord:
    equipment_id: str
    name: str
    slot: str
    quality: str
    exclusive_to: Optional[str]
    confidence: str
    source: str

def equipment_records() -> List[EquipmentRecord]: return [EquipmentRecord(**x) for x in CATALOG["equipment"]]
def find_equipment(name: str) -> EquipmentRecord:
    for e in equipment_records():
        if e.name == name or e.equipment_id == name: return e
    raise KeyError(name)

def _equipment_state(card: Card) -> Dict[str, Any]:
    st = _state(card)
    st.setdefault("equipment", {"WEAPON": None, "ARMOR": None})
    st.setdefault("skill_levels", {})
    return st

def equipped(card: Card, slot: str) -> Optional[Dict[str, Any]]: return _equipment_state(card)["equipment"].get(slot.upper())
def _skill_names(card: Card) -> List[str]:
    names=[]
    for eff in getattr(card,"effects",[]):
        n=eff.get("skill_name") or eff.get("name")
        if n and n not in names: names.append(str(n))
    extra=_equipment_state(card).get("declared_skills",[])
    for n in extra:
        if n not in names: names.append(n)
    return names

def effective_skill_level(card: Card, skill_name: str) -> int:
    st=_equipment_state(card)
    base=int(st["skill_levels"].get(skill_name, epv("default_skill_level")))
    bonus=0
    for item in st["equipment"].values():
        if item and int(item.get("star",1)) >= int(epv("equipment_star_cap")) and item.get("refined_skill") == skill_name and skill_name in _skill_names(card):
            bonus += int(epv("five_star_skill_level_bonus"))
    return min(int(epv("skill_level_cap")), base+bonus)

class EquipmentBattle(g5.HorseBattle):
    """Grid06 equipment/fate layer over Grid05.

    Confirmed rules: weapon->ATK, armor->HP, five-star equipment grants +1 to an
    existing skill, exclusive equipment fate exists, and equipment supports refine.
    Unknown stat values, fate bonuses, costs and refine probability remain external C params.
    """
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.equipment_log=[]

    def declare_skills(self, card: Card, skills: List[str], levels: Optional[Dict[str,int]]=None):
        st=_equipment_state(card); st["declared_skills"]=list(dict.fromkeys(skills))
        if levels:
            for k,v in levels.items(): st["skill_levels"][k]=int(v)

    def _find_owner(self, target: Card) -> int:
        loc=self._find_card(target)
        if loc is None: raise ValueError("target must be on board")
        return int(loc[0])

    def _apply_item_stats(self, target: Card, item: Dict[str,Any], sign: int):
        if item["slot"] == "WEAPON": target.attack += sign * int(item["attack_bonus"])
        elif item["slot"] == "ARMOR":
            delta=sign * int(item["hp_bonus"]); target.max_hp += delta; target.hp += delta
            if target.max_hp < 1: target.max_hp=1
            if target.hp > target.max_hp: target.hp=target.max_hp
            if target.hp < 1: target.hp=1

    def _fate_bonus(self, target: Card, item: Dict[str,Any], activate: bool):
        if item.get("exclusive_to") != target.name: return
        sign=1 if activate else -1
        if item["slot"] == "WEAPON": target.attack += sign*int(epv("exclusive_fate_attack_bonus"))
        else:
            d=sign*int(epv("exclusive_fate_hp_bonus")); target.max_hp += d; target.hp += d
            if target.hp > target.max_hp: target.hp=target.max_hp
        item["fate_active"] = bool(activate)

    def equip_equipment(self, owner: int, target: Card, equipment_name: str, *, star: int=1, refine_pool: Optional[List[str]]=None) -> Dict[str,Any]:
        if self._find_owner(target) != owner: raise ValueError("target must be owner's board card")
        if target.kind != "GENERAL": raise ValueError("Grid06 first version equipment target is GENERAL")
        rec=find_equipment(equipment_name); slot=rec.slot.upper()
        if equipped(target,slot) is not None: raise ValueError(f"{slot} already equipped")
        if not int(epv("equipment_star_min")) <= int(star) <= int(epv("equipment_star_cap")): raise ValueError("equipment star out of range")
        data={"equipment_id":rec.equipment_id,"name":rec.name,"slot":slot,"quality":rec.quality,"star":int(star),"exclusive_to":rec.exclusive_to,"confidence":rec.confidence,"source":rec.source,"attack_bonus":int(epv("weapon_attack_bonus")) if slot=="WEAPON" else 0,"hp_bonus":int(epv("armor_hp_bonus")) if slot=="ARMOR" else 0,"refine_pool":list(refine_pool or []),"refined_skill":None,"fate_active":False}
        _equipment_state(target)["equipment"][slot]=data; self._apply_item_stats(target,data,1); self._fate_bonus(target,data,True)
        r={"action":"EQUIP","target":target.name,"equipment":rec.name,"slot":slot,"star":int(star),"fate_active":data["fate_active"]}; self.equipment_log.append(r); self.log.append(f"GRID06 EQUIPMENT {r}"); return r

    def unequip_equipment(self, target: Card, slot: str) -> Optional[Dict[str,Any]]:
        slot=slot.upper(); item=equipped(target,slot)
        if item is None: return None
        self._fate_bonus(target,item,False); self._apply_item_stats(target,item,-1); _equipment_state(target)["equipment"][slot]=None
        self.equipment_log.append({"action":"UNEQUIP","target":target.name,"equipment":item["name"],"slot":slot}); return deepcopy(item)

    def strengthen_equipment(self, target: Card, slot: str, stars: int=1) -> Dict[str,Any]:
        item=equipped(target,slot)
        if item is None: raise ValueError("no equipment in slot")
        old=int(item["star"]); item["star"]=min(int(epv("equipment_star_cap")),old+max(0,int(stars)))
        r={"action":"STRENGTHEN","equipment":item["name"],"old_star":old,"new_star":item["star"]}; self.equipment_log.append(r); return r

    def preview_refine_skills(self, target: Card, slot: str) -> List[str]:
        item=equipped(target,slot)
        if item is None: raise ValueError("no equipment in slot")
        return list(item.get("refine_pool",[]))

    def refine_equipment(self, target: Card, slot: str, skill_name: str) -> Dict[str,Any]:
        item=equipped(target,slot)
        if item is None: raise ValueError("no equipment in slot")
        pool=list(item.get("refine_pool",[]))
        if pool and skill_name not in pool: raise ValueError("skill not in visible refine pool")
        item["refined_skill"]=str(skill_name)
        applies = str(skill_name) in _skill_names(target)
        r={"action":"REFINE","equipment":item["name"],"skill":str(skill_name),"wearer_has_skill":applies,"five_star_bonus_active":bool(applies and int(item["star"])>=int(epv("equipment_star_cap")))}; self.equipment_log.append(r); return r

    def fate_status(self, target: Card) -> List[Dict[str,Any]]:
        out=[]
        for slot,item in _equipment_state(target)["equipment"].items():
            if item and item.get("fate_active"):
                out.append({"general":target.name,"equipment":item["name"],"fate_name":"專屬緣分","bonus_status":"C_TEMP_NUMERIC","slot":slot})
        return out
