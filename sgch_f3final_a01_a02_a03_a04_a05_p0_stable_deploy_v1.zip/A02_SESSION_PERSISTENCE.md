# A02｜Session 登入狀態持久化

## 目的
避免 Render restart / redeploy 後，原本有效的 `sgch_session` Cookie 因本機 SQLite sessions 表消失而被判定為未登入。

## 本版變更
- 新增 `game_core/session_store.py`
- Session backend 支援 SQLite / PostgreSQL
- PostgreSQL 使用 `auth_sessions` 表
- `AuthStore` 的 session create / lookup / revoke 已改走 SessionStore
- Session backend 預設跟隨 `SGCH_AUTH_BACKEND`
- 可用 `SGCH_SESSION_BACKEND` 個別覆寫
- PostgreSQL URL 優先序：`SGCH_SESSION_DATABASE_URL` → `SGCH_AUTH_DATABASE_URL` → `DATABASE_URL`
- 新增 `migrations/003_auth_sessions_to_postgres.py`，可把尚未過期的舊 SQLite session 搬入 PostgreSQL

## 安全切換方式
若 A01/A02 一起正式切 PostgreSQL：

- `SGCH_AUTH_BACKEND=postgres`
- `SGCH_SESSION_BACKEND=postgres`（可省略，因會跟隨 AUTH backend；正式部署仍建議明確設定）
- Render 必須提供 `DATABASE_URL` 或 SGCH 專用 URL

切換前先執行 active session migration，可降低玩家在部署切換時被迫重新登入的機率。

## A02 驗收
1. 登入取得 session cookie
2. `/api/auth/me` 或遊戲 API 可辨識玩家
3. restart / redeploy 後，同一 cookie 仍有效
4. logout 後，同一 cookie 立即失效
5. 過期 session 會被清除
6. 找不到對應帳號的孤兒 session 不可登入

## 範圍外
- 玩家存檔持久化：A03
- 登出／失效 UI 統一：A04
