# A01｜帳號資料持久化

## 目標
只處理「玩家帳號資料」持久化，不提前處理 A02 Session 或 A03 玩家存檔。

## 本次設計
- 新增 `game_core/account_store.py`，將帳號資料存取從 `AuthStore` 拆出。
- 預設仍使用 SQLite，避免候選包一部署就直接切斷既有封測帳號。
- `SGCH_AUTH_BACKEND=postgres` 時，帳號資料改用 Render PostgreSQL。
- PostgreSQL 表：`auth_players`。
- Session 仍保留在原本 `accounts.sqlite3` 的 `sessions` 表；這是 A02 的工作範圍。
- `meta`／legacy claim 仍保留 SQLite；不在 A01 擴大範圍。

## PostgreSQL 資料模型
`auth_players`
- `player_id VARCHAR(40) PRIMARY KEY`
- `username VARCHAR(32) UNIQUE NOT NULL`
- `password_hash TEXT NOT NULL`
- `created_at BIGINT NOT NULL`

既有 PBKDF2 密碼雜湊字串原樣搬移，不做明文密碼轉換。

## 遷移順序（不可跳步）
1. 保持線上 `SGCH_AUTH_BACKEND=sqlite`。
2. 在可讀到既有 `accounts.sqlite3` 的環境執行 dry-run：
   `python migrations/002_auth_accounts_to_postgres.py`
3. 確認 `conflicts=0`。
4. 執行：
   `python migrations/002_auth_accounts_to_postgres.py --apply`
5. 直接在 PostgreSQL 核對帳號筆數、player_id、username。
6. 再把 Render 環境變數改為 `SGCH_AUTH_BACKEND=postgres`。
7. 驗證既有帳號登入、重啟／重新部署後仍可登入。
8. A01 驗收完成後才進 A02。

## 回滾
若 PostgreSQL 切換後登入異常，將 `SGCH_AUTH_BACKEND` 改回 `sqlite`。本次遷移不刪除 SQLite 原始帳號表，也不覆寫 PostgreSQL 既有衝突資料。

## 重要限制
Render 若目前的 SQLite 是 ephemeral，必須在舊實例仍可讀取資料時完成搬移或取得 DB 備份；不能先重新部署再期待舊 SQLite 帳號仍存在。
