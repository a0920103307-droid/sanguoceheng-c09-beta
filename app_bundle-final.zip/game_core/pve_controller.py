from __future__ import annotations
from typing import Any, Dict, Optional
from .ui_controller import BattleUIController, UIActionResult
from .pve_runtime import playable_stages, legacy_stage
from .growth_controller import GrowthController
from .tavern_collection import TavernCollectionController
from .progression_runtime import GeneralGrowth
from .savegame import SAVE_SCHEMA, CURRENT_SAVE_VERSION, CURRENT_GAME_VERSION
from .deck_builder import DeckBuildingController
from .dungeon_controller import DailyDungeonController
from .economy_controller import EconomyController
from .arena_controller import AIArenaController
from .alliance_controller import AllianceFrontController
from .balance_c08 import value as c08_value, temporary_value as c08_temporary, enemy_bonus

class PVECampaignController:
    def __init__(self, core, seed:int=7):
        self.core=core; self.seed=seed; self.pve_m=core.modules['pve']
        self.campaign=self.pve_m.PVEEngine(self.pve_m.CampaignState(food=100,sweep_cards=10),seed=seed)
        self.stages={s.stage_id:s for s in playable_stages(self.pve_m)}
        # Compatibility aliases for v0.2/A07 callers. They are hidden from the B04 route UI.
        self.legacy_stage_aliases={'A07_NORMAL_01':'B04_01','A07_REVERSE_BEIHAI':'B04_08','A07_HEAVEN_YINGCHUAN':'B04_02'}
        for old,new in self.legacy_stage_aliases.items(): self.stages[old]=self.stages[new]
        self.growth=GrowthController(core.modules['progression'])
        self.collection=TavernCollectionController(core,self.growth)
        self.decks=DeckBuildingController(self.collection)
        self.dungeons=DailyDungeonController(self.growth)
        self.economy=EconomyController(self.growth,self.collection,self.campaign)
        self.arena=AIArenaController(core,self.growth,self.decks,seed=seed)
        self.alliance=AllianceFrontController(core,self.growth)
        self.screen='MAIN'; self.selected=None; self.battle_ui:Optional[BattleUIController]=None; self.last_result=None; self.run_no=0
        self.stage_stars={}; self.first_clear_claimed=set(); self._legacy_run=False
        self.tutorial={'version':'C06','status':'not_started','step':0,'reward_claimed':False,'completed_count':0}
        self.save_manager=None; self.save_status={'enabled':False,'game_version':CURRENT_GAME_VERSION,'save_version':CURRENT_SAVE_VERSION}


    def _enemy_deck_for_stage(self, stage):
        """P04.2 closed-beta enemy rosters.

        These are explicit prototype/balance rosters, separate from the player's
        collection. Each name is unique; no synthetic duplicate cards are created.
        """
        rosters={
            'B04_01':['貂蟬'],
            'B04_02':['黃蓋','董卓'],
            'B04_03':['夏侯惇','荀彧'],
            'B04_04':['張郃','程昱'],
            'B04_05':['劉備','小喬'],
            'B04_06':['曹操','孫權'],
            'B04_07':['郭嘉','夏侯淵'],
            'B04_08':['袁紹','公孫瓚','龐德'],
            'B04_09':['張角','陳宮','許攸'],
            'B04_10':['曹操','郭嘉','張郃'],
        }
        return list(rosters.get(stage.stage_id,['貂蟬']))

    def attach_save_manager(self, manager):
        self.save_manager=manager
        self.save_status={'enabled':True,'game_version':CURRENT_GAME_VERSION,'save_version':CURRENT_SAVE_VERSION,'path':str(manager.path)}
        return self.save_status
    def autosave(self, reason='state_change'):
        if not self.save_manager: return {'saved':False,'reason':'disabled'}
        self.save_manager.save(self, backup=True, reason=reason)
        self.save_status.update({'last_reason':reason,'last_ok':True})
        return {'saved':True,'reason':reason}
    def export_savegame(self):
        c=self.collection; t=c.engine.state; g=self.growth.roster
        payload={
            'profile':{'screen':self.screen if self.screen!='BATTLE' else 'MAIN','selected_stage_id':None if not self.selected else self.selected.stage_id,'run_no':self.run_no},
            'pve':{'food':self.campaign.state.food,'sweep_cards':self.campaign.state.sweep_cards,'sweep_used_today':self.campaign.state.sweep_used_today,'cleared':sorted(self.campaign.state.cleared),'inventory':dict(self.campaign.state.inventory),'stage_stars':dict(self.stage_stars),'first_clear_claimed':sorted(self.first_clear_claimed),'last_result':self.last_result},
            'tavern':{'version':t.version,'yuanbao':t.yuanbao,'owned':dict(t.owned),'fragments':dict(t.fragments),'soul_qi':t.soul_qi,'first_tavern_draw_done':t.first_tavern_draw_done,'draw_count':t.draw_count,'recruit_tickets':c.recruit_tickets,'lineup':list(c.lineup),'last_recruit':c.last_recruit},
            'decks':self.decks.export(),
            'dungeons':self.dungeons.export(),
            'economy':self.economy.export(),
            'arena':self.arena.export(),
            'alliance':self.alliance.export(),
            'growth':g.state(),
            'loadout':{'owned_equipment':dict(g.owned_equipment),'owned_horses':dict(g.owned_horses),'owned_books':dict(g.owned_books)},
            'player_resources':dict(g.resources),
            'subsystems':{'tutorial':dict(self.tutorial)},
            'meta':{'source':'Prototype v0.3 B01','core_version':'A10-forward-compatible'}
        }
        return {'schema':SAVE_SCHEMA,'save_version':CURRENT_SAVE_VERSION,'game_version':CURRENT_GAME_VERSION,'payload':payload}
    def import_savegame(self, doc):
        if doc.get('schema')!=SAVE_SCHEMA: raise ValueError('未知存檔 schema')
        p=doc.get('payload') or {}; pve=p.get('pve') or {}; tav=p.get('tavern') or {}; growth=p.get('growth') or {}; loadout=p.get('loadout') or {}
        tut=((p.get('subsystems') or {}).get('tutorial') or {})
        if isinstance(tut,dict):
            self.tutorial={'version':'C06','status':str(tut.get('status','not_started')),'step':max(0,min(9,int(tut.get('step',0)))),'reward_claimed':bool(tut.get('reward_claimed',False)),'completed_count':max(0,int(tut.get('completed_count',0)))}
        st=self.campaign.state
        st.food=int(pve.get('food',st.food)); st.sweep_cards=int(pve.get('sweep_cards',st.sweep_cards)); st.sweep_used_today=int(pve.get('sweep_used_today',st.sweep_used_today)); st.cleared=set(str(x) for x in pve.get('cleared',[]) if x); st.inventory={str(k):int(v) for k,v in (pve.get('inventory') or {}).items()}
        self.stage_stars={str(k):max(0,min(3,int(v))) for k,v in (pve.get('stage_stars') or {}).items()}
        self.first_clear_claimed=set(str(x) for x in pve.get('first_clear_claimed',[]) if x)
        # Migration: any legacy cleared node that maps by old id remains valid; B04 route itself starts at node 1 unless already cleared.
        if 'A07_NORMAL_01' in st.cleared: st.cleared.add('B04_01')
        ts=self.collection.engine.state
        ts.version=str(tav.get('version',ts.version)); ts.yuanbao=int(tav.get('yuanbao',ts.yuanbao)); ts.owned={str(k):int(v) for k,v in (tav.get('owned') or {}).items()}; ts.fragments={str(k):int(v) for k,v in (tav.get('fragments') or {}).items()}; ts.soul_qi=int(tav.get('soul_qi',ts.soul_qi)); ts.first_tavern_draw_done=bool(tav.get('first_tavern_draw_done',False)); ts.draw_count=int(tav.get('draw_count',0))
        self.collection.recruit_tickets=int(tav.get('recruit_tickets',self.collection.recruit_tickets)); lineup=[str(x) for x in tav.get('lineup',[]) if str(x) in self.collection.by_name]; self.collection.lineup=lineup or ['張遼']; self.collection.last_recruit=tav.get('last_recruit')
        if p.get('decks'): self.decks.import_data(p.get('decks'))
        else:
            # B02/B01 migration: preserve legacy combat until player explicitly saves/selects a B03 deck.
            self.decks.slot(1).name='舊版編隊'; self.decks.slot(1).cards=list(self.collection.lineup); self.decks.formal_active=False
        self.dungeons.import_data(p.get('dungeons') or {})
        self.economy.import_data(p.get('economy') or {})
        self.arena.import_data(p.get('arena') or {})
        self.alliance.import_data(p.get('alliance') or {})
        roster=self.growth.roster; roster.resources={str(k):int(v) for k,v in (growth.get('resources') or p.get('player_resources') or roster.resources).items()}
        roster.owned_equipment={str(k):int(v) for k,v in (loadout.get('owned_equipment') or growth.get('owned_equipment') or roster.owned_equipment).items()}; roster.owned_horses={str(k):int(v) for k,v in (loadout.get('owned_horses') or growth.get('owned_horses') or roster.owned_horses).items()}; roster.owned_books={str(k):int(v) for k,v in (loadout.get('owned_books') or growth.get('owned_books') or roster.owned_books).items()}
        gens={}
        for name, rec in (growth.get('generals') or {}).items():
            if name not in self.collection.by_name: continue
            allowed={k:v for k,v in rec.items() if k in GeneralGrowth.__dataclass_fields__}
            allowed['name']=name
            gens[name]=GeneralGrowth(**allowed)
        if not gens: gens=roster.generals
        roster.generals=gens
        # Ensure every owned card has a growth profile; v0.2 did this during recruit.
        for cid in ts.owned:
            c=self.collection.by_id.get(cid)
            if c and c['name'] not in roster.generals: roster.generals[c['name']]=GeneralGrowth(name=c['name'],quality=c.get('quality') or '橙')
        prof=p.get('profile') or {}; self.run_no=int(prof.get('run_no',0)); sid=prof.get('selected_stage_id'); self.selected=self.stages.get(sid); wanted=str(prof.get('screen','MAIN')); self.screen=wanted if wanted in {'MAIN','STAGE_SELECT','GROWTH','TAVERN','COLLECTION','DUNGEONS','ECONOMY','ARENA','ALLIANCE','RESULT'} else 'MAIN'; self.battle_ui=None; lr=pve.get('last_result'); self.last_result=lr if isinstance(lr,dict) else None; self.screen='MAIN' if self.screen=='RESULT' and self.last_result is None else self.screen
        # Synchronize duplicate fragments into growth resource keys.
        for cid,qty in ts.fragments.items():
            c=self.collection.by_id.get(cid)
            if c: roster.resources[f"{c['name']}碎片"]=int(qty)
        return self.state()

    def tutorial_action(self, action):
        steps=10
        a=str(action)
        if a=='tutorial_start':
            self.tutorial['status']='in_progress'; self.tutorial['step']=0
            self.autosave('c06_tutorial_start')
            return UIActionResult(True,self.state(),'新手教學開始')
        if a=='tutorial_next':
            self.tutorial['status']='in_progress'
            self.tutorial['step']=min(steps-1,int(self.tutorial.get('step',0))+1)
            self.autosave('c06_tutorial_next')
            return UIActionResult(True,self.state(),'教學進度已更新')
        if a=='tutorial_prev':
            self.tutorial['status']='in_progress'; self.tutorial['step']=max(0,int(self.tutorial.get('step',0))-1)
            self.autosave('c06_tutorial_prev')
            return UIActionResult(True,self.state(),'教學進度已更新')
        if a in {'tutorial_complete','tutorial_skip'}:
            if not self.tutorial.get('reward_claimed'):
                self.collection.recruit_tickets+=5
                self.growth.roster.resources['銀幣']=int(self.growth.roster.resources.get('銀幣',0))+300
                self.tutorial['reward_claimed']=True
            self.tutorial['status']='completed' if a=='tutorial_complete' else 'skipped'
            self.tutorial['step']=steps-1
            if a=='tutorial_complete': self.tutorial['completed_count']=int(self.tutorial.get('completed_count',0))+1
            self.autosave('c06_tutorial_finish')
            return UIActionResult(True,self.state(),'新手教學已完成，新手獎勵已發放' if a=='tutorial_complete' else '已跳過教學，新手獎勵已保留發放')
        if a=='tutorial_replay':
            self.tutorial['status']='in_progress'; self.tutorial['step']=0
            self.autosave('c06_tutorial_replay')
            return UIActionResult(True,self.state(),'重新觀看新手教學')
        return UIActionResult(False,self.state(),'未知教學操作')

    def _stage_unlocked(self,s):
        return s.unlock_after is None or s.unlock_after in self.campaign.state.cleared
    def _stage_view(self,s):
        unlocked=self._stage_unlocked(s)
        return {'stage_id':s.stage_id,'order':s.order,'mode':s.mode,'name':s.name,'food_cost':s.food_cost,'victory_rule':s.victory_rule,'enemy_gate_hp':s.enemy_gate_hp,'fragment_drop':s.fragment_drop,'description':s.description,'source_layer':s.source_layer,'unlock_after':s.unlock_after,'unlocked':unlocked,'cleared':s.stage_id in self.campaign.state.cleared,'stars':int(self.stage_stars.get(s.stage_id,0)),'star_conditions':list(s.star_conditions),'enemy_preview':self._enemy_deck_for_stage(s),'first_clear_claimed':s.stage_id in self.first_clear_claimed,'can_sweep':unlocked and self.campaign.can_sweep(legacy_stage(self.pve_m,s))}
    def state(self)->Dict[str,Any]:
        base={'screen':self.screen,'pve_version':'A10','campaign_version':'B04','tutorial':dict(self.tutorial),'food':self.campaign.state.food,'sweep_cards':self.campaign.state.sweep_cards,'sweep_used_today':self.campaign.state.sweep_used_today,'inventory':dict(self.campaign.state.inventory),'stages':[self._stage_view(s) for k,s in self.stages.items() if k.startswith('B04_')],'selected_stage':None if not self.selected else self._stage_view(self.selected),'last_result':self.last_result,'growth':self.growth.state(),'collection':self.collection.state(),'decks':self.decks.state(),'dungeons':self.dungeons.state(),'economy':self.economy.state(),'arena':self.arena.state(),'alliance':self.alliance.state(),'save':dict(self.save_status)}
        if self.screen=='BATTLE' and self.battle_ui:
            b=self.battle_ui.state(); base['battle']=b
            if b['completed']: self._settle_if_needed(); base.update({'screen':self.screen,'last_result':self.last_result,'growth':self.growth.state(),'collection':self.collection.state(),'decks':self.decks.state(),'dungeons':self.dungeons.state(),'economy':self.economy.state(),'arena':self.arena.state(),'alliance':self.alliance.state(),'save':dict(self.save_status)})
        return base
    def open_stages(self): self.screen='STAGE_SELECT'; return UIActionResult(True,self.state(),'選擇關卡')
    def open_growth(self): self.screen='GROWTH'; return UIActionResult(True,self.state(),'進入武將養成')
    def open_tavern(self): self.screen='TAVERN'; return UIActionResult(True,self.state(),'進入酒館')
    def open_collection(self): self.screen='COLLECTION'; return UIActionResult(True,self.state(),'進入收藏／編隊')
    def open_dungeons(self): self.screen='DUNGEONS'; return UIActionResult(True,self.state(),'進入每日副本')
    def open_economy(self): self.screen='ECONOMY'; return UIActionResult(True,self.state(),'進入資源中心')
    def open_arena(self): self.screen='ARENA'; return UIActionResult(True,self.state(),'進入 AI 競技場')
    def open_alliance(self): self.screen='ALLIANCE'; return UIActionResult(True,self.state(),'進入聯盟')
    def alliance_action(self,action,**data):
        try:
            fn={'alliance_join':lambda:self.alliance.join(str(data.get('alliance_id') or 'NPC_ALLIANCE_1')),'alliance_create':lambda:self.alliance.create(str(data.get('name') or '我的聯盟')),'alliance_contribute':lambda:self.alliance.contribute(int(data.get('amount',50))),'alliance_tech':lambda:self.alliance.upgrade_tech(str(data.get('tech') or '攻擊科技')),'alliance_boss_hit':lambda:self.alliance.boss_hit(int(data.get('damage',400))),'alliance_boss_claim':self.alliance.claim_boss,'alliance_hire':lambda:self.alliance.hire(str(data.get('listing_id') or 'NPC_HIRE_1'))}.get(action)
            if not fn: raise ValueError('未知聯盟操作')
            r=fn(); self.screen='ALLIANCE'; self.autosave('b08_'+action); return UIActionResult(True,self.state(),str(r.get('action') or '聯盟操作完成'))
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def arena_challenge(self,opponent_id,force_won=None):
        try:r=self.arena.challenge(str(opponent_id),force_won=force_won); self.screen='ARENA'; self.autosave('arena_match'); return UIActionResult(True,self.state(),('競技勝利' if r['won'] else '競技敗北')+f"｜積分 {r['micro']['points']}")
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def arena_claim_chest(self,threshold):
        try:r=self.arena.claim_chest(int(threshold)); self.screen='ARENA'; self.autosave('arena_chest'); return UIActionResult(True,self.state(),f"已領取 {r['threshold']} 勝寶箱")
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def arena_reset_season(self,new_season_id=None):
        r=self.arena.reset_season(new_season_id); self.screen='ARENA'; self.autosave('arena_season_reset'); return UIActionResult(True,self.state(),f"賽季已重置：{r['season_id']}")
    def economy_claim_daily(self):
        try:r=self.economy.claim_daily_supply(); self.screen='ECONOMY'; self.autosave('economy_daily_supply'); return UIActionResult(True,self.state(),f'已領取每日循環補給：{r["day"]}')
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def economy_exchange(self,exchange_id):
        try:r=self.economy.exchange(str(exchange_id)); self.screen='ECONOMY'; self.autosave('economy_exchange'); return UIActionResult(True,self.state(),f'兌換完成：{r["exchange_id"]}')
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def dungeon_challenge(self,dungeon_id):
        r=self.dungeons.challenge(str(dungeon_id)); self.screen='DUNGEONS'
        if r.ok: self.autosave('dungeon_challenge')
        return UIActionResult(r.ok,self.state(),r.message)
    def tavern_recruit(self,count=1):
        try:r=self.collection.recruit(int(count)); self.screen='TAVERN'; self.autosave('tavern_recruit'); return UIActionResult(True,self.state(),f'招募完成：{len(r["results"])} 張')
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def lineup_action(self,names):
        # Backward-compatible A09/A10 API. B03 browser/API uses save_deck/select_deck.
        try:r=self.collection.set_lineup(list(names)); self.decks.formal_active=False; self.screen='COLLECTION'; self.autosave('set_lineup_legacy'); return UIActionResult(True,self.state(),f'編隊完成：{"、".join(r["lineup"])}')
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def deck_save_action(self,slot_id,name,cards):
        try:r=self.decks.save_slot(int(slot_id),str(name),list(cards)); self.screen='COLLECTION'; self.autosave('save_deck'); return UIActionResult(True,self.state(),f'已保存 {r["slot"]["name"]}')
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def deck_select_action(self,slot_id):
        try:r=self.decks.select_slot(int(slot_id)); self.screen='COLLECTION'; self.autosave('select_deck'); return UIActionResult(True,self.state(),f'已切換 {r["slot"]["name"]}')
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
    def back_main(self): self.screen='MAIN'; self.selected=None; self.battle_ui=None; return UIActionResult(True,self.state(),'回到主介面')
    def growth_action(self,action,**data):
        r=self.growth.act(action,**data); self.screen='GROWTH';
        if r.ok: self.autosave('growth_'+str(action))
        return UIActionResult(r.ok,self.state(),r.message)
    def select_stage(self,stage_id):
        requested=str(stage_id)
        legacy=requested in self.legacy_stage_aliases
        resolved=self.legacy_stage_aliases.get(requested,requested)
        if resolved not in self.stages:return UIActionResult(False,self.state(),'未知關卡')
        st=self.stages[resolved]
        if not legacy and not self._stage_unlocked(st): return UIActionResult(False,self.state(),'前置關卡尚未通關')
        self.selected=st; self.screen='STAGE_SELECT'; return UIActionResult(True,self.state(),f'已選擇 {self.selected.name}')
    def _apply_growth_to_session(self,sess):
        roster=self.growth.roster
        for zone in ('deck','hand','retreat'):
            for c in list(getattr(sess.battle.players[0],zone,[]) or []): roster.apply_to_card(c)
        p=roster.profile('張遼')
        sess.metadata['growth_version']='A08'; sess.metadata['growth_profile']=roster.state()['generals']['張遼']; sess.metadata['growth_book']=p.equipped_book
    def enter_stage(self,stage_id=None):
        legacy_request=bool(stage_id and str(stage_id) in self.legacy_stage_aliases)
        self._legacy_run=legacy_request
        if stage_id:
            selected_result=self.select_stage(stage_id)
            if not selected_result.ok: return selected_result
        if not self.selected:return UIActionResult(False,self.state(),'請先選擇關卡')
        if not legacy_request and not self._stage_unlocked(self.selected): return UIActionResult(False,self.state(),'前置關卡尚未通關')
        if self.decks.formal_active:
            valid=self.decks.validate_cards(self.decks.active_cards())
            if not valid.get('valid'): return UIActionResult(False,self.state(),'目前正式牌組違規，不能進戰鬥')
        try: self.campaign.begin_stage(legacy_stage(self.pve_m,self.selected))
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
        self.run_no+=1
        deck_names=self.decks.active_cards() if self.decks.formal_active else self.collection.battle_deck_names()
        enemy_deck_names=self._enemy_deck_for_stage(self.selected)
        sess=self.core.create_session(seed=self.seed+self.run_no,victory_rule=self.selected.victory_rule,deck_names=deck_names,enemy_deck_names=enemy_deck_names)
        if legacy_request:
            for pp in sess.battle.players:
                pp.fire=1; pp.gate_hp=20
        sess.pve=self.campaign; sess.metadata['pve_stage']=self.selected.stage_id; sess.metadata['core_version']='A10'; sess.metadata['lineup']=list(self.decks.active_cards() if self.decks.formal_active else self.collection.lineup); sess.metadata['enemy_lineup']=list(enemy_deck_names); sess.metadata['deck_slot_id']=self.decks.active_slot_id if self.decks.formal_active else None; sess.metadata['deck_rule']='B03_FORMAL_NO_ROTATION' if self.decks.formal_active else 'P04_2_UNIQUE_LINEUP'
        sess.battle.players[1].gate_hp=(int(c08_temporary('pve.enemy_gate_hp')[self.selected.order-1]) if legacy_request else self.selected.enemy_gate_hp)
        atk_bonus,hp_bonus=(0,0) if legacy_request else enemy_bonus(self.selected.order)
        if not legacy_request:
            for zone in ('deck','hand'):
                for card in list(getattr(sess.battle.players[1],zone,[]) or []):
                    card.attack=max(0,int(card.attack)+atk_bonus); card.max_hp=max(1,int(card.max_hp)+hp_bonus); card.hp=card.max_hp
        sess.metadata['c08_enemy_balance']={'attack_bonus':atk_bonus,'hp_bonus':hp_bonus,'version':'C08-v1','legacy_compat':legacy_request}
        self._apply_growth_to_session(sess)
        self.battle_ui=BattleUIController(sess); self.battle_ui.session.metadata['ui_version']='A10'; self.battle_ui.ai.pve_safe=True; self.battle_ui.ai.beginner_mode=(self.selected.stage_id=='B04_01')
        self.last_result=None; self.screen='BATTLE'; self.autosave('pve_begin')
        return UIActionResult(True,self.state(),f'進入 {self.selected.mode}｜{self.selected.name}')
    def _grant_training_reward(self,won:bool):
        if not won: return {}
        v=c08_value('economy.outputs')['pve']; reward={'武將經驗':int(v['xp']),'銀幣':int(v['silver'])}
        if int(v.get('pill',0))>0: reward['進化丹']=int(v['pill'])
        for k,v in reward.items(): self.growth.roster.resources[k]=int(self.growth.roster.resources.get(k,0))+v
        return reward
    def _grant_first_clear(self,s):
        if s.stage_id in self.first_clear_claimed: return {}
        reward=dict(s.first_clear)
        for k,v in reward.items(): self.campaign.state.inventory[k]=int(self.campaign.state.inventory.get(k,0))+int(v)
        self.first_clear_claimed.add(s.stage_id)
        return reward
    def _calculate_stars(self,s,b):
        if b.get('winner')!='PLAYER': return 0
        stars=1
        if int(b.get('player_gate_hp') or 0)>=10: stars+=1
        if (s.victory_rule=='GATE_ONLY' and b.get('win_reason')=='GATE_DESTROYED') or (s.victory_rule!='GATE_ONLY' and b.get('win_reason')=='ELIMINATION'): stars+=1
        return min(3,stars)
    def _settle_if_needed(self):
        if not self.battle_ui or self.last_result is not None:return
        b=self.battle_ui.state()
        if not b.get('completed'): return
        won=b['winner']=='PLAYER'; st=legacy_stage(self.pve_m,self.selected)
        try:r=self.campaign.finish_stage(st,won,victory_reason=b['win_reason'],force_fragment_drop=won)
        except ValueError:
            r=self.campaign.finish_stage(st,False); won=False
        training=self._grant_training_reward(won)
        first_clear=self._grant_first_clear(self.selected) if (won and not self._legacy_run) else {}
        stars=self._calculate_stars(self.selected,b) if won else 0
        if won: self.stage_stars[self.selected.stage_id]=max(int(self.stage_stars.get(self.selected.stage_id,0)),stars)
        next_stage=next((x.stage_id for x in self.stages.values() if x.unlock_after==self.selected.stage_id),None) if won else None
        self.last_result={'won':won,'stage_id':self.selected.stage_id,'stage_name':self.selected.name,'mode':self.selected.mode,'battle_reason':b['win_reason'],'settlement':r,'drops':r.get('drops',[]),'food':self.campaign.state.food,'inventory':dict(self.campaign.state.inventory),'training_rewards':training,'first_clear_rewards':first_clear,'stars':stars,'best_stars':int(self.stage_stars.get(self.selected.stage_id,0)),'next_unlocked':next_stage}
        self.screen='RESULT'; self.autosave('pve_settlement')
    def _auto_apply_loadout(self,slot:int):
        if not self.battle_ui: return
        try: c=self.battle_ui.battle.players[0].board[int(slot)]
        except Exception: return
        if not c or c.name not in self.growth.roster.generals: return
        p=self.growth.roster.profile(c.name); b=self.battle_ui.battle
        try:
            if p.equipped_horse and not (getattr(c,'skill_state',{}) or {}).get('horse'):
                b.equip_horse(0,c,p.equipped_horse,level=p.horse_level)
            skills=[x.get('name') for x in getattr(c,'a04_skills',[]) if x.get('name')]; b.declare_skills(c,skills)
            eq=(getattr(c,'skill_state',{}) or {}).get('equipment',{})
            if p.equipped_weapon and not (isinstance(eq,dict) and eq.get('WEAPON')): b.equip_equipment(0,c,p.equipped_weapon,star=p.weapon_star,refine_pool=skills)
            eq=(getattr(c,'skill_state',{}) or {}).get('equipment',{})
            if p.equipped_armor and not (isinstance(eq,dict) and eq.get('ARMOR')): b.equip_equipment(0,c,p.equipped_armor,star=p.armor_star,refine_pool=skills)
            self.battle_ui._sync_legacy_log()
        except Exception as exc: self.battle_ui._log(f'A08 養成配置套用略過：{exc}')
    def battle_action(self,action,**data):
        if not self.battle_ui:return UIActionResult(False,self.state(),'目前沒有戰鬥')
        fn={'start':lambda:self.battle_ui.start_battle(False),'play':lambda:self.battle_ui.play_card(int(data['hand_index']),int(data['slot'])),'end_turn':self.battle_ui.end_turn,'book':lambda:self.battle_ui.use_book(str(data['name'])),'command':lambda:self.battle_ui.use_command(str(data['name']),data.get('target_slot')),'horse':lambda:self.battle_ui.equip_horse(str(data['name']),int(data['target_slot']),int(data.get('level',1))),'equipment':lambda:self.battle_ui.equip_equipment(str(data['name']),int(data['target_slot']),int(data.get('star',1)),data.get('refined_skill')),'horse_mutation':lambda:self.battle_ui.horse_mutation(str(data['mode']),int(data['source_slot']),int(data['target_slot']))}.get(action)
        if not fn:return UIActionResult(False,self.state(),'未知戰鬥操作')
        r=fn()
        if r.ok and action=='play': self._auto_apply_loadout(int(data['slot']))
        self._settle_if_needed(); return UIActionResult(r.ok,self.state(),r.message)
    def sweep(self,stage_id):
        requested=str(stage_id); legacy=requested in self.legacy_stage_aliases; resolved=self.legacy_stage_aliases.get(requested,requested)
        if resolved not in self.stages:return UIActionResult(False,self.state(),'未知關卡')
        st=self.stages[resolved]
        if not legacy and not self._stage_unlocked(st): return UIActionResult(False,self.state(),'前置關卡尚未通關')
        try:r=self.campaign.sweep(legacy_stage(self.pve_m,st),force_fragment_drop=True)
        except Exception as exc:return UIActionResult(False,self.state(),str(exc))
        training=self._grant_training_reward(True)
        self.last_result={'won':True,'sweep':True,'stage_id':st.stage_id,'stage_name':st.name,'mode':st.mode,'settlement':r,'drops':r.get('drops',[]),'food':self.campaign.state.food,'inventory':dict(self.campaign.state.inventory),'training_rewards':training,'first_clear_rewards':{},'stars':int(self.stage_stars.get(st.stage_id,0)),'best_stars':int(self.stage_stars.get(st.stage_id,0)),'next_unlocked':None}
        self.selected=st; self.screen='RESULT'; self.autosave('pve_sweep'); return UIActionResult(True,self.state(),f'掃蕩完成：{st.name}')

