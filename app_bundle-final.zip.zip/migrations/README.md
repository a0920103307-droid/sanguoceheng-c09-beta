# Database migration

This prototype uses SQLite and creates/updates required tables with idempotent `CREATE TABLE IF NOT EXISTS` statements.

Run before first deployment:

```bash
python migrations/001_initialize_databases.py
```

Set `SGCH_ENV=staging` or `SGCH_ENV=production` before running if needed. The same environment must be used when starting the server.
