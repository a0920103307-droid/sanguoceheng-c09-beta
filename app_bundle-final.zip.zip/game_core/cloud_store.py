from __future__ import annotations
import hashlib, json, sqlite3, time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional
from .savegame import migrate_save

CLOUD_SCHEMA='sgch.cloudsave'
CLOUD_SCHEMA_VERSION=1

class CloudSaveError(RuntimeError): pass
class CloudConflictError(CloudSaveError):
    def __init__(self,current_revision:int):
        super().__init__(f'雲端存檔衝突：目前版本為 {current_revision}')
        self.current_revision=current_revision

@dataclass
class CloudLoadResult:
    document: Dict[str,Any]
    revision: int
    updated_at: int
    recovered: bool=False
    source: str='cloud'

class CloudSaveStore:
    """Server-side canonical save store for closed beta.

    The game save payload keeps SAVE_VERSION=7 for B10 compatibility. C04 adds a
    versioned cloud envelope + optimistic revisions around that payload.
    """
    def __init__(self,db_path:str|Path):
        self.path=Path(db_path); self.path.parent.mkdir(parents=True,exist_ok=True); self._init()
    def _db(self):
        con=sqlite3.connect(self.path,timeout=10); con.row_factory=sqlite3.Row; return con
    def _init(self):
        with self._db() as con:
            con.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS cloud_saves(
              player_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, save_json TEXT NOT NULL,
              checksum TEXT NOT NULL, updated_at INTEGER NOT NULL, schema_version INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS cloud_backups(
              backup_id INTEGER PRIMARY KEY AUTOINCREMENT, player_id TEXT NOT NULL,
              revision INTEGER NOT NULL, save_json TEXT NOT NULL, checksum TEXT NOT NULL,
              created_at INTEGER NOT NULL, reason TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_cloud_backups_player ON cloud_backups(player_id,backup_id DESC);
            ''')
    @staticmethod
    def _encode(doc:Dict[str,Any])->tuple[str,str]:
        normalized=migrate_save(doc)
        raw=json.dumps(normalized,ensure_ascii=False,sort_keys=True,separators=(',',':'))
        return raw,hashlib.sha256(raw.encode('utf-8')).hexdigest()
    @staticmethod
    def _decode(raw:str,checksum:str)->Dict[str,Any]:
        actual=hashlib.sha256(raw.encode('utf-8')).hexdigest()
        if actual!=checksum: raise CloudSaveError('雲端存檔 checksum 不符')
        return migrate_save(json.loads(raw))
    def current_revision(self,player_id:str)->int:
        with self._db() as con:
            r=con.execute('SELECT revision FROM cloud_saves WHERE player_id=?',(player_id,)).fetchone()
        return int(r['revision']) if r else 0
    def save(self,player_id:str,doc:Dict[str,Any],*,expected_revision:Optional[int]=None,reason='sync')->int:
        raw,checksum=self._encode(doc); now=int(time.time())
        with self._db() as con:
            con.execute('BEGIN IMMEDIATE')
            old=con.execute('SELECT * FROM cloud_saves WHERE player_id=?',(player_id,)).fetchone()
            current=int(old['revision']) if old else 0
            if expected_revision is not None and int(expected_revision)!=current:
                raise CloudConflictError(current)
            if old:
                con.execute('INSERT INTO cloud_backups(player_id,revision,save_json,checksum,created_at,reason) VALUES(?,?,?,?,?,?)',
                            (player_id,current,old['save_json'],old['checksum'],now,reason))
            revision=current+1
            con.execute('INSERT OR REPLACE INTO cloud_saves(player_id,revision,save_json,checksum,updated_at,schema_version) VALUES(?,?,?,?,?,?)',
                        (player_id,revision,raw,checksum,now,CLOUD_SCHEMA_VERSION))
        return revision
    def load(self,player_id:str)->Optional[CloudLoadResult]:
        with self._db() as con:
            row=con.execute('SELECT * FROM cloud_saves WHERE player_id=?',(player_id,)).fetchone()
        if not row:return None
        try:
            return CloudLoadResult(self._decode(row['save_json'],row['checksum']),int(row['revision']),int(row['updated_at']))
        except Exception:
            recovered=self.restore_latest_valid(player_id,reason='auto_corruption_recovery')
            if recovered:return recovered
            raise
    def list_backups(self,player_id:str,limit:int=20):
        with self._db() as con:
            rows=con.execute('SELECT backup_id,revision,created_at,reason FROM cloud_backups WHERE player_id=? ORDER BY backup_id DESC LIMIT ?', (player_id,int(limit))).fetchall()
        return [dict(r) for r in rows]
    def restore(self,player_id:str,backup_id:int,*,reason='manual_restore')->CloudLoadResult:
        with self._db() as con:
            row=con.execute('SELECT * FROM cloud_backups WHERE player_id=? AND backup_id=?',(player_id,int(backup_id))).fetchone()
        if not row: raise CloudSaveError('找不到指定備份')
        doc=self._decode(row['save_json'],row['checksum'])
        revision=self.save(player_id,doc,expected_revision=self.current_revision(player_id),reason=reason)
        return CloudLoadResult(doc,revision,int(time.time()),True,'backup')
    def restore_latest_valid(self,player_id:str,*,reason='auto_recovery')->Optional[CloudLoadResult]:
        with self._db() as con:
            rows=con.execute('SELECT * FROM cloud_backups WHERE player_id=? ORDER BY backup_id DESC',(player_id,)).fetchall()
        for row in rows:
            try:
                doc=self._decode(row['save_json'],row['checksum'])
                revision=self.save(player_id,doc,expected_revision=self.current_revision(player_id),reason=reason)
                return CloudLoadResult(doc,revision,int(time.time()),True,'backup')
            except CloudConflictError: raise
            except Exception: continue
        return None
