const CACHE='sanguoceheng-c09-shell-v2';
const APP_SHELL=['/','/offline.html','/manifest.webmanifest','/assets/icons/icon-192.svg','/assets/icons/icon-512.svg'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP_SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
  const req=event.request, url=new URL(req.url);
  if(req.method!=='GET'||url.origin!==location.origin)return;
  if(url.pathname.startsWith('/api/')){
    event.respondWith(fetch(req).catch(()=>new Response(JSON.stringify({ok:false,message:'offline',offline:true}),{status:503,headers:{'Content-Type':'application/json; charset=utf-8'}})));
    return;
  }
  if(req.mode==='navigate'){
    event.respondWith(fetch(req).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put('/',copy));return res}).catch(()=>caches.match('/').then(r=>r||caches.match('/offline.html'))));
    return;
  }
  event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));return res})));
});
