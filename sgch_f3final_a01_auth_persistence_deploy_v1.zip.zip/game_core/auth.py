from __future__ import annotations
import base64, hashlib, hmac, os, secrets, sqlite3, time, uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from .account_store import AccountRecord, DuplicateAccountError, build_account_store

PBKDF2_ITERATIONS=210_000
SESSION_TTL=7*24*60*60

@dataclass(frozen=True)
class Identity:
    player_id:str
    username:str
    is_guest:bool=False

class AuthStore:
    def __init__(self, db_path: str|Path):
        self.path=Path(db_path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.accounts=build_account_store(self.path)
        self._init()
    def _db(self):
        con=sqlite3.connect(self.path,timeout=10); con.row_factory=sqlite3.Row; return con
    def _init(self):
        with self._db() as con:
            con.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, player_id TEXT NOT NULL, expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            ''')
    @staticmethod
    def normalize_username(v:str)->str:
        v=(v or '').strip().lower()
        if not (3<=len(v)<=32) or not all(c.isalnum() or c in '._-' for c in v): raise ValueError('帳號需 3–32 字，只能使用英數字、._-')
        return v
    @staticmethod
    def _password_hash(password:str)->str:
        if len(password or '')<8: raise ValueError('密碼至少 8 字')
        salt=os.urandom(16); dk=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,PBKDF2_ITERATIONS)
        return f'pbkdf2_sha256${PBKDF2_ITERATIONS}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}'
    @staticmethod
    def _verify(password:str,encoded:str)->bool:
        try:
            _,iters,salt_b64,hash_b64=encoded.split('$',3); salt=base64.b64decode(salt_b64); expected=base64.b64decode(hash_b64)
            actual=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,int(iters)); return hmac.compare_digest(actual,expected)
        except Exception:return False
    @staticmethod
    def _th(token:str)->str:return hashlib.sha256(token.encode()).hexdigest()
    def register(self,username:str,password:str)->Identity:
        username=self.normalize_username(username); ph=self._password_hash(password); pid='P-'+uuid.uuid4().hex[:16].upper(); now=int(time.time())
        try:
            self.accounts.create(AccountRecord(pid,username,ph,now))
        except DuplicateAccountError: raise ValueError('此帳號已存在')
        return Identity(pid,username,False)
    def register_with_id(self,username:str,password:str,player_id:str)->Identity:
        username=self.normalize_username(username); ph=self._password_hash(password); pid=str(player_id or '').strip()
        if not pid.startswith('P-') or len(pid)>40: raise ValueError('恢復代碼中的玩家 ID 無效')
        now=int(time.time())
        try:
            self.accounts.create(AccountRecord(pid,username,ph,now))
        except DuplicateAccountError: raise ValueError('此帳號已存在')
        return Identity(pid,username,False)
    def authenticate(self,username:str,password:str)->Optional[Identity]:
        try: username=self.normalize_username(username)
        except ValueError:return None
        r=self.accounts.get_by_username(username)
        if not r or not self._verify(password,r.password_hash):return None
        return Identity(r.player_id,r.username,False)
    def create_session(self,identity:Identity)->str:
        if identity.is_guest: raise ValueError('guest session is managed separately')
        token=secrets.token_urlsafe(32); now=int(time.time())
        with self._db() as con:
            con.execute('DELETE FROM sessions WHERE expires_at<=?',(now,)); con.execute('INSERT INTO sessions VALUES(?,?,?,?)',(self._th(token),identity.player_id,now+SESSION_TTL,now))
        return token
    def identity_for_token(self,token:str|None)->Optional[Identity]:
        if not token:return None
        now=int(time.time())
        with self._db() as con:
            r=con.execute('SELECT player_id,expires_at FROM sessions WHERE token_hash=?',(self._th(token),)).fetchone()
            if not r:return None
            if r['expires_at']<=now: con.execute('DELETE FROM sessions WHERE token_hash=?',(self._th(token),)); return None
            account=self.accounts.get_by_player_id(r['player_id'])
            if not account: return None
            return Identity(account.player_id,account.username,False)
    def revoke(self,token:str|None):
        if not token:return
        with self._db() as con: con.execute('DELETE FROM sessions WHERE token_hash=?',(self._th(token),))
    def legacy_claimed_by(self)->Optional[str]:
        with self._db() as con:r=con.execute("SELECT value FROM meta WHERE key='legacy_save_claimed_by'").fetchone(); return r['value'] if r else None
    def mark_legacy_claimed(self,player_id:str):
        with self._db() as con: con.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('legacy_save_claimed_by',?)",(player_id,))
