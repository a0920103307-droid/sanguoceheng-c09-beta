from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import json, random
from pathlib import Path

BASE = Path(__file__).resolve().parent
PARAMS = json.loads((BASE / "battle_params.json").read_text(encoding="utf-8"))["parameters"]

def pv(name):
    return PARAMS[name]["value"]

@dataclass
class Card:
    card_id: str
    name: str
    kind: str = "GENERAL"   # GENERAL / SOLDIER (grid01 only)
    attack: int = 1
    max_hp: int = 1
    hp: Optional[int] = None
    effects: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self):
        if self.hp is None:
            self.hp = self.max_hp

@dataclass
class PlayerState:
    name: str
    deck: List[Card]
    hand: List[Card] = field(default_factory=list)
    board: List[Optional[Card]] = field(default_factory=lambda: [None] * int(pv("board_slots")))
    retreat: List[Card] = field(default_factory=list)
    gate_hp: int = field(default_factory=lambda: int(pv("gate_hp")))
    fire: int = field(default_factory=lambda: int(pv("initial_fire")))
    ever_deployed_elimination_target: bool = False

class Battle:
    def __init__(self, p1: PlayerState, p2: PlayerState, first_player: int = 0, seed: int = 1):
        self.players = [p1, p2]
        self.active = first_player
        self.turn = 0
        self.winner: Optional[int] = None
        self.win_reason: Optional[str] = None
        self.log: List[str] = []
        self.rng = random.Random(seed)

    def emit(self, event: str, **ctx):
        # Grid01 minimal event bus: generic effects, no character-name hardcoding.
        self.log.append(f"EVENT {event} {ctx if ctx else ''}".rstrip())
        for pi, p in enumerate(self.players):
            for card in [c for c in p.board if c]:
                for eff in card.effects:
                    if eff.get("trigger") == event:
                        self.resolve_effect(pi, card, eff, ctx)

    def resolve_effect(self, owner: int, source: Card, eff: Dict[str, Any], ctx: Dict[str, Any]):
        et = eff.get("type")
        if et == "DAMAGE_OPPOSITE_ON_DEPLOY" and ctx.get("card") is source:
            slot = self.players[owner].board.index(source)
            target = self.players[1-owner].board[slot]
            if target:
                self.damage_card(owner, source, 1-owner, target, int(eff.get("amount", 1)))
        elif et == "ADD_FIRE":
            self.add_fire(owner, int(eff.get("amount", 1)))

    def opening(self, shuffle: bool = False):
        for p in self.players:
            if shuffle:
                self.rng.shuffle(p.deck)
            self.draw(p, int(pv("opening_hand")))
        self.emit("BATTLE_START")
        self.check_victory()

    def draw(self, p: PlayerState, n: int):
        drawn = 0
        for _ in range(n):
            if len(p.hand) >= int(pv("hand_limit")):
                break
            if not p.deck:
                break
            c = p.deck.pop(0)
            p.hand.append(c)
            drawn += 1
            self.emit("ON_DRAW", player=p.name, card=c.name)
        return drawn

    def add_fire(self, player_idx: int, n: int):
        p = self.players[player_idx]
        old = p.fire
        p.fire = min(int(pv("fire_cap")), p.fire + n)
        self.emit("FIRE_CHANGED", player=p.name, old=old, new=p.fire)

    def start_turn(self):
        if self.winner is not None:
            return
        self.turn += 1
        p = self.players[self.active]
        self.emit("TURN_START", player=p.name, turn=self.turn)
        self.add_fire(self.active, int(pv("fire_per_turn")))
        self.draw(p, int(pv("draw_per_turn")))

    def play(self, hand_index: int, slot: int):
        p = self.players[self.active]
        if self.winner is not None:
            raise ValueError("battle already ended")
        if not (0 <= hand_index < len(p.hand)):
            raise ValueError("invalid hand index")
        if not (0 <= slot < int(pv("board_slots"))):
            raise ValueError("invalid slot")
        if p.board[slot] is not None:
            raise ValueError("slot occupied")
        if p.fire < int(pv("play_fire_cost")):
            raise ValueError("not enough fire")
        card = p.hand[hand_index]
        if card.kind not in ("GENERAL", "SOLDIER"):
            raise ValueError("card cannot occupy battle slot in grid01")
        p.fire -= int(pv("play_fire_cost"))
        self.emit("FIRE_CHANGED", player=p.name, new=p.fire)
        p.hand.pop(hand_index)
        p.board[slot] = card
        if card.kind == pv("elimination_target"):
            p.ever_deployed_elimination_target = True
        self.emit("ON_DEPLOY", player=p.name, card=card)
        self.state_based_defeat()
        self.check_victory()

    def damage_card(self, src_owner: int, src: Card, dst_owner: int, dst: Card, amount: int):
        self.emit("BEFORE_DAMAGE", source=src.name, target=dst.name, amount=amount)
        dst.hp -= amount
        self.emit("AFTER_DAMAGE", source=src.name, target=dst.name, amount=amount, hp=dst.hp)
        self.state_based_defeat()
        self.check_victory()

    def damage_gate(self, attacker: int, amount: int):
        defender = 1 - attacker
        self.players[defender].gate_hp -= amount
        self.emit("GATE_DAMAGED", attacker=self.players[attacker].name,
                  defender=self.players[defender].name, amount=amount,
                  gate_hp=self.players[defender].gate_hp)
        self.check_victory()

    def state_based_defeat(self):
        for pi, p in enumerate(self.players):
            for i, c in enumerate(list(p.board)):
                if c is not None and c.hp <= 0:
                    p.board[i] = None
                    p.retreat.append(c)
                    self.emit("ON_DEFEAT", player=p.name, card=c.name, slot=i)

    def combat(self):
        if self.winner is not None:
            return
        atk_idx = self.active
        def_idx = 1 - atk_idx
        self.emit("COMBAT_START", player=self.players[atk_idx].name)
        for slot in range(int(pv("board_slots"))):
            if self.winner is not None:
                break
            attacker = self.players[atk_idx].board[slot]
            if attacker is None or attacker.hp <= 0:
                continue
            self.emit("BEFORE_ATTACK", player=self.players[atk_idx].name, card=attacker.name, slot=slot)
            defender = self.players[def_idx].board[slot]
            if defender is not None:
                self.emit("ON_ATTACK", source=attacker.name, target=defender.name, slot=slot)
                self.damage_card(atk_idx, attacker, def_idx, defender, attacker.attack)
            elif bool(pv("empty_opposite_attacks_gate")):
                self.emit("ON_ATTACK", source=attacker.name, target="GATE", slot=slot)
                self.damage_gate(atk_idx, attacker.attack)
        self.emit("TURN_END", player=self.players[atk_idx].name)
        self.check_victory()
        if self.winner is None:
            self.active = def_idx

    def check_victory(self):
        if self.winner is not None:
            return self.winner
        # gate victory has priority
        for i, p in enumerate(self.players):
            if p.gate_hp <= 0:
                self.winner = 1 - i
                self.win_reason = "GATE_DESTROYED"
                return self.winner
        target = pv("elimination_target")
        for i, p in enumerate(self.players):
            if p.ever_deployed_elimination_target:
                alive = any(c is not None and c.kind == target for c in p.board)
                if not alive:
                    self.winner = 1 - i
                    self.win_reason = "ELIMINATION"
                    return self.winner
        return None


def demo_deck(prefix: str, n: int = 20):
    return [Card(f"{prefix}{i:02}", f"{prefix}將{i:02}", "GENERAL", attack=2, max_hp=3) for i in range(1, n+1)]

if __name__ == "__main__":
    a = PlayerState("玩家", demo_deck("P"))
    b = PlayerState("敵方", demo_deck("E"))
    game = Battle(a, b, first_player=0, seed=7)
    game.opening(shuffle=False)
    # Deterministic minimum-playable AI loop. It is only a harness for Grid01 verification.
    while game.winner is None and game.turn < 50:
        game.start_turn()
        p = game.players[game.active]
        empty = next((i for i, c in enumerate(p.board) if c is None), None)
        if p.hand and p.fire >= int(pv("play_fire_cost")) and empty is not None:
            game.play(0, empty)
        game.combat()
    print("turns=", game.turn)
    print("winner=", None if game.winner is None else game.players[game.winner].name, "reason=", game.win_reason)
    print("player_gate=", a.gate_hp, "enemy_gate=", b.gate_hp)
    print("retreat=", [c.name for c in a.retreat], [c.name for c in b.retreat])
