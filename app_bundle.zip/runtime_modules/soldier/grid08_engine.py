from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Optional
import importlib.util, json, sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
CATALOG = json.loads((BASE / "soldier_catalog_v0.8.json").read_text(encoding="utf-8"))
TEMP = json.loads((BASE / "temporary_soldier_params.json").read_text(encoding="utf-8"))["parameters"]
ROLE_MAP = {r["role_code"]: r for r in CATALOG["roles"]}

def tp(name: str): return TEMP[name]["value"]

def _load_grid07():
    path = ROOT / "progression" / "grid07_engine.py"
    spec = importlib.util.spec_from_file_location("grid07_engine_for_grid08", path)
    if spec is None or spec.loader is None: raise ImportError("cannot load grid07 engine")
    mod = importlib.util.module_from_spec(spec); sys.modules[spec.name] = mod; spec.loader.exec_module(mod); return mod

g7 = _load_grid07()
Card = g7.Card
PlayerState = g7.PlayerState
_state = g7._state


def soldier_state(card: Card) -> Dict[str, Any]:
    if card.kind != "SOLDIER": raise ValueError("not a SOLDIER card")
    st = _state(card)
    s = st.setdefault("soldier", {})
    s.setdefault("level", 1)
    s.setdefault("skill_level", int(s["level"]))
    s.setdefault("cost_fame", int(CATALOG["system_rules"]["fixed_cost_fame"]["value"]))
    s.setdefault("role_code", getattr(card, "soldier_role_code", None))
    s.setdefault("official_card_name", getattr(card, "official_card_name", None))
    s.setdefault("is_temporary_runtime", True)
    return s


def soldier_definition(role_code: str) -> Dict[str, Any]:
    rc = str(role_code).upper()
    if rc not in ROLE_MAP: raise KeyError(f"unknown role_code {role_code}")
    return ROLE_MAP[rc]


def make_soldier(role_code: str, *, card_id: Optional[str]=None) -> Card:
    d = soldier_definition(role_code); rc=d["role_code"]
    if rc.startswith("UNKNOWN_"):
        raise ValueError("unknown soldier roles are evidence placeholders, not playable named cards")
    attack = int(tp("runtime_attack_by_role").get(rc, 1))
    hp = int(tp("runtime_hp_by_role").get(rc, 1))
    official = d.get("official_card_name")
    # Do not invent an official card name when only a role label is known.
    display = official if official else f"[職能]{d['role_label']}"
    c = Card(card_id or f"SOLDIER_ROLE_{rc}", display, "SOLDIER", attack=attack, max_hp=hp, effects=[])
    c.soldier_role_code = rc
    c.official_card_name = official
    c.cost_fame = int(CATALOG["system_rules"]["fixed_cost_fame"]["value"])
    soldier_state(c)
    return c


class SoldierBattle(g7.ProgressionBattle):
    """Grid08 soldier layer.

    Confirmed evidence is metadata/interaction focused. Unknown initial stats, growth and role-specific
    numeric abilities remain external C parameters. Role labels are never promoted to official card names.
    """
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.soldier_log=[]

    def upgrade_soldier(self, card: Card, inventory: Dict[str,int]) -> Dict[str,Any]:
        s=soldier_state(card); level=int(s["level"]); cap=int(tp("max_soldier_level"))
        if level >= cap: raise ValueError("soldier level cap reached (temporary cap)")
        needs={"兵符":int(tp("soldier_symbol_cost_per_level")), "銀幣":int(tp("silver_cost_per_level"))}
        for k,v in needs.items():
            if int(inventory.get(k,0)) < v: raise ValueError(f"insufficient {k}")
        for k,v in needs.items(): inventory[k]=int(inventory.get(k,0))-v
        s["level"]=level+1; s["skill_level"]=s["level"]
        ag=int(tp("attack_growth_per_level")); hg=int(tp("hp_growth_per_level"))
        if ag: card.attack += ag
        if hg: card.max_hp += hg; card.hp += hg
        r={"action":"SOLDIER_UPGRADE","card":card.name,"role_code":s["role_code"],"from_level":level,"to_level":s["level"],"skill_level":s["skill_level"],"consumed":needs,"numeric_confidence":"C"}
        self.soldier_log.append(r); self.log.append(f"GRID08 SOLDIER {r}"); return r

    def emit(self, event: str, **ctx):
        super().emit(event, **ctx)
        # Siege is confirmed as a role/card direction, but exact bonus is unknown. Keep bonus C-configurable.
        if event == "ON_ATTACK" and ctx.get("target") == "GATE":
            source_name = ctx.get("source")
            for oi,p in enumerate(self.players):
                for c in p.board:
                    if c is not None and c.name == source_name and c.kind == "SOLDIER":
                        s=soldier_state(c)
                        if s.get("role_code") == "SIEGE":
                            bonus=int(tp("siege_extra_gate_damage"))
                            if bonus>0:
                                self.damage_gate(oi, bonus)
                                self.soldier_log.append({"action":"SIEGE_BONUS","card":c.name,"amount":bonus,"numeric_confidence":"C"})
                            return
