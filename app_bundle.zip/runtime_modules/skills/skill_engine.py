from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
import importlib.util
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent


def _load_grid01():
    path = ROOT / "battle" / "grid01_engine.py"
    spec = importlib.util.spec_from_file_location("grid01_engine_for_grid03", path)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load grid01 engine")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


grid01 = _load_grid01()
Card = grid01.Card
PlayerState = grid01.PlayerState
pv = grid01.pv

STATUS_ALIASES = {"SILENCE", "SEAL", "PETRIFY", "CONFUSION", "TAUNT", "STEALTH", "LOCK", "COUNTER", "IMMUNITY", "DIVINE_PROTECTION"}


def _state(card: Card) -> Dict[str, Any]:
    if not hasattr(card, "skill_state"):
        card.skill_state = {"statuses": {}, "horse": None, "base_attack": card.attack, "base_max_hp": card.max_hp}
    return card.skill_state


def has_status(card: Card, name: str) -> bool:
    return name in _state(card)["statuses"]


def status_data(card: Card, name: str) -> Dict[str, Any]:
    return _state(card)["statuses"].get(name, {})


@dataclass
class EffectResult:
    effect_type: str
    applied: bool
    detail: Dict[str, Any] = field(default_factory=dict)


class SkillBattle(grid01.Battle):
    """Grid03 generic skill/status layer on top of Grid01 battle.

    No card name is hard-coded. Every effect is a data dict. Exact original timing/stacking
    remains replaceable because status/effect semantics live here rather than in card data.
    """

    def _iter_board(self, owner: Optional[int] = None) -> Iterable[Tuple[int, int, Card]]:
        owners = range(2) if owner is None else [owner]
        for oi in owners:
            for slot, card in enumerate(self.players[oi].board):
                if card is not None:
                    yield oi, slot, card

    def _find_card(self, card: Card) -> Optional[Tuple[int, int]]:
        for oi, slot, c in self._iter_board():
            if c is card:
                return oi, slot
        return None

    def can_resolve_skill(self, card: Card) -> bool:
        return not has_status(card, "SILENCE") and not has_status(card, "SEAL")

    def emit(self, event: str, **ctx):
        # Preserve Grid01 logging, but route triggered effects through Grid03 resolver.
        self.log.append(f"EVENT {event} {ctx if ctx else ''}".rstrip())
        for oi, _, card in list(self._iter_board()):
            if not self.can_resolve_skill(card):
                continue
            for eff in list(card.effects):
                if eff.get("trigger") == event:
                    self.apply_effect(oi, card, eff, context=ctx)

    def _is_immune(self, target: Card, effect_type: str) -> bool:
        if not has_status(target, "IMMUNITY"):
            return False
        blocks = status_data(target, "IMMUNITY").get("blocks", ["STATUS"])
        return "ALL" in blocks or effect_type in blocks or (effect_type in STATUS_ALIASES and "STATUS" in blocks)

    def _apply_status(self, target: Card, name: str, effect: Dict[str, Any]) -> EffectResult:
        if self._is_immune(target, name):
            return EffectResult(name, False, {"reason": "IMMUNE"})
        duration = int(effect.get("duration", 1))
        data = {k: deepcopy(v) for k, v in effect.items() if k not in {"type", "target"}}
        data["duration"] = duration
        _state(target)["statuses"][name] = data
        self.log.append(f"SKILL STATUS {name} target={target.name} duration={duration}")
        return EffectResult(name, True, {"target": target.name, "duration": duration})

    def _visible(self, target: Card, effect: Dict[str, Any]) -> bool:
        return not has_status(target, "STEALTH") or bool(effect.get("reveals", False))

    def apply_effect(self, owner: int, source: Optional[Card], effect: Dict[str, Any], *,
                     target_owner: Optional[int] = None, target: Optional[Card] = None,
                     target_slot: Optional[int] = None, context: Optional[Dict[str, Any]] = None) -> EffectResult:
        et = str(effect.get("type", "")).upper()
        context = context or {}
        if et in STATUS_ALIASES:
            if target is None:
                return EffectResult(et, False, {"reason": "NO_TARGET"})
            return self._apply_status(target, et, effect)

        if et == "DAMAGE":
            if target is None or not self._visible(target, effect) or self._is_immune(target, et):
                return EffectResult(et, False, {"reason": "INVALID_TARGET"})
            loc = self._find_card(target)
            if loc is None:
                return EffectResult(et, False, {"reason": "NOT_ON_BOARD"})
            amount = max(0, int(effect.get("amount", 0)))
            self.damage_card(owner, source or target, loc[0], target, amount)
            return EffectResult(et, True, {"amount": amount, "target": target.name})

        if et == "HEAL":
            if target is None:
                return EffectResult(et, False, {"reason": "NO_TARGET"})
            amount = max(0, int(effect.get("amount", 0)))
            old = target.hp
            target.hp = min(target.max_hp, target.hp + amount)
            self.log.append(f"SKILL HEAL target={target.name} amount={target.hp-old}")
            return EffectResult(et, True, {"amount": target.hp-old})

        if et == "MOD_ATTACK":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            delta = int(effect.get("amount", 0)); target.attack += delta
            self.log.append(f"SKILL MOD_ATTACK target={target.name} delta={delta}")
            return EffectResult(et, True, {"delta":delta})

        if et == "MOD_HP":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            delta = int(effect.get("amount", 0)); target.max_hp = max(1, target.max_hp + delta)
            target.hp = max(1, min(target.max_hp, target.hp + delta))
            self.log.append(f"SKILL MOD_HP target={target.name} delta={delta}")
            return EffectResult(et, True, {"delta":delta})

        if et == "REVEAL":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            existed = _state(target)["statuses"].pop("STEALTH", None) is not None
            return EffectResult(et, existed, {"target":target.name})

        if et == "CLEAR_STATUS":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            name = effect.get("status", "ALL")
            if name == "ALL":
                n = len(_state(target)["statuses"]); _state(target)["statuses"].clear()
            else:
                n = 1 if _state(target)["statuses"].pop(str(name), None) is not None else 0
            return EffectResult(et, n > 0, {"cleared":n})

        if et == "DRAW":
            n = int(effect.get("amount", 1)); drawn = self.draw(self.players[owner], n)
            return EffectResult(et, drawn > 0, {"drawn":drawn})

        if et == "ADD_FIRE":
            old = self.players[owner].fire; self.add_fire(owner, int(effect.get("amount",1)))
            return EffectResult(et, self.players[owner].fire != old, {"old":old,"new":self.players[owner].fire})

        if et == "DAMAGE_GATE":
            amount = max(0, int(effect.get("amount",0))); self.damage_gate(owner, amount)
            return EffectResult(et, True, {"amount":amount})

        if et == "SPLASH":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            loc = self._find_card(target)
            if loc is None: return EffectResult(et, False, {"reason":"NOT_ON_BOARD"})
            amount = max(0, int(effect.get("amount",0))); hits=[]
            for s in (loc[1]-1, loc[1]+1):
                if 0 <= s < len(self.players[loc[0]].board):
                    c = self.players[loc[0]].board[s]
                    if c is not None and self._visible(c, effect):
                        self.damage_card(owner, source or target, loc[0], c, amount); hits.append(c.name)
            return EffectResult(et, bool(hits), {"targets":hits})

        if et == "PIERCE":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            base = self.apply_effect(owner, source, {"type":"DAMAGE","amount":effect.get("amount",0),"reveals":effect.get("reveals",False)}, target=target)
            spill = max(0, int(effect.get("gate_amount",0)))
            if spill: self.damage_gate(owner, spill)
            return EffectResult(et, base.applied or spill>0, {"card_damage":effect.get("amount",0),"gate_damage":spill})

        if et == "RETURN_TO_DECK":
            if target is None or has_status(target,"LOCK"): return EffectResult(et, False, {"reason":"LOCKED_OR_NO_TARGET"})
            loc = self._find_card(target)
            if loc is None: return EffectResult(et, False, {"reason":"NOT_ON_BOARD"})
            self.players[loc[0]].board[loc[1]] = None
            target.hp = target.max_hp; self.players[loc[0]].deck.append(target)
            return EffectResult(et, True, {"owner":loc[0]})

        if et == "COPY_CARD":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            p = self.players[owner]
            if len(p.hand) >= int(pv("hand_limit")): return EffectResult(et, False, {"reason":"HAND_FULL"})
            cp = deepcopy(target); cp.card_id = f"{target.card_id}#copy{len(p.hand)+1}"; p.hand.append(cp)
            return EffectResult(et, True, {"card":cp.name})

        if et == "REVIVE":
            p = self.players[owner]
            if not p.retreat: return EffectResult(et, False, {"reason":"EMPTY_RETREAT"})
            slot = target_slot if target_slot is not None else next((i for i,c in enumerate(p.board) if c is None), None)
            if slot is None or p.board[slot] is not None: return EffectResult(et, False, {"reason":"NO_SLOT"})
            idx = int(effect.get("retreat_index", -1)); card = p.retreat.pop(idx)
            ratio = float(effect.get("hp_ratio",1.0)); card.hp = max(1, min(card.max_hp, int(round(card.max_hp*ratio))))
            p.board[slot] = card
            return EffectResult(et, True, {"card":card.name,"slot":slot,"hp":card.hp})

        if et == "SUMMON":
            p=self.players[owner]
            slot = target_slot if target_slot is not None else next((i for i,c in enumerate(p.board) if c is None), None)
            if slot is None or p.board[slot] is not None: return EffectResult(et, False, {"reason":"NO_SLOT"})
            token=effect.get("token",{}); c=Card(str(token.get("card_id","TOKEN")),str(token.get("name","召喚物")),str(token.get("kind","SOLDIER")),attack=int(token.get("attack",1)),max_hp=int(token.get("hp",1)))
            p.board[slot]=c
            return EffectResult(et, True, {"card":c.name,"slot":slot})

        if et == "STEAL_HORSE":
            if source is None or target is None: return EffectResult(et, False, {"reason":"NO_SOURCE_OR_TARGET"})
            hs=_state(target).get("horse")
            if hs is None: return EffectResult(et, False, {"reason":"NO_HORSE"})
            _state(source)["horse"]=hs; _state(target)["horse"]=None
            return EffectResult(et, True, {"horse":hs})

        if et == "DESTROY_HORSE":
            if target is None: return EffectResult(et, False, {"reason":"NO_TARGET"})
            hs=_state(target).get("horse"); _state(target)["horse"]=None
            return EffectResult(et, hs is not None, {"horse":hs})

        if et == "COMMAND":
            results=[]
            for child in effect.get("effects",[]):
                results.append(self.apply_effect(owner, source, child, target_owner=target_owner, target=target, target_slot=target_slot, context=context))
            return EffectResult(et, any(r.applied for r in results), {"results":[r.__dict__ for r in results]})

        return EffectResult(et or "UNKNOWN", False, {"reason":"UNSUPPORTED"})

    def damage_card(self, src_owner: int, src: Card, dst_owner: int, dst: Card, amount: int):
        amount = max(0, int(amount))
        self.emit("BEFORE_DAMAGE", source=src.name, target=dst.name, amount=amount)
        dst.hp -= amount
        self.emit("AFTER_DAMAGE", source=src.name, target=dst.name, amount=amount, hp=dst.hp)
        # Counter is generic fixed retaliation and is consumed only if source remains on board.
        if amount > 0 and has_status(dst,"COUNTER"):
            retaliation = max(0, int(status_data(dst,"COUNTER").get("amount",1)))
            src_loc = self._find_card(src)
            if src_loc is not None and retaliation:
                src.hp -= retaliation
                self.log.append(f"SKILL COUNTER source={dst.name} target={src.name} amount={retaliation}")
        self.state_based_defeat(); self.check_victory()

    def state_based_defeat(self):
        for oi,p in enumerate(self.players):
            for slot,c in enumerate(list(p.board)):
                if c is None or c.hp > 0: continue
                if has_status(c,"DIVINE_PROTECTION"):
                    _state(c)["statuses"].pop("DIVINE_PROTECTION",None); c.hp=1
                    self.log.append(f"SKILL DIVINE_PROTECTION target={c.name}")
                    continue
                p.board[slot]=None; p.retreat.append(c); self.emit("ON_DEFEAT",player=p.name,card=c.name,slot=slot)

    def _combat_target(self, def_idx: int, slot: int) -> Optional[Card]:
        # Generic taunt rule: first visible TAUNT on defending board; else opposite card.
        taunts=[(s,c) for _,s,c in self._iter_board(def_idx) if has_status(c,"TAUNT") and not has_status(c,"STEALTH")]
        if taunts: return sorted(taunts,key=lambda x:x[0])[0][1]
        c=self.players[def_idx].board[slot]
        if c is not None and not has_status(c,"STEALTH"): return c
        return None

    def combat(self):
        if self.winner is not None: return
        atk_idx=self.active; def_idx=1-atk_idx; self.emit("COMBAT_START",player=self.players[atk_idx].name)
        for slot in range(int(pv("board_slots"))):
            if self.winner is not None: break
            attacker=self.players[atk_idx].board[slot]
            if attacker is None or attacker.hp<=0 or has_status(attacker,"PETRIFY"): continue
            self.emit("BEFORE_ATTACK",player=self.players[atk_idx].name,card=attacker.name,slot=slot)
            defender=self._combat_target(def_idx,slot)
            if defender is not None:
                self.emit("ON_ATTACK",source=attacker.name,target=defender.name,slot=slot)
                self.damage_card(atk_idx,attacker,def_idx,defender,attacker.attack)
            elif bool(pv("empty_opposite_attacks_gate")):
                self.emit("ON_ATTACK",source=attacker.name,target="GATE",slot=slot); self.damage_gate(atk_idx,attacker.attack)
        self.emit("TURN_END",player=self.players[atk_idx].name); self.tick_statuses(atk_idx); self.check_victory()
        if self.winner is None: self.active=def_idx

    def tick_statuses(self, owner: int):
        for _,_,card in list(self._iter_board(owner)):
            statuses=_state(card)["statuses"]
            for name in list(statuses):
                if "duration" not in statuses[name]: continue
                statuses[name]["duration"] -= 1
                if statuses[name]["duration"] <= 0: statuses.pop(name,None)
