from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .battle_flow import BattleLoadout
from .support_runtime import public_catalog, command_target_mode
from .ai_runtime import BattleAI

@dataclass
class UIActionResult:
    ok: bool
    state: Dict[str, Any]
    message: str = ""

class BattleUIController:
    """A06 browser/UI adapter. Combat math remains in frozen Grid01-08 engines."""
    def __init__(self, session, *, loadouts: Optional[List[BattleLoadout]] = None):
        self.session=session; self.battle=session.battle
        self.loadouts=loadouts or [BattleLoadout(), BattleLoadout()]
        self.support_used=[dict(book=[],command=[],horse=[],equipment=[]) for _ in range(2)]
        self.started=False; self.turn_ready=False; self.ui_log=[]; self.last_legacy_log_index=0
        self.session.metadata['ui_version']='A06'
        self.ai=BattleAI(self.battle,owner=1)
        self.catalog=public_catalog()

    def _log(self,text): self.ui_log=(self.ui_log+[str(text)])[-240:]
    def _touch(self,reason,**detail): self.session.touch(reason,**detail)
    def _sync_legacy_log(self):
        for line in self.battle.log[self.last_legacy_log_index:]: self._log(line)
        self.last_legacy_log_index=len(self.battle.log)

    def _card_view(self,card):
        if card is None: return None
        st=getattr(card,'skill_state',{}) or {}; horse=st.get('horse'); eq=st.get('equipment',{}) if isinstance(st,dict) else {}
        equipment=[]
        if isinstance(eq,dict):
            for slot in ('WEAPON','ARMOR'):
                item=eq.get(slot)
                if item: equipment.append({'slot':slot,'name':item.get('name'),'star':item.get('star'),'fate_active':bool(item.get('fate_active')),'refined_skill':item.get('refined_skill')})
        skills=[]
        for sk in getattr(card,'a04_skills',[]) or []:
            skills.append({'name':sk.get('name') or '技能','trigger':'/'.join(sorted({x.get('trigger','') for x in sk.get('compiled',[])})),'type':'/'.join(sorted({x.get('effect',{}).get('type','') for x in sk.get('compiled',[])})),'layer':sk.get('runtime_layer'),'original_text':sk.get('original_text')})
        statuses=[str(x) for x in (st.get('statuses',{}) if isinstance(st,dict) else {}).keys()]
        if horse: statuses.append(f"戰馬：{horse.get('name')}")
        for item in equipment: statuses.append(f"{item['slot']}：{item['name']}" + ('｜專屬緣分' if item['fate_active'] else ''))
        return {'card_id':card.card_id,'name':card.name,'kind':card.kind,'growth':getattr(card,'a08_growth',None),'faction':(getattr(card,'a04_meta',{}) or {}).get('faction'),'quality':(getattr(card,'a04_meta',{}) or {}).get('quality'),'attack':int(card.attack),'hp':int(card.hp),'max_hp':int(card.max_hp),'skills':skills,'statuses':statuses,'horse':None if not horse else {'name':horse.get('name'),'level':horse.get('level'),'skill':horse.get('skill_name'),'binding':horse.get('binding')},'equipment':equipment}

    def _card_at(self, owner:int, slot:int):
        slot=int(slot)
        if not 0<=slot<len(self.battle.players[owner].board): raise ValueError('目標場位超出範圍')
        c=self.battle.players[owner].board[slot]
        if c is None: raise ValueError('目標場位沒有卡牌')
        return c
    def _first_general(self,owner): return next((c for c in self.battle.players[owner].board if c and c.kind=='GENERAL'),None)
    def _empty_slot(self,owner): return next((i for i,c in enumerate(self.battle.players[owner].board) if c is None),None)

    def _start_active_turn(self):
        if self.battle.winner is not None:return
        self.battle.start_turn(); self.turn_ready=True; self._touch('a05_turn_start',owner=self.battle.active,turn=self.battle.turn); self._sync_legacy_log()
        if self.battle.active==0:self._log(f"玩家回合 {self.battle.turn}：可出牌或使用支援系統。")

    def start_battle(self,shuffle=False):
        if self.started:return UIActionResult(True,self.state(),'戰鬥已開始')
        self.battle.opening(shuffle=bool(shuffle)); self.started=True; self._touch('a05_battle_opening'); self._sync_legacy_log(); self._log('戰鬥開始。'); self._start_active_turn()
        if self.battle.active==1 and self.battle.winner is None:self._run_ai_until_player()
        return UIActionResult(True,self.state(),'戰鬥開始')

    def play_card(self,hand_index,slot):
        try:
            if not self.started: raise ValueError('請先開始戰鬥')
            if self.battle.winner is not None: raise ValueError('戰鬥已結束')
            if self.battle.active!=0 or not self.turn_ready: raise ValueError('現在不是玩家出牌階段')
            card=self.battle.players[0].hand[int(hand_index)]; name=card.name; self.battle.play(int(hand_index),int(slot)); self._touch('a05_player_play',hand_index=int(hand_index),slot=int(slot),card=name); self._sync_legacy_log(); self._log(f'玩家部署 {name} → 位置 {int(slot)+1}。'); return UIActionResult(True,self.state(),f'已部署 {name}')
        except Exception as exc:self._log(f'操作失敗：{exc}'); return UIActionResult(False,self.state(),str(exc))

    def use_book(self,name):
        try:
            self._ensure_player_phase(); r=self.battle.use_book(0,str(name));
            if not r.get('applied'): raise ValueError('目前戰況不符合這本兵書的生效條件')
            self.support_used[0]['book'].append(str(name)); self._touch('a05_book',name=name,result=r); self._sync_legacy_log(); self._log(f'玩家使用兵書 {name}。'); return UIActionResult(True,self.state(),f'已使用兵書 {name}')
        except Exception as exc:self._log(f'操作失敗：{exc}'); return UIActionResult(False,self.state(),str(exc))

    def use_command(self,name,target_slot=None):
        try:
            self._ensure_player_phase(); mode=command_target_mode(str(name)); target=None
            if mode=='ALLY': target=self._card_at(0,int(target_slot))
            elif mode=='ENEMY': target=self._card_at(1,int(target_slot))
            r=self.battle.use_command(0,str(name),target=target)
            if not r.get('applied'): raise ValueError('軍令目前無法生效')
            self.support_used[0]['command'].append(str(name)); self._touch('a05_command',name=name,target=None if target is None else target.name,result=r); self._sync_legacy_log(); self._log(f'玩家使用軍令 {name}。'); return UIActionResult(True,self.state(),f'已使用軍令 {name}')
        except Exception as exc:self._log(f'操作失敗：{exc}'); return UIActionResult(False,self.state(),str(exc))

    def equip_horse(self,name,target_slot,level=1):
        try:
            self._ensure_player_phase(); target=self._card_at(0,int(target_slot)); r=self.battle.equip_horse(0,target,str(name),level=int(level)); self.support_used[0]['horse'].append(str(name)); self._touch('a05_horse_equip',name=name,target=target.name,level=int(level)); self._sync_legacy_log(); self._log(f'玩家替 {target.name} 裝備戰馬 {name}。'); return UIActionResult(True,self.state(),f'已裝備 {name}')
        except Exception as exc:self._log(f'操作失敗：{exc}'); return UIActionResult(False,self.state(),str(exc))

    def horse_mutation(self,action,source_slot,target_slot):
        try:
            self._ensure_player_phase(); source=self._card_at(0,int(source_slot)); target=self._card_at(1,int(target_slot)); et={'steal':'STEAL_HORSE','destroy':'DESTROY_HORSE'}.get(str(action).lower())
            if not et: raise ValueError('未知戰馬操作')
            r=self.battle.apply_effect(0,source,{'type':et},target=target)
            if not r.applied: raise ValueError(f'戰馬操作未生效：{r.detail}')
            self._touch('a05_horse_mutation',action=action,source=source.name,target=target.name); self._sync_legacy_log(); self._log(f'{source.name} 對 {target.name} 執行戰馬{action}。'); return UIActionResult(True,self.state(),'戰馬操作成功')
        except Exception as exc:self._log(f'操作失敗：{exc}'); return UIActionResult(False,self.state(),str(exc))

    def equip_equipment(self,name,target_slot,star=1,refined_skill=None):
        try:
            self._ensure_player_phase(); target=self._card_at(0,int(target_slot)); skills=[x.get('name') for x in getattr(target,'a04_skills',[]) if x.get('name')]
            self.battle.declare_skills(target,skills)
            r=self.battle.equip_equipment(0,target,str(name),star=int(star),refine_pool=skills)
            if refined_skill:
                self.battle.refine_equipment(target,r['slot'],str(refined_skill))
            self.support_used[0]['equipment'].append(str(name)); self._touch('a05_equipment',name=name,target=target.name,star=int(star),fate_active=r.get('fate_active')); self._sync_legacy_log(); self._log(f'玩家替 {target.name} 裝備 {name}' + ('，專屬緣分生效。' if r.get('fate_active') else '。')); return UIActionResult(True,self.state(),f'已裝備 {name}')
        except Exception as exc:self._log(f'操作失敗：{exc}'); return UIActionResult(False,self.state(),str(exc))

    def _ensure_player_phase(self):
        if not self.started or self.battle.winner is not None: raise ValueError('目前不能使用支援系統')
        if self.battle.active!=0 or not self.turn_ready: raise ValueError('只能在玩家出牌階段使用')

    # A03 compatibility: use configured defaults
    def use_support(self,kind):
        target=next((i for i,c in enumerate(self.battle.players[0].board) if c and c.kind=='GENERAL'),None)
        if kind=='book': return self.use_book(self.loadouts[0].book_name)
        if kind=='command': return self.use_command(self.loadouts[0].command_name,target)
        if kind=='horse': return self.equip_horse(self.loadouts[0].horse_name,target,1)
        if kind=='equipment': return self.equip_equipment(self.loadouts[0].armor_name,target,1)
        return UIActionResult(False,self.state(),'未知支援類型')

    def _ai_play(self):
        owner=1; p=self.battle.players[owner]
        self.ai.begin_turn()
        # 1) Deploy by board/threat/stealth/gate-pressure scoring.
        while p.fire>0 and self.battle.winner is None:
            d=self.ai.choose_play()
            if d is None: break
            before=len(p.hand)
            try:
                self.battle.play(int(d.payload['hand_index']),int(d.payload['slot']))
                self.ai.record(d,True)
                self._touch('a06_ai_play',slot=int(d.payload['slot']),card=d.payload['card'],decision_reason=d.reason,score=d.score)
                self._sync_legacy_log(); self._log(f"AI 部署 {d.payload['card']} → 位置 {int(d.payload['slot'])+1}｜{d.reason}。")
            except Exception as exc:
                self.ai.record(d,False,{'error':str(exc)}); self._log(f'AI 出牌略過：{exc}'); break
            if self.battle.winner is not None or len(p.hand)>=before: break

        if self.battle.winner is not None:return

        # 2) Support timing. At most one book + one command per AI turn.
        bd=self.ai.choose_book()
        if bd is not None:
            try:
                r=self.battle.use_book(owner,bd.payload['name'])
                ok=bool(r.get('applied'))
                self.ai.record(bd,ok,r)
                if ok:
                    self.ai.turn_book_used=True; self.ai.used_books.add(bd.payload['name']); self.support_used[owner]['book'].append(bd.payload['name'])
                    self._touch('a06_ai_book',name=bd.payload['name'],reason=bd.reason,score=bd.score); self._log(f"AI 使用兵書 {bd.payload['name']}｜{bd.reason}。")
            except Exception as exc:self.ai.record(bd,False,{'error':str(exc)})

        if self.battle.winner is not None:return
        cd=self.ai.choose_command()
        if cd is not None:
            try:
                r=self.battle.use_command(owner,cd.payload['name'],target=cd.payload.get('target'))
                ok=bool(r.get('applied'))
                self.ai.record(cd,ok,r)
                if ok:
                    self.ai.turn_command_used=True; self.ai.used_commands.add(cd.payload['name']); self.support_used[owner]['command'].append(cd.payload['name'])
                    self._touch('a06_ai_command',name=cd.payload['name'],target=getattr(cd.payload.get('target'),'name',None),reason=cd.reason,score=cd.score); self._log(f"AI 使用軍令 {cd.payload['name']}｜{cd.reason}。")
            except Exception as exc:self.ai.record(cd,False,{'error':str(exc)})

        # 3) Equipment remains a support preparation step, but target selection is strategic.
        if self.battle.winner is not None:return
        target=max((c for c in p.board if c and c.kind=='GENERAL'),key=lambda c:self.ai._threat(c),default=None)
        if target is not None:
            l=self.loadouts[owner]
            try:
                if not self.support_used[owner]['horse'] and not (getattr(target,'skill_state',{}) or {}).get('horse'):
                    self.battle.equip_horse(owner,target,l.horse_name,level=1); self.support_used[owner]['horse'].append(l.horse_name); self._log(f'AI 將戰馬 {l.horse_name} 配給高威脅主力 {target.name}。')
                if not self.support_used[owner]['equipment']:
                    eq=(getattr(target,'skill_state',{}) or {}).get('equipment',{})
                    if not (isinstance(eq,dict) and any(eq.values())):
                        self.battle.declare_skills(target,[x.get('name') for x in getattr(target,'a04_skills',[]) if x.get('name')]); self.battle.equip_equipment(owner,target,l.armor_name,star=1); self.support_used[owner]['equipment'].append(l.armor_name); self._log(f'AI 將裝備 {l.armor_name} 配給高威脅主力 {target.name}。')
                self._sync_legacy_log()
            except Exception: pass

    def _run_ai_until_player(self):
        safety=0
        while self.battle.winner is None and self.battle.active==1 and safety<4:
            safety+=1
            if not self.turn_ready:self._start_active_turn()
            self._log(f'AI 回合 {self.battle.turn}。');self._ai_play()
            if self.battle.winner is not None:self.turn_ready=False;self._sync_legacy_log();break
            self.battle.combat();self.turn_ready=False;self._touch('a05_ai_combat',turn=self.battle.turn,winner=self.battle.winner);self._sync_legacy_log()
            if self.battle.winner is None and self.battle.active==0:self._start_active_turn()

    def end_turn(self):
        try:
            if not self.started:raise ValueError('請先開始戰鬥')
            if self.battle.winner is not None:return UIActionResult(True,self.state(),'戰鬥已結束')
            if self.battle.active!=0 or not self.turn_ready:raise ValueError('現在不能結束玩家回合')
            self.battle.combat();self.turn_ready=False;self._touch('a05_player_combat',turn=self.battle.turn,winner=self.battle.winner);self._sync_legacy_log()
            if self.battle.winner is None and self.battle.active==1:self._start_active_turn();self._run_ai_until_player()
            elif self.battle.winner is not None:self._log('戰鬥結束。')
            return UIActionResult(True,self.state(),'回合結束')
        except Exception as exc:self._log(f'操作失敗：{exc}');return UIActionResult(False,self.state(),str(exc))

    def state(self):
        p,e=self.battle.players; winner=None if self.battle.winner is None else self.battle.players[self.battle.winner].name
        return {'screen':'BATTLE','reconstruction_label':'相似邏輯UI｜非100%原版像素復刻','ai_policy':'A06_HEURISTIC' ,'started':self.started,'completed':self.battle.winner is not None,'winner':winner,'win_reason':self.battle.win_reason,'turn':int(self.battle.turn),'active_side':'player' if self.battle.active==0 else 'ai','turn_ready':self.turn_ready,'fire':int(p.fire),'enemy_fire':int(e.fire),'player_gate_hp':int(p.gate_hp),'enemy_gate_hp':int(e.gate_hp),'hand':[self._card_view(c) for c in p.hand],'player_slots':[self._card_view(c) for c in p.board],'enemy_slots':[self._card_view(c) for c in e.board],'player_retreat':[self._card_view(c) for c in p.retreat],'enemy_retreat_count':len(e.retreat),'support_used':self.support_used[0],'support_catalog':self.catalog,'interaction':{'click':'先點手牌，再點空場位','drag_drop':'拖曳手牌到空場位','support':'選擇兵書/軍令/戰馬/裝備及目標','end_turn':'結束回合後自動執行戰鬥與AI回合'},'playable_general_count':int(self.session.metadata.get('playable_generals',0)),'growth_profile':self.session.metadata.get('growth_profile'),'growth_book':self.session.metadata.get('growth_book'),'ai_decisions':list(self.ai.decision_log[-40:]),'battle_log':list(self.ui_log[-120:])}
