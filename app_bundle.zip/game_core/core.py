from __future__ import annotations
from dataclasses import dataclass, field, asdict, is_dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
import importlib.util, sys, json, uuid
from .general_runtime import build_deck, GeneralSkillRuntimeMixin, load_catalog
from .pve_runtime import PVEVictoryRuleMixin
from .balance_c08 import apply_legacy_balance, value as c08_value

RUNTIME_FILES = {
    "battle": "battle/grid01_engine.py",
    "cards": "cards/card_loader.py",
    "skills": "skills/skill_engine.py",
    "tactics": "tactics/grid04_engine.py",
    "horse": "horse/grid05_engine.py",
    "equipment": "equipment/grid06_engine.py",
    "progression": "progression/grid07_engine.py",
    "soldier": "soldier/grid08_engine.py",
    "pve": "pve/grid09_engine.py",
    "dungeon": "dungeon/grid10_engine.py",
    "tavern": "tavern/grid11_engine.py",
    "pvp": "pvp/grid12_engine.py",
    "alliance": "alliance/grid13_engine.py",
    "ui": "ui/grid14_ui.py",
    "balance": "balance/grid15_calibration.py",
}

class LegacyLoader:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.modules: Dict[str, Any] = {}

    def load(self, key: str):
        if key in self.modules:
            return self.modules[key]
        p = self.root / RUNTIME_FILES[key]
        if not p.exists():
            raise FileNotFoundError(f"legacy module missing: {p}")
        name = f"kzw_a01_{key}_{abs(hash(str(p)))}"
        spec = importlib.util.spec_from_file_location(name, p)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        assert spec and spec.loader
        spec.loader.exec_module(module)
        self.modules[key] = module
        return module

    def load_all(self):
        return {k: self.load(k) for k in RUNTIME_FILES}

class EventBus:
    """A01 統一事件匯流排。Legacy engine 的 log 保留；Core 再發出跨模組事件。"""
    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = {}
        self.history: List[Dict[str, Any]] = []
        self.seq = 0

    def subscribe(self, event_type: str, callback: Callable[[Dict[str, Any]], None]):
        self._subscribers.setdefault(event_type, []).append(callback)

    def publish(self, event_type: str, **payload):
        self.seq += 1
        evt = {"seq": self.seq, "type": event_type, "payload": payload}
        self.history.append(evt)
        for cb in self._subscribers.get(event_type, []) + self._subscribers.get("*", []):
            cb(evt)
        return evt

class LayeredConfigRegistry:
    """Original / Temporary / Balance 統一唯讀入口；不做層間回寫。"""
    VALID_LAYERS = ("original", "temporary", "balance")
    def __init__(self, root: Path, loader: LegacyLoader):
        self.root = Path(root)
        self.loader = loader
        self.sources: Dict[str, List[str]] = {k: [] for k in self.VALID_LAYERS}

    def get(self, key: str, layer: str = "temporary") -> Any:
        layer = layer.lower()
        if layer not in self.VALID_LAYERS:
            raise ValueError(f"invalid layer: {layer}")
        cal = self.loader.load("balance")
        p = cal.get_parameter(key)
        if p is None:
            raise KeyError(key)
        return getattr(p, layer)

    def effective(self, key: str, mode: str = "temporary") -> Any:
        mode = mode.lower()
        if mode not in self.VALID_LAYERS:
            raise ValueError(f"invalid mode: {mode}")
        return self.loader.load("balance").effective_value(key, mode)

    def validate(self) -> Dict[str, Any]:
        result = self.loader.load("balance").validate_three_layers()
        return {"valid": (result == [] or result is True), "raw": result}

@dataclass
class GameSession:
    session_id: str
    seed: int
    bus: EventBus
    config: LayeredConfigRegistry
    battle: Any
    pve: Any
    dungeon: Any
    tavern: Any
    pvp: Any
    alliance: Any
    ui: Any
    state_version: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def touch(self, reason: str, **detail):
        self.state_version += 1
        self.bus.publish("STATE_CHANGED", version=self.state_version, reason=reason, **detail)
        return self.state_version

    @staticmethod
    def _safe(obj: Any):
        if is_dataclass(obj):
            return asdict(obj)
        if isinstance(obj, (str, int, float, bool, type(None))):
            return obj
        if isinstance(obj, dict):
            return {str(k): GameSession._safe(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple, set)):
            return [GameSession._safe(v) for v in obj]
        if hasattr(obj, "__dict__"):
            return {k: GameSession._safe(v) for k, v in vars(obj).items() if k != "rng"}
        return repr(obj)

    def snapshot(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "seed": self.seed,
            "state_version": self.state_version,
            "battle": self._safe(self.battle),
            "pve": self._safe(self.pve.state),
            "dungeon": self._safe(self.dungeon.state),
            "tavern": self._safe(self.tavern.state),
            "alliance_players": self._safe(getattr(self.alliance, "players", {})),
            "ui": self._safe(self.ui),
        }

    # A01 thin orchestration wrappers; A02 will extend full battle flow.
    def battle_opening(self, shuffle: bool = False):
        self.battle.opening(shuffle)
        self.touch("battle_opening")
        return self.snapshot()

    def battle_start_turn(self):
        self.battle.start_turn()
        self.touch("battle_start_turn", turn=self.battle.turn, active=self.battle.active)

    def battle_play(self, hand_index: int, slot: int):
        self.battle.play(hand_index, slot)
        self.touch("battle_play", hand_index=hand_index, slot=slot)

    def battle_combat(self):
        self.battle.combat()
        self.touch("battle_combat", winner=self.battle.winner)

    def begin_stage(self, stage):
        r = self.pve.begin_stage(stage)
        self.touch("pve_begin", stage_id=stage.stage_id)
        return r

    def finish_stage(self, stage, won: bool):
        r = self.pve.finish_stage(stage, won)
        self.touch("pve_finish", stage_id=stage.stage_id, won=won)
        return r

class GameCore:
    """第二階段統一組合根。第一階段各格視為 legacy modules，不直接改寫。"""
    def __init__(self, legacy_root: str | Path):
        self.root = Path(legacy_root)
        self.loader = LegacyLoader(self.root)
        self.modules = self.loader.load_all()
        apply_legacy_balance(self.modules)
        self.config = LayeredConfigRegistry(self.root, self.loader)

    def module_inventory(self) -> Dict[str, str]:
        return {k: str(self.root / v) for k, v in RUNTIME_FILES.items()}

    def create_session(self, *, seed: int = 1, player_names=("PLAYER", "AI"), deck_names=None, victory_rule: str = "STANDARD") -> GameSession:
        m8 = self.modules["soldier"]
        base_battle_cls = m8.SoldierBattle
        battle_cls = type("A10PrototypeBattle", (PVEVictoryRuleMixin, GeneralSkillRuntimeMixin, base_battle_cls), {"victory_rule": victory_rule})
        # Resolve the inherited Grid01 module types through the MRO.
        battle_base = next(c for c in battle_cls.__mro__ if c.__name__ == "Battle")
        base_mod = sys.modules[battle_base.__module__]
        Card, PlayerState = base_mod.Card, base_mod.PlayerState
        demo_deck = base_mod.demo_deck
        p1 = PlayerState(player_names[0], build_deck(Card, deck_names))
        p2 = PlayerState(player_names[1], build_deck(Card, deck_names))
        battle = battle_cls(p1, p2, first_player=0, seed=seed)
        for pp in battle.players:
            pp.fire=int(c08_value('battle.initial_fire')); pp.gate_hp=int(c08_value('battle.player_gate_hp'))

        pve_m = self.modules["pve"]
        dun_m = self.modules["dungeon"]
        tav_m = self.modules["tavern"]
        pvp_m = self.modules["pvp"]
        ali_m = self.modules["alliance"]
        ui_m = self.modules["ui"]
        bus = EventBus()
        s = GameSession(
            session_id=str(uuid.uuid4()), seed=seed, bus=bus, config=self.config,
            battle=battle,
            pve=pve_m.PVEEngine(seed=seed),
            dungeon=dun_m.DungeonEngine(),
            tavern=tav_m.TavernEngine(seed=seed),
            pvp=pvp_m.PVPEngine(seed=seed),
            alliance=ali_m.AllianceEngine(),
            ui=ui_m.BattleUIState(),
            metadata={"core_version": "A10", "runtime_baseline": "prototype-v0.4", "playable_generals": load_catalog()["playable_count"]},
        )
        bus.publish("SESSION_CREATED", session_id=s.session_id, seed=seed)
        return s
