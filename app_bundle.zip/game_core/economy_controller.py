from __future__ import annotations
from datetime import date
import json
from pathlib import Path
from typing import Any, Callable, Dict
from .balance_c08 import value as c08_value

BASE=Path(__file__).resolve().parent.parent
CATALOG=json.loads((BASE/'b06_economy_catalog.json').read_text(encoding='utf-8'))

class EconomyController:
    def __init__(self, growth, collection, campaign, today_provider:Callable[[],str]|None=None):
        self.growth=growth; self.collection=collection; self.campaign=campaign
        self.today_provider=today_provider or (lambda: date.today().isoformat())
        self.last_daily_claim=''; self.history=[]
        # Make B06 resources explicit without overwriting existing balances.
        self.growth.roster.resources.setdefault('將魂',0)
        self.growth.roster.resources.setdefault('軍令資源',0)

    def _today(self): return str(self.today_provider())
    def _get(self,name:str)->int:
        if name=='元寶': return int(self.collection.engine.state.yuanbao)
        if name=='招募令': return int(self.collection.recruit_tickets)
        if name=='糧草': return int(self.campaign.state.food)
        if name=='掃蕩卡': return int(self.campaign.state.sweep_cards)
        return int(self.growth.roster.resources.get(name,0))
    def _set(self,name:str,value:int):
        value=max(0,int(value))
        if name=='元寶': self.collection.engine.state.yuanbao=value
        elif name=='招募令': self.collection.recruit_tickets=value
        elif name=='糧草': self.campaign.state.food=value
        elif name=='掃蕩卡': self.campaign.state.sweep_cards=value
        else: self.growth.roster.resources[name]=value
    def _add(self,name:str,qty:int): self._set(name,self._get(name)+int(qty))
    def balances(self)->Dict[str,int]:
        base={k:self._get(k) for k in ['銀幣','元寶','招募令','進化丹','馬糧','鍛造石','兵書殘頁','掃蕩卡','糧草','將魂','軍令資源']}
        # Expose all currently held named fragments as one resource family detail.
        for k,v in self.growth.roster.resources.items():
            if str(k).endswith('碎片'): base[str(k)]=int(v)
        return base
    def claim_daily_supply(self)->Dict[str,Any]:
        today=self._today()
        if self.last_daily_claim==today: raise ValueError('今日循環補給已領取')
        x=c08_value('economy.outputs')['daily_supply']; rewards={'元寶':int(x['yuanbao']),'招募令':int(x['ticket']),'糧草':int(x['food']),'掃蕩卡':int(x['sweep'])}
        for k,v in rewards.items(): self._add(k,v)
        self.last_daily_claim=today
        r={'action':'DAILY_SUPPLY','day':today,'rewards':rewards,'layer':'BALANCE_C08'}; self.history.append(r); return r
    def exchange(self,exchange_id:str)->Dict[str,Any]:
        rec=next((x for x in CATALOG['temporary_exchanges'] if x['exchange_id']==str(exchange_id)),None)
        if not rec: raise ValueError('未知資源兌換')
        for k,v in rec['pay'].items():
            if self._get(k)<int(v): raise ValueError(f'資源不足：{k} 需要 {v}')
        for k,v in rec['pay'].items(): self._add(k,-int(v))
        for k,v in rec['receive'].items(): self._add(k,int(v))
        r={'action':'EXCHANGE','exchange_id':rec['exchange_id'],'pay':dict(rec['pay']),'receive':dict(rec['receive']),'layer':'TEMPORARY'}; self.history.append(r); return r
    def export(self): return {'last_daily_claim':self.last_daily_claim,'history':list(self.history[-50:])}
    def import_data(self,data):
        data=data or {}; self.last_daily_claim=str(data.get('last_daily_claim') or ''); self.history=list(data.get('history') or [])[-50:]
    def state(self):
        families=[]
        for x in CATALOG['resource_families']:
            y=dict(x); families.append(y)
        exchanges=[]
        for x in CATALOG['temporary_exchanges']:
            y=dict(x); y['affordable']=all(self._get(k)>=int(v) for k,v in x['pay'].items()); exchanges.append(y)
        active=[x for x in families if x['status'].startswith('ACTIVE') or x['status']=='MIXED']
        # Active families have at least one current or explicit next-grid source/use; planned-only resources are not treated as broken loops.
        return {'version':'B06','day':self._today(),'daily_claimed':self.last_daily_claim==self._today(),'daily_supply':dict(CATALOG['temporary_daily_supply']),'balances':self.balances(),'resource_families':families,'exchanges':exchanges,'loop_status':{'acquire_consume_grow_reacquire':True,'active_family_count':len(active),'planned_locked':['神符','萬能將魂完整轉換規則']},'history':list(self.history[-10:])}
