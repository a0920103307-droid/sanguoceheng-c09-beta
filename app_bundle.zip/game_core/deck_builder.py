from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List

B03_RULES={
    'slot_count':3,
    'deck_min_cards':1,
    'deck_max_cards':8,
    'same_name_limit':1,
    'allowed_types':['GENERAL'],
    'cost_limit_enabled':False,
    'cost_limit':None,
    'support_cards_in_deck':False,
    'loadout_binding':'GENERAL_PROFILE',
    'source_layer':'TEMPORARY_UNLESS_ORIGINAL_CONFIRMED',
}

@dataclass
class DeckSlot:
    slot_id:int
    name:str
    cards:List[str]=field(default_factory=list)

class DeckBuildingController:
    def __init__(self, collection):
        self.collection=collection
        starter=list(collection.lineup or ['張遼'])
        self.slots=[DeckSlot(1,'牌組一',starter),DeckSlot(2,'牌組二',starter.copy()),DeckSlot(3,'牌組三',starter.copy())]
        self.active_slot_id=1
        self.formal_active=False

    def _owned_names(self):
        owned=set(self.collection.engine.state.owned)
        return {c['name'] for c in self.collection.cards if c['card_id'] in owned}

    def validate_cards(self,cards:List[str])->Dict[str,Any]:
        names=[str(x) for x in cards]
        errors=[]
        if len(names)<B03_RULES['deck_min_cards']: errors.append('牌組至少需要1張卡')
        if len(names)>B03_RULES['deck_max_cards']: errors.append('牌組最多8張卡')
        if len(set(names))!=len(names): errors.append('同名卡不可重複')
        owned=self._owned_names()
        for n in names:
            c=self.collection.by_name.get(n)
            if not c: errors.append(f'未知卡牌：{n}'); continue
            if n not in owned: errors.append(f'尚未收藏：{n}')
            ctype=str(c.get('type') or c.get('card_type') or 'GENERAL').upper()
            if ctype not in B03_RULES['allowed_types']: errors.append(f'目前正式牌組僅開放武將卡：{n}')
        return {'valid':not errors,'errors':errors,'card_count':len(names),'cost_check':'DISABLED_UNCONFIRMED_ORIGINAL'}

    def slot(self,slot_id:int)->DeckSlot:
        sid=int(slot_id)
        for s in self.slots:
            if s.slot_id==sid:return s
        raise ValueError('未知牌組槽位')

    def save_slot(self,slot_id:int,name:str,cards:List[str])->Dict[str,Any]:
        v=self.validate_cards(cards)
        if not v['valid']: raise ValueError('；'.join(v['errors']))
        s=self.slot(slot_id); s.name=(str(name).strip() or f'牌組{s.slot_id}'); s.cards=[str(x) for x in cards]
        if s.slot_id==self.active_slot_id: self.collection.lineup=list(s.cards)
        self.formal_active=True
        return {'action':'SAVE_DECK','slot':asdict(s),'validation':v}

    def select_slot(self,slot_id:int)->Dict[str,Any]:
        s=self.slot(slot_id); v=self.validate_cards(s.cards)
        if not v['valid']: raise ValueError('此牌組無法啟用：'+'；'.join(v['errors']))
        self.active_slot_id=s.slot_id; self.collection.lineup=list(s.cards); self.formal_active=True
        return {'action':'SELECT_DECK','active_slot_id':self.active_slot_id,'slot':asdict(s)}

    def active_cards(self)->List[str]:
        s=self.slot(self.active_slot_id); v=self.validate_cards(s.cards)
        if not v['valid']: raise ValueError('違規牌組不能進戰鬥：'+'；'.join(v['errors']))
        return list(s.cards)

    def state(self)->Dict[str,Any]:
        return {'version':'B03','formal_active':self.formal_active,'active_slot_id':self.active_slot_id,'slots':[dict(asdict(s),validation=self.validate_cards(s.cards)) for s in self.slots],'rules':dict(B03_RULES)}

    def export(self)->Dict[str,Any]: return {'formal_active':self.formal_active,'active_slot_id':self.active_slot_id,'slots':[asdict(s) for s in self.slots]}

    def import_data(self,data:Dict[str,Any]):
        if not isinstance(data,dict): return
        incoming=[]
        for raw in data.get('slots',[]):
            if not isinstance(raw,dict): continue
            try: sid=int(raw.get('slot_id'))
            except: continue
            if sid not in (1,2,3): continue
            incoming.append(DeckSlot(sid,str(raw.get('name') or f'牌組{sid}'),[str(x) for x in raw.get('cards',[])]))
        by={s.slot_id:s for s in incoming}
        for i in (1,2,3):
            if i in by: self.slots[i-1]=by[i]
        try:self.active_slot_id=int(data.get('active_slot_id',1))
        except:self.active_slot_id=1
        if self.active_slot_id not in (1,2,3): self.active_slot_id=1
        self.formal_active=bool(data.get('formal_active',False))
        active=self.slot(self.active_slot_id)
        if self.formal_active and self.validate_cards(active.cards)['valid']: self.collection.lineup=list(active.cards)
