from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Callable
import datetime as _dt
import json
from .ui_controller import UIActionResult
from .balance_c08 import value as c08_value

BASE=Path(__file__).resolve().parent.parent
CATALOG=json.loads((BASE/'b05_dungeon_catalog.json').read_text(encoding='utf-8'))

class DailyDungeonController:
    """B05 daily-loop adapter. Content identity is catalog driven; unknown quantities stay Temporary."""
    def __init__(self, growth, *, today_fn:Callable[[],str]|None=None):
        self.growth=growth
        self.today_fn=today_fn or (lambda:_dt.date.today().isoformat())
        self.day=self.today_fn()
        self.runs:Dict[str,int]={}
        self.history=[]
        self.alliance_boss=dict(CATALOG['alliance_boss_preload'])
        self.player_level=20  # Prototype account level; account-level progression not yet formalized.

    def _roll_day(self):
        now=self.today_fn()
        if now != self.day:
            self.day=now; self.runs={}
            self.history.append({'action':'DAILY_RESET','day':now})
            return True
        return False

    def _def(self,dungeon_id):
        rec=next((x for x in CATALOG['dungeons'] if x['dungeon_id']==dungeon_id),None)
        if not rec: raise ValueError('未知副本')
        return rec

    def state(self):
        self._roll_day()
        rows=[]
        for d in CATALOG['dungeons']:
            used=int(self.runs.get(d['dungeon_id'],0)); limit=int(c08_value('dungeon.daily_limits')[{'B05_HORSE_RAID':'horse','B05_GROWTH_RESOURCE':'growth','B05_BOOK_COMMAND':'book_command'}.get(d['dungeon_id'],'growth')])
            rows.append({**d,'temporary_daily_limit':int(d['daily_limit']),'daily_limit':limit,'used_today':used,'remaining':max(0,limit-used),'unlocked':self.player_level>=int(d.get('unlock_level') or 1)})
        boss={**self.alliance_boss,'used_today':int(self.runs.get('ALLIANCE_BOSS',0)),'remaining':max(0,int(self.alliance_boss['daily_limit'])-int(self.runs.get('ALLIANCE_BOSS',0)))}
        return {'version':'B05','day':self.day,'reset_rule':CATALOG['daily_reset_rule'],'dungeons':rows,'alliance_boss_preload':boss,'history':list(self.history[-20:])}

    def challenge(self,dungeon_id:str):
        try:
            self._roll_day(); d=self._def(str(dungeon_id))
            if self.player_level < int(d.get('unlock_level') or 1): raise ValueError(f"需要玩家等級 {d['unlock_level']}")
            used=int(self.runs.get(d['dungeon_id'],0)); limit=int(c08_value('dungeon.daily_limits')[{'B05_HORSE_RAID':'horse','B05_GROWTH_RESOURCE':'growth','B05_BOOK_COMMAND':'book_command'}.get(d['dungeon_id'],'growth')])
            if used>=limit: raise ValueError('今日挑戰次數已用完')
            self.runs[d['dungeon_id']]=used+1
            rewards=dict(CATALOG['temporary_rewards'].get(d['dungeon_id'],{}))
            if d['dungeon_id']=='B05_GROWTH_RESOURCE':
                x=c08_value('economy.outputs')['growth_dungeon']; rewards={'銀幣':int(x['silver']),'武將經驗':int(x['xp']),'進化丹':int(x['pill'])}
            elif d['dungeon_id']=='B05_HORSE_RAID': rewards={'馬糧':2}
            elif d['dungeon_id']=='B05_BOOK_COMMAND': rewards={'兵書殘頁':1,'軍令資源':1}
            roster=self.growth.roster
            for item,qty in rewards.items(): roster.resources[item]=int(roster.resources.get(item,0))+int(qty)
            # Horse dungeon also feeds existing ownership, but does not claim an original probability.
            bonus=None
            if d['category']=='HORSE' and self.runs[d['dungeon_id']]==1:
                roster.owned_horses['西南馬']=int(roster.owned_horses.get('西南馬',0))+1
                bonus={'item':'西南馬','qty':1,'layer':'TEMPORARY_DETERMINISTIC_PROTOTYPE'}
            rec={'action':'DUNGEON_CLEAR','dungeon_id':d['dungeon_id'],'day':self.day,'run':self.runs[d['dungeon_id']], 'rewards':rewards,'bonus':bonus,'reward_layer':'BALANCE_C08','source_layer':d['source_layer']}
            self.history.append(rec)
            return UIActionResult(True,self.state(),f"{d['name']} 挑戰完成")
        except Exception as exc:
            return UIActionResult(False,self.state(),str(exc))

    def export(self):
        self._roll_day()
        return {'day':self.day,'runs':dict(self.runs),'history':list(self.history[-50:]),'player_level':int(self.player_level)}

    def import_data(self,data:Dict[str,Any]|None):
        data=data or {}; self.day=str(data.get('day') or self.today_fn())
        self.runs={str(k):max(0,int(v)) for k,v in (data.get('runs') or {}).items()}
        self.history=list(data.get('history') or [])[-50:]
        self.player_level=max(1,int(data.get('player_level',20)))
        self._roll_day(); return self.state()
