from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .support_runtime import support_catalog, command_target_mode
from .balance_c08 import value as c08_value
AI_BALANCE=c08_value('ai.policy')


def _statuses(card) -> Dict[str, Any]:
    st=getattr(card,'skill_state',{}) or {}
    return st.get('statuses',{}) if isinstance(st,dict) else {}


def _has(card, name:str) -> bool:
    return bool(card is not None and name in _statuses(card))


@dataclass
class AIDecision:
    action: str
    score: float
    reason: str
    payload: Dict[str, Any] = field(default_factory=dict)


class BattleAI:
    """A06 heuristic policy layer.

    It never mutates combat state directly. It only selects actions; Grid01-08 remain
    the authoritative executors. Scores are Temporary AI policy weights, not Original data.
    """
    def __init__(self, battle, owner:int=1):
        self.battle=battle
        self.owner=int(owner)
        self.enemy=1-self.owner
        self.pve_safe=False
        self.catalog=support_catalog()
        self.used_books:set[str]=set()
        self.used_commands:set[str]=set()
        self.turn_book_used=False
        self.turn_command_used=False
        self.decision_log:List[Dict[str,Any]]=[]

    def begin_turn(self):
        self.turn_book_used=False
        self.turn_command_used=False

    def _cards(self, owner:int):
        return [c for c in self.battle.players[owner].board if c is not None and c.hp>0]

    def _empty_slots(self, owner:int):
        return [i for i,c in enumerate(self.battle.players[owner].board) if c is None]

    def _threat(self, c) -> float:
        if c is None:return -1e9
        score=float(max(0,c.attack))*float(AI_BALANCE['threat_attack']) + float(max(0,c.hp))
        st=_statuses(c)
        if 'TAUNT' in st: score+=5
        if 'STEALTH' in st: score+=float(AI_BALANCE['stealth_threat'])
        if 'COUNTER' in st: score+=4
        if 'DIVINE_PROTECTION' in st: score+=4
        skills=getattr(c,'a04_skills',[]) or []
        for sk in skills:
            for spec in sk.get('compiled',[]) or []:
                et=str(spec.get('effect',{}).get('type','')).upper()
                if et in {'DAMAGE','DIRECT_DEFEAT','DAMAGE_GATE'}: score+=3
                if et in {'TAUNT','STEALTH','REVEAL','SILENCE','SEAL','LOCK'}: score+=2
        return score

    def high_threat_enemy(self):
        xs=self._cards(self.enemy)
        return max(xs,key=self._threat) if xs else None

    def low_hp_enemy(self):
        xs=self._cards(self.enemy)
        return min(xs,key=lambda c:(c.hp,self._threat(c))) if xs else None

    def low_hp_ally(self):
        xs=self._cards(self.owner)
        return min(xs,key=lambda c:(c.hp/max(1,c.max_hp),c.hp)) if xs else None

    def enemy_has_stealth(self): return any(_has(c,'STEALTH') for c in self._cards(self.enemy))
    def enemy_has_taunt(self): return any(_has(c,'TAUNT') and not _has(c,'STEALTH') for c in self._cards(self.enemy))
    def ally_has_negative(self):
        neg={'SILENCE','SEAL','PETRIFY','CONFUSION','LOCK','ACTION_LOCK'}
        return any(neg.intersection(_statuses(c)) for c in self._cards(self.owner))

    def _card_score(self, card) -> Tuple[float,List[str]]:
        score=float(card.attack)*float(AI_BALANCE['card_attack']) + float(card.hp)
        why=['基礎戰力']
        enemy_stealth=self.enemy_has_stealth()
        enemy_taunt=self.enemy_has_taunt()
        for sk in getattr(card,'a04_skills',[]) or []:
            for spec in sk.get('compiled',[]) or []:
                et=str(spec.get('effect',{}).get('type','')).upper()
                if et=='REVEAL' and enemy_stealth: score+=float(AI_BALANCE['reveal_bonus']); why.append('照明對隱身')
                elif et in {'DAMAGE','DIRECT_DEFEAT'}: score+=5; why.append('解場')
                elif et in {'SILENCE','SEAL','LOCK','CONFUSION'}: score+=float(AI_BALANCE['control_bonus']); why.append('控制')
                elif et=='TAUNT': score+=3 if self.battle.players[self.owner].gate_hp<=10 else 1; why.append('保城嘲諷')
                elif et=='STEALTH': score+=2; why.append('生存')
                elif et=='DAMAGE_GATE': score+=8 if self.battle.players[self.enemy].gate_hp<=8 else 2; why.append('攻城')
        if enemy_taunt and card.attack>=4: score+=4; why.append('破嘲諷')
        return score,why

    def choose_play(self) -> Optional[AIDecision]:
        p=self.battle.players[self.owner]
        empties=self._empty_slots(self.owner)
        if p.fire<=0 or not empties:return None
        candidates=[]
        for i,c in enumerate(p.hand):
            if getattr(c,'kind',None) not in ('GENERAL','SOLDIER'):continue
            score,why=self._card_score(c)
            # Choose lane: attack empty lane for gate pressure, otherwise contest highest-threat lane.
            enemy_board=self.battle.players[self.enemy].board
            empty_enemy=[s for s in empties if enemy_board[s] is None]
            threat_slots=[s for s in empties if enemy_board[s] is not None]
            if self.enemy_has_taunt():
                slot=empties[0]; why.append('敵方嘲諷使站位次要')
            elif self.battle.players[self.enemy].gate_hp<=8 and empty_enemy:
                slot=empty_enemy[0]; score+=float(AI_BALANCE['gate_pressure_bonus']); why.append('優先攻城')
            elif threat_slots:
                slot=max(threat_slots,key=lambda s:self._threat(enemy_board[s])); score+=8; why.append('優先解高威脅')
            elif empty_enemy:
                slot=empty_enemy[0]; score+=5; why.append('空線攻城')
            else:
                slot=empties[0]
            candidates.append(AIDecision('PLAY_CARD',score,'、'.join(dict.fromkeys(why)),{'hand_index':i,'slot':slot,'card':c.name}))
        if not candidates:return None
        return max(candidates,key=lambda d:d.score)

    def choose_command(self) -> Optional[AIDecision]:
        if self.turn_command_used:return None
        ally=self._cards(self.owner); enemy=self._cards(self.enemy)
        if not ally and not enemy:return None
        opts=[]
        high=self.high_threat_enemy(); lowe=self.low_hp_enemy(); lowa=self.low_hp_ally()
        # 集火: hard answer to stealth/taunt/high-threat; engine focus target ignores taunt/stealth.
        if high is not None and '軍令集火' not in self.used_commands:
            bonus=35 if self.enemy_has_stealth() else 25 if self.enemy_has_taunt() else 10
            opts.append(AIDecision('COMMAND',bonus+self._threat(high)/10,'集火處理隱身／嘲諷／高威脅',{'name':'軍令集火','target':high}))
        if lowe is not None and '軍令衝擊' not in self.used_commands:
            score=18 if lowe.hp<=3 else 7
            opts.append(AIDecision('COMMAND',score,'衝擊收掉低血量目標',{'name':'軍令衝擊','target':lowe}))
        if lowa is not None and '軍令重生' not in self.used_commands:
            ratio=lowa.hp/max(1,lowa.max_hp)
            if ratio<=0.45 or _statuses(lowa):
                opts.append(AIDecision('COMMAND',20+(1-ratio)*10,'重生救低血量／異常核心',{'name':'軍令重生','target':lowa}))
        if ally and '軍令戰意' not in self.used_commands:
            best=max(ally,key=lambda c:c.attack)
            opts.append(AIDecision('COMMAND',8,'戰意強化最高攻擊主力',{'name':'軍令戰意','target':best}))
        if ally and '軍令死誌' not in self.used_commands:
            target=min(ally,key=lambda c:c.hp/max(1,c.max_hp))
            if target.hp/max(1,target.max_hp)<=0.35:
                opts.append(AIDecision('COMMAND',9,'死誌榨取瀕危單位輸出',{'name':'軍令死誌','target':target}))
        if self.battle.players[self.owner].gate_hp<=8 and self._empty_slots(self.owner) and '軍令固守' not in self.used_commands:
            opts.append(AIDecision('COMMAND',16,'城門低血量時固守',{'name':'軍令固守','target':None}))
        return max(opts,key=lambda d:d.score) if opts else None

    def choose_book(self) -> Optional[AIDecision]:
        if self.turn_book_used:return None
        ally=self._cards(self.owner); enemy=self._cards(self.enemy)
        p=self.battle.players[self.owner]; e=self.battle.players[self.enemy]
        opts=[]
        def add(name,score,reason):
            if self.pve_safe and name in {'太平清領道','青囊書','遁甲天書','吳子兵法','十勝十敗論'}: return
            if name not in self.used_books: opts.append(AIDecision('BOOK',score,reason,{'name':name}))
        if p.retreat and self._empty_slots(self.owner): add('還魂咒',32,'有敗退武將且有空位，優先復活')
        if self.ally_has_negative(): add('論語',30,'清除我方負面狀態')
        if p.gate_hp<=8: add('遁甲天書',28,'城門低血量保命')
        if len(enemy)>=3: add('太平要術',24,'敵方多人時沉默並鎖行動')
        if len(enemy)>=2: add('太平清領道',22,'敵方多人時全體傷害')
        if enemy and sum(c.attack for c in enemy)>sum(c.attack for c in ally)+3: add('吳子兵法',20,'敵方總攻擊較高，先降攻')
        if len(ally)>=2: add('十勝十敗論',18,'我方多人時全體加攻')
        if len(ally)>=2 and any(c.hp<c.max_hp for c in ally): add('青囊書',17,'我方多人受傷，提升生命')
        if len(ally)>=2: add('鬼谷子',14,'我方成形後提升技能等級')
        if len(p.hand)<=3 and len(p.deck)>0: add('孫臏兵法',19,'手牌偏低，補牌並加火種')
        if len(e.retreat)>=2: add('詩經',13,'敵方敗退區累積，阻止復活')
        if self._empty_slots(self.owner) and len(ally)<=2: add('史記',8,'我方場面不足時補臨時兵魄')
        if enemy and self._empty_slots(self.owner): add('孫子兵法',16,'借敵軍助陣或滿場時鎖敵')
        if len(p.hand)<=6: add('兵法24篇',9,'補充軍令資源')
        # 司馬法 intentionally omitted: in current prototype it can fill enemy lanes and
        # often blocks gate pressure. Avoiding it is an explicit anti-self-destruction policy.
        return max(opts,key=lambda d:d.score) if opts else None

    def record(self,d:AIDecision,applied:bool=True,detail:Optional[Dict[str,Any]]=None):
        row={'action':d.action,'score':round(d.score,2),'reason':d.reason,'payload':{k:(v.name if hasattr(v,'name') else v) for k,v in d.payload.items()},'applied':bool(applied)}
        if detail: row['detail']=detail
        self.decision_log.append(row)
        if len(self.decision_log)>120:self.decision_log=self.decision_log[-120:]
        return row
