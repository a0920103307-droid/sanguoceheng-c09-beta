from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / 'runtime_modules'


def _read(rel: str):
    return json.loads((RUNTIME / rel).read_text(encoding='utf-8'))


def support_catalog() -> Dict[str, Any]:
    tactics = _read('tactics/tactic_catalog_v0.4.json')
    horses = _read('horse/horse_catalog_v0.5.json')
    equip = _read('equipment/equipment_catalog_v0.6.json')
    return {
        'books': tactics['books'],
        'commands': tactics['commands'],
        'horses': horses['horses'],
        'equipment': equip['equipment'],
        'exclusive_fates': equip['exclusive_fates'],
    }


def command_target_mode(name: str) -> str:
    if name in {'軍令集火','軍令衝擊'}: return 'ENEMY'
    if name in {'軍令戰意','軍令死誌','軍令重生'}: return 'ALLY'
    if name == '軍令固守': return 'NONE'
    raise KeyError(name)


def equipment_slot(name: str) -> str:
    for row in support_catalog()['equipment']:
        if row['name'] == name or row['equipment_id'] == name:
            return row['slot']
    raise KeyError(name)


def public_catalog() -> Dict[str, List[Dict[str, Any]]]:
    c=support_catalog()
    return {
      'books': [{k:x.get(k) for k in ('id','name','quality','max_level','effect_original','confidence')} for x in c['books']],
      'commands': [{**{k:x.get(k) for k in ('id','name','level','effect_original','confidence','numeric_status')}, 'target_mode':command_target_mode(x['name'])} for x in c['commands']],
      'horses': [{k:x.get(k) for k in ('horse_id','name','quality','skill_name','binding','effect_original','confidence')} for x in c['horses']],
      'equipment': [{k:x.get(k) for k in ('equipment_id','name','slot','quality','exclusive_to','confidence')} for x in c['equipment']],
      'exclusive_fates': list(c['exclusive_fates']),
    }
