from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional
from copy import deepcopy
from .general_runtime import load_catalog
from .support_runtime import support_catalog
from .balance_c08 import value as c08_value

# A08 Temporary economy. Original rules are read from frozen Grid07; exact costs/stat curves are not claimed as original.
_GC=c08_value('growth.costs')
TEMP = {
    'level_cap': 20,
    'level_xp_cost': int(_GC['level_xp']),
    'level_silver_cost': int(_GC['level_silver']),
    'level_attack_every': 5,
    'level_hp_every': 3,
    'star_attack_bonus': 1,
    'star_hp_bonus': 1,
    'horse_feed_per_level': int(_GC['horse_feed']),
    'equipment_stone_per_star': int(_GC['equipment_stone']),
    'book_pages_to_master': int(_GC['book_pages']),
}

STARTER_RESOURCES = {
    '銀幣': 1600,
    '武將經驗': 60,
    '進化丹': 6,
    '張遼碎片': 50,
    '馬糧': 12,
    '鍛造石': 16,
    '兵書殘頁': 8,
}

@dataclass
class GeneralGrowth:
    name: str
    level: int = 1
    star: int = 1
    quality: str = '橙'
    equipped_weapon: Optional[str] = None
    weapon_star: int = 1
    equipped_armor: Optional[str] = None
    armor_star: int = 1
    equipped_horse: Optional[str] = None
    horse_level: int = 1
    equipped_book: Optional[str] = None
    book_mastered: bool = False
    history: list = field(default_factory=list)

class GrowthRoster:
    def __init__(self, progression_module, starter='張遼'):
        self.m=progression_module
        self.catalog=load_catalog()
        by={x['name']:x for x in self.catalog['cards']}
        if starter not in by: raise KeyError(starter)
        self.generals={starter:GeneralGrowth(starter, quality=by[starter].get('quality') or '橙')}
        self.resources=deepcopy(STARTER_RESOURCES)
        # A08 starter ownership is Temporary so one complete growth cycle is runnable before A09 tavern/collection exists.
        self.owned_equipment={'龍鱗刀':1,'玄鐵甲':1}
        self.owned_horses={'西南馬':1,'的盧':1}
        self.owned_books={'鬼谷子':1,'六韜':1}
        self.history=[]

    def profile(self,name='張遼') -> GeneralGrowth:
        if name not in self.generals: raise ValueError('尚未持有此武將')
        return self.generals[name]

    def _spend(self, needs:Dict[str,int]):
        for k,v in needs.items():
            if int(self.resources.get(k,0)) < int(v): raise ValueError(f'資源不足：{k} 需要 {v}')
        for k,v in needs.items(): self.resources[k]=int(self.resources.get(k,0))-int(v)

    def level_up(self,name='張遼',times=1):
        p=self.profile(name); done=[]
        for _ in range(max(1,int(times))):
            if p.level>=TEMP['level_cap']: break
            needs={'武將經驗':TEMP['level_xp_cost'],'銀幣':TEMP['level_silver_cost']}
            self._spend(needs); old=p.level; p.level+=1
            r={'action':'LEVEL_UP','name':name,'from':old,'to':p.level,'consumed':needs,'layer':'BALANCE_C08'}; p.history.append(r); self.history.append(r); done.append(r)
        if not done: raise ValueError('已達目前等級上限')
        return done[-1]

    def evolve(self,name='張遼'):
        p=self.profile(name)
        if p.star>=5: raise ValueError('已達5星上限')
        # Delegate requirements/star semantics to frozen Grid07; use fragments for orange starter.
        class Dummy:
            kind='GENERAL'
            def __init__(self,n,q): self.name=n; self.quality=q; self.attack=1; self.max_hp=1; self.hp=1
        d=Dummy(p.name,p.quality); self.m.set_progression(d,star=p.star,quality=p.quality)
        req=self.m.evolution_requirements(d,use_fragments=True)
        needs={'進化丹':int(req['evolution_pills']),'銀幣':int(req['silver'] or 0),f'{name}碎片':int(req['fragments'])}
        needs={k:v for k,v in needs.items() if v>0}; self._spend(needs)
        old=p.star; p.star+=1
        r={'action':'EVOLVE','name':name,'from_star':old,'to_star':p.star,'skill_unlock_count':self.unlocked_skill_count(name),'consumed':needs,'numeric_confidence':req['numeric_confidence'],'layer':'ORIGINAL_RULE_TEMP_NUMBERS'}
        p.history.append(r); self.history.append(r); return r

    def unlocked_skill_count(self,name='張遼'):
        return int(self.m.CATALOG['star_to_unlocked_skill_count'][str(self.profile(name).star)])

    def equip_item(self,name,item):
        p=self.profile(name); cat=support_catalog()
        rec=next((x for x in cat['equipment'] if x['name']==item),None)
        if not rec or self.owned_equipment.get(item,0)<1: raise ValueError('未持有此裝備')
        if rec['slot']=='WEAPON': p.equipped_weapon=item; p.weapon_star=max(1,p.weapon_star)
        elif rec['slot']=='ARMOR': p.equipped_armor=item; p.armor_star=max(1,p.armor_star)
        else: raise ValueError('未知裝備欄位')
        r={'action':'EQUIP_ITEM','name':name,'item':item,'slot':rec['slot']}; p.history.append(r); self.history.append(r); return r

    def strengthen_equipment(self,name,slot):
        p=self.profile(name); attr='weapon_star' if str(slot).upper()=='WEAPON' else 'armor_star'; equipped=p.equipped_weapon if attr=='weapon_star' else p.equipped_armor
        if not equipped: raise ValueError('請先裝備該欄位裝備')
        old=getattr(p,attr)
        if old>=5: raise ValueError('裝備已達5星')
        needs={'鍛造石':TEMP['equipment_stone_per_star'],'銀幣':15}; self._spend(needs); setattr(p,attr,old+1)
        r={'action':'EQUIPMENT_STAR','name':name,'item':equipped,'from':old,'to':old+1,'consumed':needs,'layer':'TEMPORARY_COST'}; p.history.append(r); self.history.append(r); return r

    def equip_horse(self,name,horse):
        p=self.profile(name)
        if self.owned_horses.get(horse,0)<1: raise ValueError('未持有此戰馬')
        if not any(x['name']==horse for x in support_catalog()['horses']): raise ValueError('未知戰馬')
        p.equipped_horse=horse; p.horse_level=max(1,p.horse_level)
        r={'action':'EQUIP_HORSE','name':name,'horse':horse}; p.history.append(r); self.history.append(r); return r

    def strengthen_horse(self,name):
        p=self.profile(name)
        if not p.equipped_horse: raise ValueError('請先裝備戰馬')
        if p.horse_level>=10: raise ValueError('戰馬已達A08暫定上限')
        needs={'馬糧':TEMP['horse_feed_per_level'],'銀幣':15}; self._spend(needs); old=p.horse_level; p.horse_level+=1
        r={'action':'HORSE_LEVEL','name':name,'horse':p.equipped_horse,'from':old,'to':p.horse_level,'consumed':needs,'layer':'TEMPORARY_COST'}; p.history.append(r); self.history.append(r); return r

    def study_book(self,name,book):
        p=self.profile(name)
        if self.owned_books.get(book,0)<1: raise ValueError('未持有此兵書')
        if not any(x['name']==book for x in support_catalog()['books']): raise ValueError('未知兵書')
        needs={'兵書殘頁':TEMP['book_pages_to_master'],'銀幣':30}; self._spend(needs)
        p.equipped_book=book; p.book_mastered=True
        r={'action':'STUDY_BOOK','name':name,'book':book,'consumed':needs,'layer':'TEMPORARY_OWNERSHIP_COST'}; p.history.append(r); self.history.append(r); return r

    def battle_modifiers(self,name='張遼'):
        p=self.profile(name)
        return {
            'attack_bonus': (p.level-1)//TEMP['level_attack_every'] + (p.star-1)*TEMP['star_attack_bonus'],
            'hp_bonus': (p.level-1)//TEMP['level_hp_every'] + (p.star-1)*TEMP['star_hp_bonus'],
            'unlocked_skill_count': self.unlocked_skill_count(name),
        }

    def apply_to_card(self,card):
        if card.name not in self.generals: return card
        p=self.profile(card.name); mod=self.battle_modifiers(card.name)
        card.attack+=mod['attack_bonus']; card.max_hp+=mod['hp_bonus']; card.hp=card.max_hp
        skills=list(getattr(card,'a04_skills',[]) or [])
        card.a08_all_skills=skills; card.a04_skills=skills[:mod['unlocked_skill_count']]
        card.a08_growth={'level':p.level,'star':p.star,'attack_bonus':mod['attack_bonus'],'hp_bonus':mod['hp_bonus']}
        return card

    def state(self):
        return {
            'version':'A10','resources':dict(self.resources),
            'generals':{k:{**asdict(v),'unlocked_skill_count':self.unlocked_skill_count(k),'battle_modifiers':self.battle_modifiers(k)} for k,v in self.generals.items()},
            'owned_equipment':dict(self.owned_equipment),'owned_horses':dict(self.owned_horses),'owned_books':dict(self.owned_books),
            'temporary_parameters':dict(TEMP),
        }
