from __future__ import annotations
from dataclasses import asdict
from typing import Any, Dict, List
from .general_runtime import load_catalog
from .progression_runtime import GeneralGrowth
from .balance_c08 import value as c08_value

_TP=c08_value('tavern.ticket_price')
TEMP_A09={
    'single_ticket_cost':int(_TP['single']),
    'ten_ticket_cost':int(_TP['ten']),
    'starter_recruit_tickets':int(_TP['starter_tickets']),
    'lineup_max':8,
    'battle_deck_size':25,
}

class TavernCollectionController:
    """A09 front-loop adapter over frozen Grid11 tavern.

    Original Grid11 owns recruit semantics. This adapter owns only playable collection,
    lineup and Temporary ticket economy required to connect the front loop to battle.
    """
    def __init__(self, core, growth):
        self.core=core; self.growth=growth; self.m=core.modules['tavern']
        cards=load_catalog(expanded=True)['cards']; self.cards=cards
        self.by_id={c['card_id']:c for c in cards}; self.by_name={c['name']:c for c in cards}
        pool=[self.m.RecruitCard(c['card_id'],c['name'],c['faction'],c['quality']) for c in cards]
        state=self.m.TavernState(version='HAOLING_2016')
        starter='張遼'; sid=self.by_name[starter]['card_id']; state.owned[sid]=1
        self.engine=self.m.TavernEngine(state=state,seed=17,pool=pool)
        self.recruit_tickets=TEMP_A09['starter_recruit_tickets']
        self.lineup=[starter]
        self.last_recruit=None; self.history=[]

    def _ticket_cost(self,count:int)->int:
        return TEMP_A09['single_ticket_cost'] if count==1 else TEMP_A09['ten_ticket_cost']

    def _ensure_growth_profile(self,name:str):
        if name in self.growth.roster.generals:return
        c=self.by_name[name]
        self.growth.roster.generals[name]=GeneralGrowth(name=name,quality=c.get('quality') or '橙')

    def _sync_fragment_to_growth(self,card_id:str,name:str):
        qty=int(self.engine.state.fragments.get(card_id,0))
        self.growth.roster.resources[f'{name}碎片']=qty

    def recruit(self,count:int=1)->Dict[str,Any]:
        count=int(count)
        if count not in (1,10):raise ValueError('只支援單抽或十連')
        cost=self._ticket_cost(count)
        if self.recruit_tickets<cost:raise ValueError(f'招募令不足：需要 {cost}')
        self.recruit_tickets-=cost
        r=self.engine.recruit('HIGH',count,charge=False)
        view=[]
        for z in r['results']:
            c=z['card']; g=z['grant']
            if not z['duplicate']:
                self._ensure_growth_profile(c.name)
            else:
                self._sync_fragment_to_growth(c.card_id,c.name)
            view.append({'card_id':c.card_id,'name':c.name,'faction':c.faction,'quality':c.quality,'duplicate':bool(z['duplicate']),'grant':dict(g)})
        self.last_recruit={'count':count,'ticket_cost':cost,'results':view,'first_draw_orange_rule':True,'layer':'ORIGINAL_RULE_BALANCE_C08_TICKET'}
        self.history.append(self.last_recruit)
        return self.last_recruit

    def force_duplicate_for_test(self,name:str)->Dict[str,Any]:
        """Deterministic verification hook; still delegates duplicate conversion to Grid11."""
        c=self.by_name[name]
        if c['card_id'] not in self.engine.state.owned:
            self.engine.state.owned[c['card_id']]=1; self._ensure_growth_profile(name)
        r=self.engine.event_recruit('HIGH',1,[c['card_id']],charge=False)
        z=r['results'][0]; self._sync_fragment_to_growth(c['card_id'],name)
        return {'name':name,'duplicate':z['duplicate'],'grant':dict(z['grant'])}

    def set_lineup(self,names:List[str])->Dict[str,Any]:
        seen=[]
        for raw in names:
            n=str(raw)
            if n in seen:continue
            c=self.by_name.get(n)
            if not c:raise ValueError(f'未知武將：{n}')
            if c['card_id'] not in self.engine.state.owned:raise ValueError(f'尚未收藏：{n}')
            seen.append(n)
        if not seen:raise ValueError('編隊至少需要1名武將')
        if len(seen)>TEMP_A09['lineup_max']:raise ValueError(f'編隊最多 {TEMP_A09["lineup_max"]} 名')
        self.lineup=seen
        r={'action':'SET_LINEUP','lineup':list(self.lineup),'layer':'TEMPORARY_FRONTEND_SIZE'}; self.history.append(r); return r

    def toggle_lineup(self,name:str)->Dict[str,Any]:
        if name in self.lineup:
            if len(self.lineup)<=1:raise ValueError('編隊至少保留1名武將')
            return self.set_lineup([x for x in self.lineup if x!=name])
        return self.set_lineup(self.lineup+[name])

    def battle_deck_names(self)->List[str]:
        if not self.lineup:raise ValueError('尚未編隊')
        size=TEMP_A09['battle_deck_size']
        return [self.lineup[i%len(self.lineup)] for i in range(size)]

    def state(self)->Dict[str,Any]:
        owned_ids=set(self.engine.state.owned)
        collection=[]
        for c in self.cards:
            owned=c['card_id'] in owned_ids
            collection.append({
                'card_id':c['card_id'],'name':c['name'],'faction':c['faction'],'quality':c['quality'],
                'owned':owned,'fragments':int(self.engine.state.fragments.get(c['card_id'],0)),
                'in_lineup':c['name'] in self.lineup,
                'skills':[s['name'] for s in c.get('skills',[])],
            })
        return {
            'version':'A10','recruit_tickets':self.recruit_tickets,'draw_count':self.engine.state.draw_count,
            'first_draw_done':self.engine.state.first_tavern_draw_done,'last_recruit':self.last_recruit,
            'owned_count':len(owned_ids),'catalog_count':len(collection),'collection':collection,
            'lineup':list(self.lineup),'lineup_max':TEMP_A09['lineup_max'],
            'temporary_parameters':dict(TEMP_A09),
            'original_rules':{'first_tavern_draw_orange':True,'single_and_ten_pull':True,'duplicate_to_fragments':True,'2016_price':'UNCONFIRMED'},
        }
