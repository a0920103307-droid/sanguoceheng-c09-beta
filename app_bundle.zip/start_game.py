from __future__ import annotations
import json, logging, threading, webbrowser, secrets, shutil
from http.cookies import SimpleCookie
from logging.handlers import RotatingFileHandler
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from game_core import GameCore, PVECampaignController
from game_core.savegame import SaveGameManager, migrate_save
from game_core.cloud_store import CloudSaveStore, CloudConflictError, CloudSaveError
from game_core.project_config import load_project_config
from game_core.auth import AuthStore, Identity, SESSION_TTL
from game_core.telemetry import TelemetryStore, TelemetryEvent, CLIENT_EVENTS
from game_core.closed_beta import ClosedBetaStore, BetaFeedback

BASE=Path(__file__).resolve().parent; RUNTIME=BASE/'runtime_modules'; WEB_DIR=BASE/'web'; HTML=(WEB_DIR/'index.html').read_text(encoding='utf-8')
PROJECT_VERSION=(BASE/'VERSION').read_text().strip() if (BASE/'VERSION').exists() else '0.3'; DATA_VERSION=(BASE/'DATA_VERSION').read_text().strip() if (BASE/'DATA_VERSION').exists() else 'v0.3'; CONFIG=load_project_config(BASE)
LOG_DIR=BASE/'logs'; LOG_DIR.mkdir(parents=True,exist_ok=True); logger=logging.getLogger('sanguoceheng')
if not logger.handlers:
    logger.setLevel(getattr(logging,CONFIG.log_level.upper(),logging.INFO)); h=RotatingFileHandler(LOG_DIR/f'{CONFIG.environment}.log',maxBytes=1_000_000,backupCount=3,encoding='utf-8'); h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s')); logger.addHandler(h)
AUTH=AuthStore(CONFIG.save_dir/'auth'/'accounts.sqlite3'); CLOUD=CloudSaveStore(CONFIG.save_dir/'cloud'/'cloud_saves.sqlite3'); TELEMETRY=TelemetryStore(CONFIG.save_dir/'telemetry'/'telemetry.sqlite3'); BETA=ClosedBetaStore(CONFIG.save_dir/'beta'/'feedback.sqlite3'); PLAYER_DIR=CONFIG.save_dir/'players'; GUEST_DIR=CONFIG.save_dir/'guests'; controllers={}; controller_lock=threading.RLock(); guest_sessions={}

def build_player(identity:Identity):
    base=(GUEST_DIR if identity.is_guest else PLAYER_DIR)/identity.player_id
    mgr=SaveGameManager(base/'savegame.json'); c=PVECampaignController(GameCore(RUNTIME),seed=7); c.attach_save_manager(mgr)
    if identity.is_guest:
        status=mgr.load(c); return c,mgr,{**status,'cloud':False,'cloud_revision':0}
    cloud=CLOUD.load(identity.player_id)
    if cloud:
        c.import_savegame(cloud.document); mgr._atomic_write(cloud.document)
        return c,mgr,{'loaded':True,'source':cloud.source,'cloud':True,'cloud_revision':cloud.revision,'recovered':cloud.recovered}
    status=mgr.load(c)
    revision=CLOUD.save(identity.player_id,c.export_savegame(),expected_revision=0,reason='c04_bootstrap')
    mgr._atomic_write(c.export_savegame())
    return c,mgr,{**status,'cloud':True,'cloud_revision':revision,'migrated_to_cloud':True}

def sync_cloud(identity,c,mgr,status,*,reason='action'):
    if identity.is_guest:
        mgr.save(c,backup=False,reason=reason); return 0
    expected=int(status.get('cloud_revision',CLOUD.current_revision(identity.player_id)))
    revision=CLOUD.save(identity.player_id,c.export_savegame(),expected_revision=expected,reason=reason)
    status['cloud_revision']=revision; status['cloud']=True
    mgr.save(c,backup=False,reason=reason)
    return revision

def session_cookie(headers):
    raw=headers.get('Cookie',''); c=SimpleCookie(); c.load(raw); return c.get('sgch_session').value if c.get('sgch_session') else None

def guest_cookie(headers):
    raw=headers.get('Cookie',''); c=SimpleCookie(); c.load(raw); return c.get('sgch_guest').value if c.get('sgch_guest') else None

def identity_from_headers(headers):
    token=session_cookie(headers); ident=AUTH.identity_for_token(token)
    if ident:return ident
    gt=guest_cookie(headers)
    if gt and gt in guest_sessions:return guest_sessions[gt]
    return None

def player_context(identity):
    with controller_lock:
        if identity.player_id not in controllers: controllers[identity.player_id]=build_player(identity)
        return controllers[identity.player_id]

class Handler(BaseHTTPRequestHandler):
    def _json(self,obj,code=200,cookies=None):
        raw=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store')
        for cookie in cookies or []: self.send_header('Set-Cookie',cookie)
        self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def _body(self):
        n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n) or b'{}')
    def _auth(self): return identity_from_headers(self.headers)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/':
            raw=HTML.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Cache-Control','no-cache'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        if path=='/api/auth/me':
            i=self._auth(); self._json({'authenticated':bool(i),'player':None if not i else {'player_id':i.player_id,'username':i.username,'is_guest':i.is_guest},'legacy_save_available':(CONFIG.save_dir/'savegame.json').exists() and AUTH.legacy_claimed_by() is None}); return
        if path=='/api/profile':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            c,_,status=player_context(i); st=c.state(); self._json({'ok':True,'player_id':i.player_id,'username':i.username,'is_guest':i.is_guest,'cloud_revision':status.get('cloud_revision',0),'profile':{'screen':st.get('screen'),'resources':st.get('growth',{}).get('resources',{}),'collection':st.get('collection',{}),'decks':st.get('decks',{}),'pve':{'food':st.get('food'),'inventory':st.get('inventory'),'stages':st.get('stages')},'growth':st.get('growth',{}),'tavern':st.get('collection',{}),'arena':st.get('arena',{}),'alliance':st.get('alliance',{})}}); return
        if path=='/api/cloud/save':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            if i.is_guest:self._json({'ok':False,'error':'GUEST_NO_CLOUD'},400); return
            cloud=CLOUD.load(i.player_id)
            if not cloud:self._json({'ok':False,'error':'CLOUD_SAVE_NOT_FOUND'},404); return
            self._json({'ok':True,'schema':'sgch.cloudsave','cloud_schema_version':1,'revision':cloud.revision,'updated_at':cloud.updated_at,'recovered':cloud.recovered,'savegame':cloud.document}); return
        if path=='/api/cloud/backups':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            if i.is_guest:self._json({'ok':False,'error':'GUEST_NO_CLOUD'},400); return
            self._json({'ok':True,'backups':CLOUD.list_backups(i.player_id)}); return
        if path=='/api/state':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            c,_,status=player_context(i); s=c.state(); s['identity']={'player_id':i.player_id,'username':i.username,'is_guest':i.is_guest}; s['cloud_revision']=status.get('cloud_revision',0); self._json(s); return
        if path=='/api/beta/me':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            self._json({'ok':True,**TELEMETRY.participant_progress(i.player_id)}); return
        if path=='/api/beta/report':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            self._json({'ok':True,'telemetry':TELEMETRY.summary(),'feedback':BETA.report(),'human_test_status':'PENDING_EXTERNAL_TESTERS'}); return
        if path=='/api/telemetry/summary':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            self._json({'ok':True,**TELEMETRY.summary()}); return
        if path=='/api/telemetry/export':
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
            self._json({'ok':True,'schema':'sgch.telemetry.export','events':TELEMETRY.export_redacted()}); return
        if path=='/api/version': self._json({'project_version':PROJECT_VERSION,'data_version':DATA_VERSION,'save_version':7,'environment':CONFIG.environment,'web_mode':'pwa','auth_mode':'c03-local-account','cloud_save':'c04-revisioned-server-store','cloud_schema_version':1,'mobile_mode':'c05-responsive-touch','performance_tier':'client-adaptive','tutorial_mode':'c06-first-run-guided-flow','telemetry_mode':'c07-redacted-closed-test','balance_mode':'c08-v1','closed_beta_mode':'c09-instrumented','human_test_status':'PENDING_EXTERNAL_TESTERS'}); return
        if path=='/api/health': self._json({'ok':True,'service':'sgch','project_version':PROJECT_VERSION,'environment':CONFIG.environment}); return
        static_map={'/manifest.webmanifest':('manifest.webmanifest','application/manifest+json; charset=utf-8'),'/sw.js':('sw.js','application/javascript; charset=utf-8'),'/offline.html':('offline.html','text/html; charset=utf-8'),'/assets/icons/icon-192.svg':('assets/icons/icon-192.svg','image/svg+xml'),'/assets/icons/icon-512.svg':('assets/icons/icon-512.svg','image/svg+xml')}
        if path in static_map:
            rel,ctype=static_map[path]; raw=(WEB_DIR/rel).read_bytes(); self.send_response(200); self.send_header('Content-Type',ctype); self.send_header('Cache-Control','no-cache' if path=='/sw.js' else 'public, max-age=86400'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        self.send_error(404)
    def do_POST(self):
        path=urlparse(self.path).path
        try:d=self._body()
        except Exception:self._json({'ok':False,'message':'JSON 格式錯誤'},400); return
        try:
            if path=='/api/auth/register':
                i=AUTH.register(str(d.get('username','')),str(d.get('password',''))); token=AUTH.create_session(i); TELEMETRY.record_for_player(i.player_id,'login',category='auth',success=True,metadata={'method':'register'}); self._json({'ok':True,'player':i.__dict__},201,[f'sgch_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}']); return
            if path=='/api/auth/login':
                i=AUTH.authenticate(str(d.get('username','')),str(d.get('password','')))
                if not i:self._json({'ok':False,'message':'帳號或密碼錯誤'},401); return
                token=AUTH.create_session(i); TELEMETRY.record_for_player(i.player_id,'login',category='auth',success=True,metadata={'method':'password'}); self._json({'ok':True,'player':i.__dict__},200,[f'sgch_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}','sgch_guest=; Path=/; Max-Age=0; SameSite=Strict']); return
            if path=='/api/auth/guest':
                tok=secrets.token_urlsafe(24); i=Identity('G-'+secrets.token_hex(8).upper(),'訪客',True); guest_sessions[tok]=i; TELEMETRY.record_for_player(i.player_id,'login',category='auth',success=True,metadata={'method':'guest'}); self._json({'ok':True,'player':i.__dict__},201,[f'sgch_guest={tok}; Path=/; HttpOnly; SameSite=Strict; Max-Age={24*60*60}']); return
            if path=='/api/auth/logout':
                AUTH.revoke(session_cookie(self.headers)); gt=guest_cookie(self.headers); guest_sessions.pop(gt,None); self._json({'ok':True},200,['sgch_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict','sgch_guest=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict']); return
            if path=='/api/beta/feedback':
                i=self._auth()
                if not i:self._json({'ok':False,'error':'AUTH_REQUIRED'},401); return
                fid,priority=BETA.submit(BetaFeedback(player_hash=TELEMETRY.player_hash(i.player_id),session_id=d.get('session_id'),category=d.get('category','other'),severity=d.get('severity','suggestion'),screen=d.get('screen'),message=d.get('message',''),reproduce=d.get('reproduce')))
                TELEMETRY.record_for_player(i.player_id,'beta_feedback',category='beta',screen=d.get('screen'),success=True,metadata={'action':'submit_feedback'})
                self._json({'ok':True,'feedback_id':fid,'priority':priority},201); return
            if path=='/api/telemetry':
                i=self._auth(); event_name=str(d.get('event_name',''))
                if event_name not in CLIENT_EVENTS:self._json({'ok':False,'error':'EVENT_NOT_ALLOWED'},400); return
                TELEMETRY.record(TelemetryEvent(event_name=event_name,player_hash=TELEMETRY.player_hash(i.player_id if i else None),session_id=d.get('session_id'),category='error' if event_name in {'js_error','api_error'} else 'client',screen=d.get('screen'),duration_ms=d.get('duration_ms'),success=False if event_name in {'js_error','api_error'} else None,error_code=d.get('error_code'),metadata=d))
                self._json({'ok':True}); return
            i=self._auth()
            if not i:self._json({'ok':False,'error':'AUTH_REQUIRED','message':'請先登入'},401); return
            if path=='/api/auth/claim-local-save':
                if i.is_guest:self._json({'ok':False,'message':'訪客不可綁定舊存檔'},400); return
                old=CONFIG.save_dir/'savegame.json'; claimed=AUTH.legacy_claimed_by(); target=PLAYER_DIR/i.player_id/'savegame.json'
                if claimed:self._json({'ok':False,'message':'舊存檔已被綁定'},409); return
                if not old.exists():self._json({'ok':False,'message':'沒有可綁定的舊存檔'},404); return
                target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(old,target); AUTH.mark_legacy_claimed(i.player_id); controllers.pop(i.player_id,None); c,_,status=player_context(i); self._json({'ok':True,'message':'舊存檔已綁定此帳號','load_status':status,'state':c.state()}); return
            if path=='/api/cloud/save':
                if i.is_guest:self._json({'ok':False,'error':'GUEST_NO_CLOUD'},400); return
                try:
                    doc=migrate_save(d.get('savegame') or {})
                    revision=CLOUD.save(i.player_id,doc,expected_revision=int(d.get('base_revision',0)),reason='api_cloud_save')
                    c,mgr,status=player_context(i); c.import_savegame(doc); mgr._atomic_write(doc); status['cloud_revision']=revision
                    self._json({'ok':True,'revision':revision,'state':c.state()}); return
                except CloudConflictError as exc:
                    self._json({'ok':False,'error':'SAVE_CONFLICT','current_revision':exc.current_revision,'message':str(exc)},409); return
            if path=='/api/cloud/restore':
                if i.is_guest:self._json({'ok':False,'error':'GUEST_NO_CLOUD'},400); return
                restored=CLOUD.restore(i.player_id,int(d.get('backup_id',0)))
                c,mgr,status=player_context(i); c.import_savegame(restored.document); mgr._atomic_write(restored.document); status['cloud_revision']=restored.revision
                self._json({'ok':True,'revision':restored.revision,'source':restored.source,'state':c.state()}); return
            if path!='/api/action': self.send_error(404); return
            c,mgr,status=player_context(i); a=d.get('action')
            if str(a).startswith('tutorial_'): r=c.tutorial_action(str(a))
            elif a=='open_stages': r=c.open_stages()
            elif a=='open_tavern': r=c.open_tavern()
            elif a=='open_collection': r=c.open_collection()
            elif a=='open_dungeons': r=c.open_dungeons()
            elif a=='open_economy': r=c.open_economy()
            elif a=='open_arena': r=c.open_arena()
            elif a=='open_alliance': r=c.open_alliance()
            elif str(a).startswith('alliance_'): r=c.alliance_action(str(a),**d)
            elif a=='arena_challenge': r=c.arena_challenge(str(d.get('opponent_id','')))
            elif a=='arena_claim_chest': r=c.arena_claim_chest(int(d.get('threshold',0)))
            elif a=='arena_reset_season': r=c.arena_reset_season(d.get('season_id'))
            elif a=='economy_claim_daily': r=c.economy_claim_daily()
            elif a=='economy_exchange': r=c.economy_exchange(str(d.get('exchange_id','')))
            elif a=='dungeon_challenge': r=c.dungeon_challenge(str(d.get('dungeon_id','')))
            elif a=='recruit_single': r=c.tavern_recruit(1)
            elif a=='recruit_ten': r=c.tavern_recruit(10)
            elif a=='set_lineup': r=c.lineup_action(d.get('names') or [])
            elif a=='save_deck': r=c.deck_save_action(d.get('slot_id',1),d.get('name',''),d.get('cards') or [])
            elif a=='select_deck': r=c.deck_select_action(d.get('slot_id',1))
            elif a=='open_growth': r=c.open_growth()
            elif a=='back_main': r=c.back_main()
            elif a=='save_now': mgr.save(c,backup=True,reason='manual_api'); r=type('R',(),{'ok':True,'message':'存檔完成','state':c.state()})()
            elif a=='backup_save': dest=mgr.manual_backup(); r=type('R',(),{'ok':True,'message':f'備份完成：{dest.name}','state':c.state()})()
            elif a=='select_stage': r=c.select_stage(str(d['stage_id']))
            elif a=='enter_stage': r=c.enter_stage(d.get('stage_id'))
            elif a=='sweep': r=c.sweep(str(d['stage_id']))
            elif a in {'level_up','evolve','equip_item','strengthen_equipment','equip_growth_horse','strengthen_growth_horse','study_book'}: r=c.growth_action(a,**d)
            else:
                battle_data={k:v for k,v in d.items() if k!='action'}
                r=c.battle_action(a,**battle_data)
            if r.ok:
                try: sync_cloud(i,c,mgr,status,reason=f'c04:{a}')
                except CloudConflictError as exc:
                    controllers.pop(i.player_id,None); self._json({'ok':False,'error':'SAVE_CONFLICT','current_revision':exc.current_revision,'message':'雲端資料已被其他裝置更新，請重新載入後再操作'},409); return
            if r.ok:
                event_name=None; meta={'action':str(a)}
                if a=='tutorial_start': event_name='tutorial_start'
                elif a=='tutorial_complete': event_name='tutorial_complete'
                elif a in {'recruit_single','recruit_ten'}: event_name='recruit'; meta['draw_count']=10 if a=='recruit_ten' else 1
                elif a in {'save_deck','set_lineup','select_deck'}: event_name='lineup'
                elif a=='enter_stage': event_name='stage_start'; meta['stage_id']=str(d.get('stage_id') or '')
                elif a=='dungeon_challenge': event_name='dungeon'; meta['dungeon_id']=str(d.get('dungeon_id') or '')
                elif a in {'level_up','evolve','equip_item','strengthen_equipment','equip_growth_horse','strengthen_growth_horse','study_book'}: event_name='growth'
                elif a=='arena_challenge': event_name='ai_arena'; meta['opponent_id']=str(d.get('opponent_id') or '')
                if event_name: TELEMETRY.record_for_player(i.player_id,event_name,category='gameplay',screen=r.state.get('screen'),success=True,metadata=meta)
                lr=r.state.get('last_result') if isinstance(r.state,dict) else None
                if r.state.get('screen')=='RESULT' and isinstance(lr,dict) and a not in {'open_stages','back_main'}:
                    TELEMETRY.record_for_player(i.player_id,'stage_success' if lr.get('won') or lr.get('sweep') else 'stage_fail',category='gameplay',screen='RESULT',success=bool(lr.get('won') or lr.get('sweep')),metadata={'action':str(a),'result':'win' if lr.get('won') or lr.get('sweep') else 'loss'})
            st=r.state; st['identity']={'player_id':i.player_id,'username':i.username,'is_guest':i.is_guest}; st['cloud_revision']=status.get('cloud_revision',0); self._json({'ok':r.ok,'message':r.message,'state':st})
        except ValueError as exc:self._json({'ok':False,'message':str(exc)},400)
        except Exception as exc:
            i=self._auth(); TELEMETRY.record(TelemetryEvent(event_name='server_error',player_hash=TELEMETRY.player_hash(i.player_id if i else None),category='error',screen=None,success=False,error_code=type(exc).__name__,metadata={'action':str(d.get('action','')) if isinstance(d,dict) else ''})); logger.exception('API failed'); self._json({'ok':False,'message':'SERVER_ERROR'},500)
    def log_message(self,fmt,*args): logger.info('request %s',fmt%args)

if __name__=='__main__':
    server=ThreadingHTTPServer((CONFIG.host,CONFIG.port),Handler); actual_port=server.server_address[1]; url=f'http://{CONFIG.host}:{actual_port}/'; banner=f'三國策衡｜原創化封閉測試｜D09 {PROJECT_VERSION}｜env={CONFIG.environment}｜{url}'; print(banner); logger.info(banner)
    if CONFIG.open_browser: threading.Timer(.6,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close(); logger.info('server stopped')
