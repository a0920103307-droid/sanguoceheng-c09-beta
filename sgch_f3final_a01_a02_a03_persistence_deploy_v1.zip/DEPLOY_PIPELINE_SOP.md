# 部署流水 SOP｜固定交接规则

## 原则
部署等待期间不停工。前一版在 Render build / live 验收时，下一步继续开发；可合并相邻步骤后一次部署，减少等待次数。

## 用户操作最小化
用户原则上只负责把 ChatGPT 提供的英文 Deploy ZIP 上传 GitHub。不得每个步骤都要求用户进入 Render 手动修改 Build Command。

## 当前仓库限制
现有 Render `sanguoceheng-c09-beta-p04final` 的 Build Command 固定读取 `app_bundle-final.zip`。GitHub 网页上传同名档会自动改名，不能当作真正覆盖机制。

## 后续固定处理
1. ChatGPT 先完成并测试开发步骤。
2. 相邻步骤可合并为同一个 Deploy Bundle（例如 A01+A02+A03）。
3. 部署前确认 Render 实际读取的 canonical bundle。
4. 有 GitHub 写权限时，由 ChatGPT／自动化把最新 Deploy Bundle promote 为 canonical `app_bundle-final.zip`。
5. 无写权限时，不反复要求用户修改 Render；优先一次性修复部署通道权限或固定自动 promotion 机制。
6. Render 部署期间继续下一开发步骤，不空等。
7. 每次部署后记录 commit、deploy id、live 时间、验收结果。

## A 阶段当前流水
- A01 帐号资料持久化：程式完成，尚未真正部署到当前 Live。
- A02 Session 登入状态持久化：已完成本机候选。
- A03 玩家存档持久化：已完成本机候选。
- 下一次建议以 A01+A02+A03 合并包一次部署与验收。
